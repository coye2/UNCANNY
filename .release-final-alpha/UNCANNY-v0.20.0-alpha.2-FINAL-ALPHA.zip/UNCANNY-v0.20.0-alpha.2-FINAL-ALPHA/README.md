# UNCANNY v0.20.0-alpha.2 — FINAL ALPHA

UNCANNY is a Windows real-time graphics remastering runtime for games and emulators.

**This is the final alpha checkpoint before beta.** It packages the exact tested ELYSIUM runtime from `748f80b6a63f64bc811479b185e00dc45d34c373`. The later recovered DLSS5 development branch is intentionally not included.

## Start

1. Extract the ZIP completely.
2. Run **`UNCANNY.exe`**.
3. Select or manually add a game/emulator.
4. Choose **Install UNCANNY** or **Update UNCANNY**.
5. Launch normally and press **HOME** for the Control Deck.

## Verified additions in this checkpoint

- D3D11 rigid-geometry fixture changes actual vertex/index buffers and rasterized depth.
- Normal-only recovery changes real normal buffers while preserving topology/positions.
- Material targeting passed the magenta isolation test: **65,536 selected pixels changed, 65,536 unrelated pixels stayed byte-identical, and restoration was exact**.
- The source-bounded detail governor reduced controlled-fixture overshoot from `0.0391917` to `0.0129333` and flat-region variance from `0.00182544` to `0.000234787`.
- Conservative water recovery produced a measurable controlled-fixture response while keeping missing-guide and false-positive safety gates.
- Motion/temporal fixtures, x86/x64 production builds, Windows, GPU/provider, research and flagship suites passed for the exact candidate.

## What this release does NOT claim

No real game was used to certify the new geometry/material/water fixtures. No approved game geometry profile ships. Universal auto-tessellation, automatic rock displacement, animated mesh replacement, dramatic water geometry and the later recovered DLSS5 bridge are **not** claimed by this Final Alpha.

## Exact validation

Runtime source: `748f80b6a63f64bc811479b185e00dc45d34c373`  
CI run: `35683346915`  
BuildId: `elysium45-hf18.14`  
ABI: `143`

The package keeps proprietary native/shader source private. Public files are restricted to compiled release binaries, installer/runtime scripts, configs, documentation and third-party notices. See `SECURITY.md` and `docs/FINAL-ALPHA-VERIFICATION.md`.

## Windows trust

The binaries are currently unsigned, so SmartScreen / Unknown Publisher can appear. Do not disable Defender or add broad exclusions. A new antivirus result applies only after the exact final ZIP has been scanned; prior scans are not silently carried forward.
