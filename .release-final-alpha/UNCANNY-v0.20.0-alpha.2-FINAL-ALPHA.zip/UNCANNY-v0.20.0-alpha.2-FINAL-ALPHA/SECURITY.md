# Security — UNCANNY Final Alpha

This public package is built from the exact validated runtime candidate `748f80b6a63f64bc811479b185e00dc45d34c373` and is distributed as **v0.20.0-alpha.2 Final Alpha**.

## Public-package boundary

The package excludes proprietary C/C++/shader source, debug symbols, private recovery manifests, private evidence archives, compiler outputs and developer-only test executables. It contains compiled release binaries, readable install/recovery scripts, configuration, documentation and required third-party notices.

Native release components were built with stripped symbols, hidden visibility, ThinLTO, stack protection, ASLR, DEP, CFG and x64 high-entropy VA. Protected shader resources use authenticated AES-256-GCM packaging. These measures raise tampering/reverse-engineering cost; they are not a claim that client-side code is impossible to reverse engineer.

## Integrity

`SHA256SUMS.txt` covers the public package members. `FINAL-ALPHA-VERIFICATION.json` records the exact source candidate, CI run and runtime binary hashes. The outer ZIP SHA-256 is published beside the release asset.

## Antivirus / signing

UNCANNY does not require Defender exclusions or security bypasses. The binaries are unsigned, so SmartScreen / Unknown Publisher can appear. Do not reuse an antivirus result from an older ZIP as proof for this repackaged Final Alpha; scan results apply only to the exact file/hash tested.

## Scope

Do not use UNCANNY to bypass anti-cheat, protected-process restrictions or software authorization. Review diagnostic logs before sharing because local paths, process names and game identifiers can appear.

Copyright © 2026 Coye Stillwagen. All rights reserved.
