# Third-party notices

UNCANNY is closed source. Copyright © 2026 Coye Stillwagen. All rights reserved. Third-party notices do not license the UNCANNY engine under an open-source license.

The Windows binaries statically link applicable LLVM-MinGW compiler/runtime components. Their notices are supplied in `third-party-notices/` in the release ZIP. These notices apply to their respective third-party components only. The compiler is not included.

Real-ESRGAN/NCNN runners and models are obtained separately by the optional asset dependency installer. Their original notices and terms remain applicable. UNCANNY does not claim ownership of model weights or replace their notices.

NVIDIA NGX/DLSS providers are supplied separately by the user. No proprietary NVIDIA provider is redistributed in the release ZIP, and the installer does not fetch mirrored NVIDIA DLLs. Windows/DirectX components are supplied by Microsoft and the GPU driver. The optional legacy D3DX9 component is obtained separately from Microsoft.

UNCANNY is an independent project and is not affiliated with or endorsed by NVIDIA. NVIDIA and DLSS are trademarks of NVIDIA Corporation.

Game assets, emulator software and other third-party software retain their respective ownership and terms. No game assets, emulator source or reference-source snapshots are distributed in the public UNCANNY release.

## D3D8 translation

The public ZIP includes an x86 Release build of [crosire/d3d8to9](https://github.com/crosire/d3d8to9), commit `6cdb8a82184898f1b9371e4c8412c2d33ebb7b51`, Copyright (C) 2015 Patrick Mours. Its BSD-2-Clause license and disclaimer are reproduced in `third-party-notices/d3d8to9-LICENSE.txt`. This license applies to that dependency only. Its source is preserved in the private recovery and is available from the upstream project; it is not bundled as source in the public release.
