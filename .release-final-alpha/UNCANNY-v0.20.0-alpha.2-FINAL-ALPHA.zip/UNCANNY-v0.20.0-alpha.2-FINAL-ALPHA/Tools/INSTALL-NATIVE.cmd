@echo off
set "UNCANNY_PACKAGE_ROOT=%~dp0.."
setlocal EnableExtensions
cd /d "%~dp0.."
if "%~1"=="" (
 echo Drag pcsx2-qt.exe or an offline game EXE onto this installer.
 pause
 exit /b 2
)
powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%~dp0..\runtime\PRECHECK.ps1"
if errorlevel 1 (
 echo Installer preflight failed. No target files were changed.
 pause
 exit /b %ERRORLEVEL%
)
powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%~dp0..\runtime\INSTALL-NATIVE.ps1" -Target "%~f1" -CleanEnvironment
if errorlevel 1 pause
