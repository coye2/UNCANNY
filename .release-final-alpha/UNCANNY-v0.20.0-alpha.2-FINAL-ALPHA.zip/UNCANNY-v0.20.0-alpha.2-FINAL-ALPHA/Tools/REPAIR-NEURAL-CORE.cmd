@echo off
set "UNCANNY_PACKAGE_ROOT=%~dp0.."
setlocal EnableExtensions DisableDelayedExpansion
cd /d "%~dp0.."
set "UNCANNY_AI_TARGET_EXE=%~1"
powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%~dp0..\runtime\INSTALL-AI-CORE.ps1" -RepairInstalledTarget -ForceRepair
set "RC=%ERRORLEVEL%"
echo.
if "%RC%"=="0" echo Neural core repair complete. Restart the game and inspect REVENANT.
if not "%RC%"=="0" echo Neural core repair failed with code %RC%. Read the error above. No protection settings were changed.
pause
exit /b %RC%
