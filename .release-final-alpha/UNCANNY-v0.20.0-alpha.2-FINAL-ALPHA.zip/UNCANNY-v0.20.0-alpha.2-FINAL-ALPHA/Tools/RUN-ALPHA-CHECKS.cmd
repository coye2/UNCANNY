@echo off
set "UNCANNY_PACKAGE_ROOT=%~dp0.."
setlocal
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0..\runtime\RUN-ALPHA-CHECKS.ps1"
set "code=%errorlevel%"
echo.
pause
exit /b %code%
