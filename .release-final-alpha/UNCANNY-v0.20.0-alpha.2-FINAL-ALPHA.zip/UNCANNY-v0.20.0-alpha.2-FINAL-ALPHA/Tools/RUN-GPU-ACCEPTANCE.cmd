@echo off
set "UNCANNY_PACKAGE_ROOT=%~dp0.."
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0..\runtime\RUN-GPU-ACCEPTANCE.ps1" %*
pause
