@echo off
set "UNCANNY_PACKAGE_ROOT=%~dp0.."
setlocal EnableExtensions DisableDelayedExpansion
cd /d "%~dp0.."
powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%~dp0..\runtime\RUN-GPU-ACCEPTANCE.ps1" -HardwareInteropOnly -Architecture both -TimeoutSeconds 90
set "RC=%ERRORLEVEL%"
echo.
echo These transport-only tests do not certify DLSS 5 inference or game compatibility.
pause
exit /b %RC%
