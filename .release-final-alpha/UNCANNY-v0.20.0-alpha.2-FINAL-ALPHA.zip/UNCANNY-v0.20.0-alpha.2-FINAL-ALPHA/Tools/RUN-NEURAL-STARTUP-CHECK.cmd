@echo off
set "UNCANNY_PACKAGE_ROOT=%~dp0.."
cd /d "%~dp0.."
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0..\runtime\RUN-NEURAL-STARTUP-CHECK.ps1" %*
set "rc=%errorlevel%"
pause
exit /b %rc%
