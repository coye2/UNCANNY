@echo off
set "UNCANNY_PACKAGE_ROOT=%~dp0.."
setlocal
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0..\runtime\PRECHECK.ps1"
if errorlevel 1 goto failed
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0..\runtime\RUN-REPAIR8-CHECKS.ps1"
if errorlevel 1 goto failed
pause
exit /b 0
:failed
echo Check failed. Read the local report. No game should be treated as certified.
pause
exit /b 1
