@echo off
set "UNCANNY_PACKAGE_ROOT=%~dp0.."
setlocal DisableDelayedExpansion
echo This checks setup argument handling in temporary folders only.
echo It does not download a provider or change your game.
pause
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0..\runtime\TEST-SETUP-LAUNCHER.ps1"
set "TEST_EXIT=%ERRORLEVEL%"
pause
exit /b %TEST_EXIT%
