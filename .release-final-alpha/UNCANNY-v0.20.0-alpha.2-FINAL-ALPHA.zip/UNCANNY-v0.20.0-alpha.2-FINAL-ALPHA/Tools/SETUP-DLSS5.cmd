@echo off
set "UNCANNY_PACKAGE_ROOT=%~dp0.."
setlocal DisableDelayedExpansion
cd /d "%~dp0.." || exit /b 1
echo Close the game and its UNCANNY panel before continuing.
echo Automatic setup preserves backups and never asks you to pick a DLL.
pause
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0..\runtime\SETUP-DLSS5.ps1"
set "UNCANNY_SETUP_EXIT=%ERRORLEVEL%"
if not "%UNCANNY_SETUP_EXIT%"=="0" echo Provider setup failed. Existing backups were preserved; see the error above.
pause
exit /b %UNCANNY_SETUP_EXIT%
