@echo off
set "UNCANNY_PACKAGE_ROOT=%~dp0.."
setlocal
cd /d "%~dp0.."
powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%~dp0..\runtime\SETUP-PC-ASSETS.ps1"
pause
