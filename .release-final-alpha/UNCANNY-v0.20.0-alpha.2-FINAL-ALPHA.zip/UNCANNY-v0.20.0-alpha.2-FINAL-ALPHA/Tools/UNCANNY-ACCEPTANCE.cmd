@echo off
set "UNCANNY_PACKAGE_ROOT=%~dp0.."
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0..\runtime\UNCANNY-ACCEPTANCE.ps1" %*
pause
