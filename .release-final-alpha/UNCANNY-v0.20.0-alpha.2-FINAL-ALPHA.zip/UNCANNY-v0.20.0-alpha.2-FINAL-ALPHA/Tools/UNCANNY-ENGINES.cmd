@echo off
set "UNCANNY_PACKAGE_ROOT=%~dp0.."
if not exist "%~dp0..\UNCANNY.EngineManager.exe" (
  echo Run this command from the installed game folder after installing UNCANNY.
  pause
  exit /b 1
)
start "" "%~dp0..\UNCANNY.EngineManager.exe" --engines
