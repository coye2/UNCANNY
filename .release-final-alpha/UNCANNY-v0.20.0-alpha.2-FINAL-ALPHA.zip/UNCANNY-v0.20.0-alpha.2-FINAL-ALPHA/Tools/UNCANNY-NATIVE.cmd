@echo off
set "UNCANNY_PACKAGE_ROOT=%~dp0.."
setlocal EnableExtensions
cd /d "%~dp0.."
if "%~1"=="" (
 echo Drag pcsx2-qt.exe or an offline game EXE onto this file.
 pause
 exit /b 2
)
powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%~dp0..\runtime\INSTALL-NATIVE.ps1" -Target "%~f1" -CleanEnvironment
if errorlevel 1 (
 pause
 exit /b 1
)
pushd "%~dp1"
call "%~dp1UNCANNY-LAUNCH.cmd"
popd
