@echo off
set "UNCANNY_PACKAGE_ROOT=%~dp0.."
setlocal
cd /d "%~dp0.."
call "%~dp0SETUP-DLSS5.cmd"
exit /b %ERRORLEVEL%
