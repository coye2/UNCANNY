@echo off
set "UNCANNY_PACKAGE_ROOT=%~dp0.."
cd /d "%~dp0.."
title UNCANNY Runtime Diagnostic Report
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0..\runtime\UNCANNY-DIAGNOSTICS.ps1" -SaveReport
pause
