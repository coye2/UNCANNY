# UNCANNY Final Alpha — usage

## Install

1. Download and fully extract `UNCANNY-v0.20.0-alpha.2-FINAL-ALPHA.zip`.
2. Run `UNCANNY.exe`.
3. Let the launcher scan, or disable Scan on startup and add a target manually.
4. Select the real rendering executable.
5. Click **Install UNCANNY** or **Update UNCANNY**.
6. Launch normally and press **HOME** for the Control Deck.

Do not mix DLLs or scripts from different releases.

## Current identity

Distribution: **v0.20.0-alpha.2 FINAL ALPHA**  
Runtime BuildId: `elysium45-hf18.14`  
Runtime revision: `release-alpha.1.elysium-engine45-hf18.14-recovery.2`  
ABI: `143`

## PCSX2

PCSX2 remains on the Direct3D 12 route with `Renderer=15`. The launcher preserves the original emulator executable and uses the verified sidecar/install model.

## REVENANT

REVENANT remains experimental. This release contains a verified controlled D3D11 rigid/material path, but it does not ship a generic approved game profile and does not claim universal animated replacement.

## DLSS 5 / neural

ELYSIUM and the optional neural route are separate. This Final Alpha intentionally excludes the later recovered DLSS5 bridge development so the release stays on the exact tested `748f80b6` runtime. Provider discovery or a loaded DLL alone is not proof of visible neural output.

## Before/after testing

Turn **Enable UNCANNY** off for the live image path. REVENANT replacement files can persist separately and may need restoration for a complete asset-level comparison.

## If something breaks

Run `Tools/UNCANNY-STATUS.cmd` and keep the session logs. Report the game/emulator, API, x86/x64, GPU/driver, exact Final Alpha version, and what happened.
