# UNCANNY v0.20 ELYSIUM compatibility and evidence

`release-alpha.1.elysium-engine45-hf18.14-recovery.2` · ABI 143 · Final Alpha distribution v0.20.0-alpha.2. Exact-revision Windows/GPU behavior must still be verified on the target machine; controlled fixtures are not game certification.

| Route | Current implementation | Release gate |
|---|---|---|
| D3D12 x64 | Native UNCANNY pipeline + optional Feature-18/deep stages | Real game/GPU acceptance required |
| D3D11 x64 | Native D3D11 path with first-frame fail-open Present warmup; D3D12 neural interop is deferred until native Presents are advancing | Hotfix 11 PCSX2 retest + real provider/inference/display acceptance required |
| D3D11 x86 | x64 helper transport for neural work; native frame path remains authoritative | Real helper/provider/request-return acceptance required |
| D3D9/Ex | Native legacy feeder / D3D9On12 when available, spatial fallback otherwise | Old-game compatibility and actual Feature-18 return must be tested |
| D3D10/10.1 | Native image/feeder path + in-game HOME compositor | Real-game acceptance required |
| D3D8 x86 | Preserved/managed D3D8-to-D3D9 route when appropriate | Requires compatible legacy runtime and game test |
| PCSX2 REVENANT | Texture capture, neural reconstruction, replacement commit and reversible visible-load proof | Visible rendered-use proof remains the acceptance gate |
| Native D3D9/D3D11 REVENANT | Existing capture/substitution path preserved | Per-game acceptance required |
| PPSSPP | Separate/offline pack workflow | Not promoted to universal live support |
| Vulkan/OpenGL/D3D7 and earlier | No completed native release route | Not supported by this release claim |

## Hotfix 11 D3D11 evidence

The triggering tester run was PCSX2 x64 on D3D11. The swapchain/device was captured and the Present patch succeeded, but the report stopped at one Present attempt with zero successful Presents, `PresentAdvancing=0` and 0 FPS. Feature-18 create/evaluate counters were still zero. Hotfix 11 therefore changes startup ordering rather than claiming a provider fix.

The normal x64 D3D11 route does not require the separate Host64 helper, so `Host64LaunchAttempted=0` is not by itself a compatibility failure for that case.

A Hotfix 11 D3D11 acceptance run should show the native game image first, then increasing successful Presents, then UNCANNY processing, and only then optional neural initialization. HOME/Deck must not minimize, Alt-Tab, steal focus, or stop Present advancement. Real hardware retest is still required.

A working UNCANNY image hook does not prove DLSS 5/Feature-18 output. Provider presence does not prove a neural evaluation. REVENANT capture/inference counters do not prove the replacement was displayed. The diagnostics intentionally keep those claims separate.
