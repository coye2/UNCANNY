# UNCANNY Final Alpha acceptance scope

Distribution: `v0.20.0-alpha.2 FINAL ALPHA`  
Runtime source: `748f80b6a63f64bc811479b185e00dc45d34c373`  
Runtime revision: `release-alpha.1.elysium-engine45-hf18.14-recovery.2`  
BuildId: `elysium45-hf18.14`  
ABI: `143`

Exact CI run `35683346915` completed production x86/x64, static, Linux, formal, Windows, GPU/provider, additional, research and flagship gates for the runtime candidate.

The controlled flagship evidence proves only what it measures: geometry/material binding in the synthetic D3D11 fixtures, source-bounded image behavior, motion metrics, package integrity and GPU execution on the tested hardware. It does not certify arbitrary games, universal tessellation, animated replacement or visible DLSS5 output in a particular title.
