# Final Alpha hardware acceptance

Use the complete Final Alpha package. Do not mix components from older releases.

Expected distribution: `v0.20.0-alpha.2 FINAL ALPHA`  
Expected runtime BuildId: `elysium45-hf18.14`  
ABI: `143`

For a real-game report, verify attachment, advancing Presents, HOME/Deck responsiveness, OFF/ON/OFF restoration, resize/fullscreen transitions and actual visible output. For REVENANT, distinguish capture/commit counters from visible replacement. For DLSS5, distinguish provider discovery from successful feature creation/evaluation and presented current output.
