# UNCANNY Engine 4.5 — GPU capability notes

UNCANNY's image-processing path is vendor-neutral on the DirectX routes the runtime actually supports. A detected AMD adapter does not disable base UNCANNY processing.

DLSS 5 / Feature 18 is an NVIDIA provider path. When an AMD or Intel rendering adapter is positively identified, UNCANNY reports DLSS 5 as unavailable instead of attempting to present it as a cross-vendor feature.

The Engine 4.5 capability panel reports the detected rendering-vendor ID, base UNCANNY availability, DLSS 5 vendor availability, and whether a real AMD-specific optimized path is active. Engine 4.5 does **not** claim FidelityFX SPD or another RDNA optimization on Direct3D 9; the AMD-specific flag remains inactive unless a real vendor-specific implementation is present.

Tester reports outside CI are compatibility evidence, not universal support guarantees. Hardware/API combinations remain experimental until reproduced in the compatibility matrix.
