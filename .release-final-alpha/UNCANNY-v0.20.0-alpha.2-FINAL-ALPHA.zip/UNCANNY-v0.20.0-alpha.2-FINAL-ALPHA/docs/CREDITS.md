# Developer credits

## Coye — founder, creator and lead software developer

Coye Stillwagen founded UNCANNY and leads its software development and creative direction. His project responsibilities include:

- Project vision, product direction and development priorities.
- Lead software development, engine architecture and runtime integration.
- Graphics development, DirectX compatibility and neural integration direction.
- REVENANT asset reconstruction and remastering direction.
- Scene, material and geometry research and development.
- Visual design, image treatments, presets and quality evaluation.
- Control Deck interface, installation and user experience.
- Testing, debugging, diagnostics and compatibility investigation.
- Builds, release preparation, source protection and private workspace recovery.
- Documentation, community support and project communication.

These credits recognize Coye's roles in UNCANNY. Third-party libraries, models and trademarks remain separately attributed; see [third-party notices](../THIRD-PARTY-NOTICES.md).

## Discord

**Coye:** `coye67`. In HOME → Credits, **Contact Coye on Discord** copies this username and opens Discord Friends, where it can be pasted into Add Friend. A direct profile URL requires Coye's numeric Discord user ID, which is not configured in this release.

**Official UNCANNY server:** [Join the UNCANNY Discord](https://discord.gg/zMveJN2kDa). The separate server button opens this exact invite.

Opening either Discord action intentionally leaves the in-game panel for the browser/app. Pressing HOME alone does not request that desktop focus change.

Copyright © 2026 Coye Stillwagen. All rights reserved.

UNCANNY is an independent project and is not affiliated with or endorsed by NVIDIA. NVIDIA and DLSS are trademarks of NVIDIA Corporation.
