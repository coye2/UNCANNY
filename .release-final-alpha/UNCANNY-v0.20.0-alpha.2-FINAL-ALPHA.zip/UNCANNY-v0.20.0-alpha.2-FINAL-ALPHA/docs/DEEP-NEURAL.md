# Experimental source-anchored neural stages

The hard one-evaluation ceiling has been replaced by an upper-bound policy of 1–3 actual Feature-18 evaluations. The original primary provider path remains available. Two optional independent feature/parameter contexts maintain separate later-stage histories; a gap or camera reset resets the affected later history. A once-per-Present reentrancy guard remains, to prevent duplicate processing of the same Present.

Stage 2 prepares a source-detail residual absent from the current neural anchor. Stage 3 prepares a low-frequency source-tone anchor. Each later evaluation sees a different prepared input and weaker settings; it is not an identical input replay. Each returned proposal is limited by current motion/confidence, source consistency, explicit HUD protection and a bounded incremental residual. This is an original heuristic experiment, not a newly trained provider or established quality improvement.

All stages use the same full-frame dimensions and 100% work scale. No verified provider ROI, cropped/tiled evaluation or reduced-resolution later-stage contract was established. Quarter-cadence later work in Clean 1.5/2.5 reduces frequency and contribution; it does not turn a full evaluation into a fractional one.

A three-slot GPU resource/descriptor/query ring uses actual caller-queue fences. In-flight slots are not rewritten. Unretired resources are retained after failure instead of being freed from a CPU frame count. GPU timestamp queries measure actual calls and the full recorded neural pipeline. The scheduler consumes completed, fresh, frame-identified measurements, not unsubmitted command counts.

Budget decisions use actual measured available neural-call costs, measured VRAM budget/usage, queue availability, sampled scene confidence, source residual cue and observed CPU presentation cadence. Initial unknown later-pass costs are conservatively estimated from the primary until measured. This is not a measurement of the game's full GPU frametime. A stale/absent measurement, low confidence, missing cue, reset, pressure or provider failure retains primary-only or last-good neural output.

| Mode | Ceiling and later contribution |
|---|---|
| Clean 1 | Primary only |
| Clean 1.5 | Up to two; eligible quarter-cadence second stage with 0.20 maximum contribution before per-pixel trust |
| Clean 2 | Up to two; 0.40 second contribution before trust |
| Clean 2.5 | Up to three; stricter confidence, 0.30 second, eligible quarter-cadence third at 0.12 |
| Clean 3 | Up to three; 0.40 second and 0.22 third before trust |

Confidence and source-cue thresholds are heuristics. Explicit HUD masks exclude scene content too, and do not identify every subtitle or interface. The stock motion/confidence source is not labeled native engine motion/depth when reconstructed. Full-frame preparation, readback metrics, later feature contexts and scratch textures add unmeasured overhead/VRAM; do not infer a speedup.

Actual evaluations, successes, timing masks/frame IDs, per-stage reasons and work scales are shown in the provider report. A requested ceiling of three may correctly run one. No extra stage has been executed or benchmarked on an RTX GPU in this build environment. Test matched quality and motion before recommending a higher mode.
