# UNCANNY engine versions

| Engine | Identity | Selection |
|---|---|---|
| **Automatic (recommended)** | Current UNCANNY 4 ELYSIUM Final Alpha runtime | Saved immediately; applied next launch |
| **UNCANNY 4 - ELYSIUM** | `release-alpha.1.elysium-engine45-hf18.14-recovery.2`, ABI 143, BuildId `elysium45-hf18.14` | Saved immediately; applied next launch |
| **UNCANNY 2.5 - Lucid** | preserved `release-fix.5`, ABI 136 | Saved immediately; applied next launch |

Engine builds are not quality presets. Live quality/pass controls remain separate. Binary engine switching is performed while the target is closed so installed files can be hash-checked and rolled back safely.

Earlier Legacy/Rise/Evolve labels remain unavailable because reproducible deployable snapshots are not present in this package.
