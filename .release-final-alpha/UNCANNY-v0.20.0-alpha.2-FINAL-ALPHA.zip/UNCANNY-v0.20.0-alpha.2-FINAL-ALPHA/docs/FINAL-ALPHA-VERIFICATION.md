# Final Alpha verification

Exact runtime source: `748f80b6a63f64bc811479b185e00dc45d34c373`  
Exact CI run: `35683346915`  
Runtime revision: `release-alpha.1.elysium-engine45-hf18.14-recovery.2`  
BuildId: `elysium45-hf18.14`  
ABI: `143`

The public package is rebuilt only at the packaging/document layer from the validated candidate artifact. Native runtime/launcher/Control Deck/REVENANT/bridge bytes are not substituted after the exact candidate run. Member hashes are recorded in `SHA256SUMS.txt` and `FINAL-ALPHA-VERIFICATION.json`.

The package boundary rejects proprietary source, debug symbols, nested private archives, private evidence and internal acceptance executables.

Synthetic fixture PASS is not real-game certification. See `docs/RELEASE-NOTES.md` for the exact verified and unverified claims.

## Controlled proof highlights

- Material target: 65,536 pixels pure magenta.
- Unrelated material: 65,536 pixels byte-identical.
- Restore: exact full-buffer equality.
- Rigid fixture: 48 -> 120 triangles; 39 -> 216 stored vertices; rasterized depth changed.
- Corrected silhouette reference error: 4,464 -> 3,816 pixels.
- Water response: measurable but subtle; max float-channel delta about 0.000303.
