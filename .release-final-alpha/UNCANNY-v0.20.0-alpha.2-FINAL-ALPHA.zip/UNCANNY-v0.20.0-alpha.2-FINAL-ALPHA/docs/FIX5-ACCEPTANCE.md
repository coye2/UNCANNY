# Release Fix 5 acceptance

This is a test candidate. Candidate 4 was reported to have an invisible HOME menu, HUD/minimap corruption with Ghosting Guard, and excessive combined neural cost. Release Fix 5 implements repairs; it has not passed Windows or gameplay acceptance in the build environment. Official v0.20 promotion remains blocked.

## Install and preserve fullscreen

Close the game/emulator and install the complete package over the intended target using `INSTALL-NATIVE.cmd`. Runtime and Control Deck must both use ABI 136. Open the installed game EXE normally; no launch CMD is required. If installation names a running target process, close that process before retrying.

Press HOME while ordinary gameplay is visible, then in borderless and exclusive fullscreen. The supported in-frame panel must appear without minimization or a foreground change. Repeat at least ten open/close cycles, including held HOME, quick taps, Alt-Tab and a resolution change. Test PCSX2 separately for each renderer used. Verify Tab/Shift+Tab, arrows, Enter, scrolling and a real setting change.

If in-frame delivery cannot complete, a desktop fallback now appears instead of remaining invisible. **That fallback can leave exclusive fullscreen and counts as a failed in-frame acceptance result.** Close it with HOME or Escape and inspect Diagnostics. It is a recovery path, not proof the fullscreen bug is fixed.

The fallback hotkey is registered only while the target game has focus. HOME in unrelated applications should retain its normal behavior.

## Automated regressions

From the extracted package, in PowerShell:

```powershell
.\RUN-GPU-ACCEPTANCE.ps1 -Consent -Architecture both
```

This includes `--hud-guard`, using the production Image shader and declared corrupt-input fixtures. It checks protected HUD pixels, invalid history, NaN/infinite guides, resolution changes and image-only stability. It does not identify a real game's HUD or certify visual quality.

For the actual installed panel and physical HOME tests:

```powershell
.\RUN-GPU-ACCEPTANCE.ps1 -Consent -Architecture 64 -IncludeHomeProducer -IncludeFullscreenHome -ProviderRoot 'C:\Games\YourGame'
```

Use architecture `32` for a 32-bit installed target. The supplied folder must contain the matching `UNCANNY.ControlDeck.exe`. The producer regression launches that real executable, requires nonblank published pixels, checks duplicate requests, and exercises the visible fallback. The D3D11 windowed/fullscreen tests generate HOME key events and require actual composition while retaining focus. Existing isolated D3D9/11/12 compositor tests use declared UI pixels; their PASS alone cannot certify the real panel producer. D3D9 and D3D12 physical HOME still require the game checks above.

Optional neural tests require the matching user-supplied provider and compatible NVIDIA hardware:

```powershell
.\RUN-GPU-ACCEPTANCE.ps1 -Consent -Architecture 64 -IncludeNeural11 -ProviderRoot 'C:\Games\YourGame'
.\RUN-GPU-ACCEPTANCE.ps1 -Consent -Architecture 32 -IncludeLegacyOn12 -IncludeNeural9 -ProviderRoot 'C:\Games\LegacyGame'
```

No provider is installed or downloaded by these tests. Unavailable prerequisites must remain UNAVAILABLE, not PASS.

## HUD and Ghosting Guard

Use the same failing scene and minimap from Candidate 4. Test UNCANNY only and UNCANNY + DLSS with Ghosting Guard off/on. Record moving and stationary camera segments, animated minimap markers, health bars, subtitles, menus and loading transitions. Look for blocks, stale pixels, flicker, trails and unwanted edge changes.

Performance → **HUD current-frame protection** offers Auto, lower left, lower right, lower corners and all corners. Each explicit corner covers 28% of the frame width and height and preserves the original current-frame pixels, including any world pixels inside it. Auto is evidence-based and can miss animated or unfamiliar HUDs. The setting applies to implemented D3D11/D3D12 processing and the On12 path; native D3D9 spatial rendering does not use this new mask.

A selected region must remain unchanged by neural processing and image tuning. Changing the region is an explicit workaround for HUDs the automatic heuristic cannot recognize. Do not treat the synthetic fixture as proof that every game's HUD is protected.

## Capture comparable performance

Use the same scene, resolution, provider, driver, camera, frame cap and Clean Stage. Warm up, then record three separate stable runs: master OFF, UNCANNY only, UNCANNY + DLSS. Do not change modes during a performance capture. Allow the rolling cadence window (up to 2048 presents) to refresh after changing modes, then run `UNCANNY-ACCEPTANCE.cmd` for each run. Keep gameplay screenshots/video separate from numeric reports.

Compare source-copy, flow, neural, image and history GPU scopes, CPU submission cost and cadence median/p95/p99. D3D11's neural scope includes preparation and cross-API synchronization; it is not isolated Feature-18 time. Ghosting is integrated in the image pass. Present latency, scene effects, native-depth acquisition and driver memory use are not independently measured by these counters. Stale/unavailable GPU times are reported as -1, never zero cost.

Image-only flow search is now skipped. Measure the actual effect; no FPS improvement, 9/10 quality score or ShortFuse/RenoDX parity is claimed.

## Evidence to retain

Keep the candidate ZIP hash, installed binary hashes, game/emulator version, API, GPU/driver, test settings, structured test reports and before/after captures. The status chain distinguishes HOME input, panel launch, surface publication, presentation attempts, actual submissions and fallback. Runtime counters cannot certify that remastered assets or neural output looked correct on screen.

The remaining release gates are real HOME acceptance across the affected targets, HUD corruption acceptance, successful Feature-18 output and synchronized return per advertised route, visible REVENANT reload evidence, measured performance and matched visual comparisons. D3D10/older native APIs, OpenGL/Vulkan enhancement and universal reconstruction remain incomplete.

Copyright © 2026 Coye Stillwagen. All rights reserved.

UNCANNY is an independent project and is not affiliated with or endorsed by NVIDIA. NVIDIA and DLSS are trademarks of NVIDIA Corporation.
