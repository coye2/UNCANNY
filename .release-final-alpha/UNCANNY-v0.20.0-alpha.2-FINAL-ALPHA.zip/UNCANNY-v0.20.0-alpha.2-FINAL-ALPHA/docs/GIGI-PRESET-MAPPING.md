# Gigi's preset — hp.ini mapping

This preset was translated from the supplied `hp.ini` active stack, not from the inactive TechniqueSorting entries.

Active source intent preserved in UNCANNY-native terms:

- Clarity.fx: strength 0.4, dark intensity 0.4, radius 3.
- qUINT_sharp: RMS/depth masked sharpen, strength 0.7.
- Marty McFly MXAO: radius 2.5, SSAO amount 0.8. UNCANNY uses source-backed meso-form/concavity evidence rather than copying MXAO.
- SOLARIS: bloom intensity 0.097, haziness 0.9, white point 7.0. UNCANNY uses a bounded supported-highlight haze.
- PD80 Filmic Adaptation: linear 1.0, toe 1.0, shoulder 2.8.
- PD80 Shadows/Midtones/Highlights: shadow brightness +0.667, shadow saturation -1.0, midtone contrast +0.341.
- PD80 Color Balance: cool midtone bias, warm-highlight bias, preserve luminance.
- Lightroom / Cinetools LUT / general Contrast-Brightness-Saturation values in the supplied file are neutral and therefore do not add an invented grade.

The source preset and UNCANNY do not share the same renderer, depth buffer, shader implementations, or color pipeline, so bit-identical pixels are not claimed. The dedicated `contentMode == 5` path is the closest native reconstruction of the supplied active look while retaining UNCANNY motion/HUD/artifact guards.
## Tester visual reference refinement

A same-camera tester comparison was supplied after the first port. In that reference the active ReShade side is not simply sharper: the low-end floor is visibly deeper, bright practical lights separate more strongly, the broad pink/magenta veil is reduced, and walls/character silhouettes read with substantially more local material contrast. Engine 4.5 therefore treats the screenshot as an additional perceptual acceptance target.

The Gigi path now uses stronger monotone contrast with a lower shadow floor, radius-scale source-backed veil rejection, luma-neutral broad color-cast reduction, tighter highlight-core bloom, a less destructive filmic shoulder, and the original 0.7 guarded sharpness. These changes are isolated to `contentMode == 5`; they do not alter ELYSIUM defaults or other presets.
