# Hotfix 11 — PCSX2 D3D11 first-frame fail-open repair

Hotfix 11 exists because of a real tester result, not a synthetic compatibility guess.

## What the tester saw

The target was PCSX2 x64 using D3D11. UNCANNY attached far enough to capture the D3D11 device/swapchain and patch DXGI Present successfully, but the game window stayed black.

The saved status/trace showed:

- `PRESENT_PATCH_OK`
- `PresentAttempts=1`
- `Presents=0`
- `PresentAdvancing=0`
- `BaseFPS=0`
- `PresentedFPS=0`
- `ProviderLoaded=0`
- `FeatureCreateAttempts=0`
- `FeatureEvaluateAttempts=0`
- `SharedResourcesCreatedMask=0`
- `FenceCreatedMask=0`
- `DeckConnected=1`
- `DeckSurfacePublished=0`
- `DeckVisible=0`
- `GameForeground=0`
- the separate REVENANT texture path completed 38/38 jobs

The important evidence is that the Present hook was armed and entered once, but the application's native Present never successfully completed afterward. That means the first-frame problem was in work executed before the original D3D11 Present call could return, not in PCSX2's emulation core.

## Why Host64 was not blamed

The same report showed `Host64LaunchAttempted=0` and `Host64Alive=0`. On an x64 D3D11 target, that is not automatically an error: UNCANNY's normal native x64 D3D11 route can use the in-process bridge. A separate x64 helper is required for other transport/isolation cases, including cross-bitness routes, but this report did not prove a helper-launch failure.

Hotfix 11 therefore fixes presentation ordering instead of pretending the issue was simply "start NeuralHost64 earlier."

## What Hotfix 11 changes

### Native Present wins startup

For a direct D3D11 swapchain, the first three native presentation opportunities are warmup frames. UNCANNY image preprocessing and in-frame Control Deck composition are deferred so the game's original `Present` / `Present1` can establish visible output first.

An enhancement layer should never be required for the base game to display its first frame.

### Neural interop waits for a healthy stream

Feature-18/DLSS5 interop is deferred until all of the following are true:

- native presentation is advancing
- at least 8 successful Presents have completed
- the last successful Present is recent

Until that point, the live source frame remains the source. UNCANNY does not substitute a stale neural result simply because neural startup is delayed.

### HOME/Deck cannot block first-frame visibility

The in-frame Control Deck still uses the normal native composition path after startup, but its frame composition is deferred during the initial D3D11 warmup. Focus state can affect input behavior, but it is not allowed to become a prerequisite for base rendering.

### Better stall telemetry

Hotfix 11 adds exact attachment stages around both DXGI presentation entry points:

- `PRESENT_PREPROCESS`
- `PRESENT_NATIVE_CALL`
- `PRESENT1_PREPROCESS`
- `PRESENT1_NATIVE_CALL`
- `PRESENT_SUCCEEDED`

If a future report stops at `PRESENT_PREPROCESS`, it is still inside UNCANNY-side preprocessing. If it reaches `PRESENT_NATIVE_CALL` but never `PRESENT_SUCCEEDED`, UNCANNY reached the application's original Present and the remaining stall is on or below that native call.

## What Hotfix 11 does not rewrite

This patch intentionally preserves:

- Hotfix 10 ELYSIUM pass and slider wiring
- REVENANT capture/reconstruction/replacement behavior
- PCSX2 wrapper launch behavior
- D3D9, D3D10 and D3D12 rendering routes
- provider selection policy
- engine switching
- updater/install/rollback transactions
- protected shader resources

The tester's 38/38 REVENANT completion is one reason that path is intentionally left alone.

## Same-machine acceptance checklist

The original tester setup is considered repaired only when the new build shows all of the following:

1. The PCSX2 game image appears instead of remaining black.
2. `PresentAttempts` continuously increases.
3. `Presents` becomes non-zero and continuously increases.
4. `PresentAdvancing=1`.
5. `BaseFPS` and `PresentedFPS` become non-zero.
6. `AttachmentStage` reaches `PRESENT_SUCCEEDED`.
7. UNCANNY processing begins only after native warmup.
8. Feature-18 create/evaluate work is not attempted until native presentation is healthy.
9. HOME opens without minimizing PCSX2, forcing Alt-Tab, stealing focus, or stopping Presents.
10. REVENANT remains unchanged.
11. PCSX2 exits cleanly without leaving an orphaned UNCANNY process.

Build, static regression and package-integrity checks are required before release, but they do not replace this final Windows/GPU retest.