# v0.20 ELYSIUM - legacy DirectX

ELYSIUM keeps the experimental legacy routes while tightening the rule that **DLSS 5 Active requires successful current Feature-18 output**, not just a provider file or initialized bridge.

| API | Route | Important limits |
|---|---|---|
| D3D9/Ex | Native legacy feeder, D3D9On12 when Windows/device support it, spatial fallback otherwise | Real Feature-18 return and game compatibility must be tested |
| D3D8 x86 | Existing translator is preserved if already present; UNCANNY only owns a translator it installed/verified | x86 only; may require `d3dx9_43.dll` from Microsoft DirectX End-User Runtimes (June 2010) |
| D3D10/10.1 | Native feeder/image path with HOME compositor | Conservative SDR/format gates; hardware acceptance required |
| D3D7/OpenGL/Vulkan | No completed native ELYSIUM release route | Not part of this release claim |

Unknown pre-existing `d3d8.dll` wrappers are retained byte-for-byte rather than overwritten. That protects existing mod stacks, but the wrapper may or may not provide a route UNCANNY can use.

No NVIDIA provider binary is bundled. See `PROVIDERS.md`.
