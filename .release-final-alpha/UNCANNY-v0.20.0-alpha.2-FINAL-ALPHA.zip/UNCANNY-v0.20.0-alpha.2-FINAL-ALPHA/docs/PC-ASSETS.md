# Checkpoint 2 technical-texture protection

Likely encoded normal maps are retained before photo inference. Detection is conservative and cannot identify every technical texture. Existing replacement files are not automatically removed. Confirm alpha, mip behavior and rendered output in your game.

# PC REVENANT experiments

REVENANT has real, bounded PC color-texture paths on D3D9/Ex and D3D11. They are off by default. This exact revision has not run inference or rendered game assets in the development environment.

1. Install UNCANNY and close the game.
2. Run `SETUP-PC-ASSETS.cmd` in the installed folder to obtain the separately licensed neural runner/models and enable the experiment.
3. Restart using the game's ordinary EXE and visit a repeatable gameplay scene.
4. Open HOME → REVENANT and the PC asset report. Compare capture, actual inference, validated files, GPU upload and draw evidence separately.

| Path | Eligible resource subset | Replacement behavior |
| --- | --- | --- |
| D3D9/Ex | Observed opaque color creation/CPU updates and validated full texture transfers | Rebuilt texture is bound for supported stage-0 draws; exact original binding is restored afterward |
| D3D11 | Initialized immutable opaque color textures with supported descriptors | Rebuilt views replace supported pixel-shader bindings; sampled direct draws provide additional binding evidence |

The supported color formats are RGBA/BGRA and opaque BC1/BC2/BC3, with source dimensions 64–1024 pixels and aspect ratio at most 4:1. The external Real-ESRGAN runner performs actual reconstruction, followed by material finishing. Output must decode at 4× dimensions and pass complete mip-chain, source/model identity and strength validation before upload. Original game assets are retained.

| Evidence | Meaning |
| --- | --- |
| Capture | Source color data was committed |
| Inference start | The actual external runner was started |
| Neural success | The runner completed and a correctly sized image decoded |
| Validated / committed | Rebuilt output and mip data passed validation |
| GPU upload | A replacement graphics resource was created |
| Binding / submitted draw | An observed graphics call used the replacement binding |
| Rendered use | Requires seeing the intended surface; counters alone remain NOT_VERIFIED |

An empty queue is possible when a game has no eligible resources. D3D11 DEFAULT/Map-streamed textures, D3D12 resource replacement, arbitrary shader semantics and universal live reload are not implemented. Alpha/UI/normal-map heuristics can be imperfect. Check text, characters, signage, high-frequency surfaces and moving objects before keeping the experiment enabled.

Replacement GPU ownership is bounded to 128 MiB per implemented PC texture adapter. There are additional capture/queue/cache limits, and optional work pauses under frame pressure. These limits do not measure total driver VRAM. Inference runs outside Present; work already running is not instantly preempted. Some surfaces require a level reload or restart to be observed again.

Turn off the experiment and restart for a complete original-resource comparison. Master OFF stops subsequent eligible substitution, but does not undo already committed emulator texture files. Holding Ctrl+Shift+Backspace compares live image/neural processing only; it leaves asset experiments separate.

## Experimental legacy materials

HOME → REVENANT has a separate D3D9 **experimental legacy materials** option. Restart to observe new resources. It handles a narrow opaque fixed-function mesh/material subset with directional lights and retains original geometry. Material validation, upload and submitted draws are reported separately. This is an observed material treatment, not semantic scene recovery or newly inferred normal/height/AO maps. Unrecognized layouts and rendering states are excluded.

For geometry, see the separate [D3D11 rigid-object experiment](RIGID-OBJECTS.md). PCSX2 continues to use its own dump/replacement/reload/index/visual diagnostic workflow; PPSSPP remains an offline pack path. Neither proves universal PC resource replacement.

Close the game before editing generated caches. Do not distribute captured game assets. See [verification](VERIFICATION.md) for the evidence needed to show remastered assets actually became visible.

Copyright © 2026 Coye Stillwagen. All rights reserved.

UNCANNY is an independent project and is not affiliated with or endorsed by NVIDIA. NVIDIA and DLSS are trademarks of NVIDIA Corporation.
