# Release Polish 6 — Checkpoint 2 acceptance

This is an experimental candidate, revision release-polish.6.2. Reinstall the complete package, with the game closed, so runtime and Deck match ABI 138. Select the current engine for these tests. Lucid intentionally uses the older RF5 components and UI.

Start the installed game's ordinary EXE. Newly created D3D9/Ex targets request the compatible Windows legacy neural route automatically. HOME → DLSS 5 shows provider, actual feature create/evaluate counts, returned neural frames and successful neural Presents separately. Configure Provider opens independently so you can close the game before installing matching provider components. Provider files are not bundled.

## Synthetic tests

Use the architecture matching the installed target. Run from the extracted release in PowerShell:

```powershell
.\RUN-GPU-ACCEPTANCE.ps1 -Architecture 64 -IncludeLegacyOn12 -Consent
.\RUN-GPU-ACCEPTANCE.ps1 -Architecture 64 -IncludeNeural9 -IncludeNeural11 -ProviderRoot 'C:\Games\Example' -Consent
.\RUN-GPU-ACCEPTANCE.ps1 -Architecture 64 -IncludeHomeProducer -IncludeFullscreenHome -ProviderRoot 'C:\Games\Example' -Consent
```

Use 32 for an x86 game. A single installed folder contains only its matching architecture. The producer test copies the supplied current Deck into an isolated temporary folder and checks real UI messages, scroll range, move/resize, cancellation and persistence through a restarted process. It does not modify your game profiles or panel preferences. Physical HOME tests use their own D3D11 window and can enter exclusive fullscreen. Physical wheel/game cursor capture still needs the real-game checklist below. Unsupported devices or providers must remain failures/unavailable, not passes.

## Real-game checklist

1. Start the normal installed EXE with its usual arguments/shortcut. Verify the original target and current runtime connect. Test game exit and restart.
2. In windowed and fullscreen modes, open/close/reopen HOME, including rapid taps. Confirm the game stays foreground, fullscreen and unminimized. If in-frame rendering fails, desktop fallback is shown without taking focus; explicitly switch to it to interact.
3. On Profiles, scroll to the last presets with the wheel/touchpad, drag the right-edge scrollbar, and use Page Up/Down and Tab. Confirm off-screen controls become accessible.
4. Drag the top title area. Resize with the bottom-right grip. Confirm the panel remains inside the current viewport and content adapts. Release the mouse, Alt+Tab mid-drag, return, and verify no stuck drag or game keys.
5. Change page and Advanced state, close/reopen the game, and check panel position/size/page/state. Repeat at 720p, 1080p, 1440p, 4K, ultrawide and relevant 100–200% DPI settings. Large/high-DPI panels may resample text; inspect legibility.
6. Exercise neural OFF/ON, Clean Stages, fast motion, scene cuts, HUD, particles, sky/fog and faces. For legacy neural proof require successful Feature-18 evaluation, return and successful Present counters in the same real session. A loaded provider alone is insufficient.
7. On eligible REVENANT assets, distinguish captured, reconstructed, committed, uploaded/bound and visibly rendered output. Test alpha/mips/technical maps, reload, cancellation and rollback. Existing counts do not certify the appearance of new assets.
8. Close the game, run UNCANNY-ENGINES.cmd in its installed folder, choose Lucid and start the same EXE. Repeat with Default/current. Confirm the engine shown by diagnostics and expected UI. Both are experimental; a successful startup is not neural or game certification.
9. Test uninstallation/rollback after closing the target. Keep all original/backups until originals are restored. If a file changed externally, resolve that conflict explicitly; do not delete the recovery files.

Record exact game/version, API, architecture, GPU/driver, provider/version/hash, engine revision, failures and video. No game is FULL until all advertised features pass its actual path. Windows/GPU tests were compiled but not executed in the development environment.

Known blockers: unproved D3D9/11/12 neural and fullscreen results, incomplete native motion/depth/reactive inputs, unmeasured quality/performance, unsupported D3D10/Vulkan/OpenGL enhancement, and missing generic D3D12 asset reconstruction. Official release remains blocked.

Copyright © 2026 Coye Stillwagen. All rights reserved.

UNCANNY is an independent project and is not affiliated with or endorsed by NVIDIA. NVIDIA and DLSS are trademarks of NVIDIA Corporation.
