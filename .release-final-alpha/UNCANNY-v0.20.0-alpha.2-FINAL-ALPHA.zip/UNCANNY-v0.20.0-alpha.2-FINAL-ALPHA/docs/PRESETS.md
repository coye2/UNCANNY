# Presets and engine identity

**ELYSIUM is an engine version, not a visual preset.** Presets/looks and UNCANNY PASSES tune the currently active engine and may be changed live. The Engine selector changes the actual binary engine build on the next launch.

# UNCANNY presets

Open HOME → Profiles. There are 38 distinct presets: 24 artistic looks and 14 coordinated presets.

Artistic looks adjust the image while retaining the selected quality budget, UNCANNY pass level and REVENANT strength. Coordinated presets also select a quality budget, UNCANNY pass level, denoise and photographic treatment. Both retain the independent master and DLSS switches. Unavailable API features stay unavailable, and presets do not enable the separate texture or rigid-object experiments.

Photoreal is an explicit photographic reinterpretation mode with UNCANNY 2.5 and strong artifact guards. It does not reconstruct an entire scene or guarantee photographic results. High Detail uses UNCANNY 3; Performance uses the smallest image-search budget. Names describe intended treatments, not verified visual results or measured FPS gains.

The image path now limits stacked detail, reduces alternating grain and keeps more shadow gradation. No preset has been visually certified for this exact Windows build. Check faces, hair, text, high-contrast edges and motion in your game. Hold Ctrl+Shift+Backspace while the game is focused to bypass live image/neural processing. Cached texture and object replacements stay active during this comparison; disable those separately to compare original assets.

## Coordinated presets

| Preset | Intended treatment |
| --- | --- |
| Natural | Source-faithful tone, moderate denoise, Balanced budget |
| Clean | UNCANNY 2.5, strong artifact guards and restrained color |
| Restored | Protected source detail, open shadows and Quality budget |
| Modern | Neutral modern response with balanced surface definition |
| Filmic | Muted film response, softer highlights and texture |
| Cinematic | Cool shadows, warm highlights and UNCANNY 2.5 guards |
| Photoreal | Explicit photographic reinterpretation; strongest guarded budget |
| High Detail | Source-supported detail, UNCANNY 3, protected edges |
| Retro Restore | Preserve graphic lines and flat colors; modest restoration |
| Dark Cinema | Low-key photographic tone with retained shadow gradation |
| Color Rich | Deliberately vivid color with restrained edge energy |
| Neutral | Neutral grading, subtle restoration and no extra sharpening |
| Competitive | Open shadows and guarded low-cost reconstruction |
| Performance | Smallest search budget; minimal optional detail work |

## Artistic looks

| Preset | Intended treatment |
| --- | --- |
| True to Life | Neutral color, restrained detail, preserved highlights |
| Silver Screen | Cool cinema, softer color, deeper shadows |
| Golden Hour | Amber daylight with warm highlights and open shadows |
| Midnight Blue | Cool, low-key night atmosphere |
| Velvet Noir | Black-and-white noir with pronounced contrast |
| Silver Portrait | Gentle monochrome with lifted shadow detail |
| Bleach Bypass | Desaturated, hard-edged dramatic contrast |
| Vintage Print | Muted warm film with faded blacks |
| Desert Heat | Warm, dry color and crisp sunlit detail |
| Arctic Glass | Icy blue-white color with clean contrast |
| Emerald World | Rich natural color and softer highlight rolloff |
| Neon Arcade | Saturated, cool arcade color with bold contrast |
| Candy Pop | Bright playful color and soft shadow lift |
| Anime Cel | Clear color with strong line and flat-area protection |
| Watercolor Light | Soft pastel color, lifted blacks, gentle detail |
| Retro Revival | Warm, vivid retro color with protected pixel edges |
| Modern Remaster | Neutral, crisp restoration with visible texture detail |
| Stone and Steel | Cool, desaturated industrial texture emphasis |
| Soft Focus Cinema | Warm subdued color with gentle surface detail |
| Moonlit Horror | Cold, dark tension with reduced saturation |
| Daybreak | Airy, warm brightness with open shadow detail |
| Competitive Clear | Neutral color, bright shadows and restrained sharpening |
| Museum Restore | Subtle restoration that stays close to source art |
| High Drama | Strong contrast and rich color with controlled highlights |

Watercolor and Soft Focus are image parameter treatments; they do not add paint simulation or lens depth of field. Edited values save with the executable profile; the selected preset name itself is not persisted.
