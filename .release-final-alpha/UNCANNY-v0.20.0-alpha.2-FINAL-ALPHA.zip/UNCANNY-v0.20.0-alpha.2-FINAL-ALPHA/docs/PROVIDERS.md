# DLSS 5 provider setup

Repair 7 performs local-first provider discovery during installation. Normal setup no longer requires guessing a DLL in a file picker. It checks the target, the most recently installed UNCANNY target (including its `.uncanny/host64` helper directory), known local provider locations and the NVIDIA driver before using the network. Every reused DLL is revalidated for architecture and required exports. `SETUP-DLSS5.cmd` repeats this operation with the game closed; `UNCANNY-PROVIDERS.cmd` is an alias.

Two different roles are needed: the DLSS 5 rendering component (`nvngx_dlssnr.dll`) and a compatible NVIDIA driver core (`_nvngx.dll`). Super-resolution, Ray Reconstruction and UNCANNY's own bridge DLLs are not interchangeable with the rendering component. PE export and architecture checks reject incompatible roles without loading them during discovery.

An x86 game cannot load an x64 DLL. This build places x64 provider components in `.uncanny/host64` and uses `UNCANNY.NeuralHost64.exe` for that experimental route. Native x64 D3D11/D3D12 games keep their existing in-process path. v0.20 ELYSIUM also installs this isolated helper/provider directory for x64 games because the new native D3D9/D3D10 fallback uses it without sharing the in-process provider. Reinstall the complete package to stage the matching helper; copying provider DLLs alone cannot add it.

If no local rendering component is found, setup tries the fixed community RHI release in `config/provider-catalog.json`. Its URL and SHA-256 are pinned; arbitrary mirrors and mutable latest-version links are not used. The metadata came from the upstream release asset list. This is not an official NVIDIA installer or endorsement. No NVIDIA DLL is included in the UNCANNY ZIP. A matching hash is an integrity check, not a malware scan or proof of driver compatibility.

The driver core must come from the installed NVIDIA driver. UNCANNY does not silently change your system driver or fetch core DLLs from mirror sites. Missing core produces `NVIDIA_DRIVER_CORE_MISSING_UPDATE_DRIVER`. Missing render component/network failure produces an explicit setup status; image-only operation remains available. File discovery never marks inference as passed.

Local setup receipts may contain user paths; review/redact before sharing. Set `-OfflineProviders` on `INSTALL-NATIVE.ps1` to prohibit download fallback. Use normal installation rollback to restore previous files. Preserve `.uncanny` backups.
