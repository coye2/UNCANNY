# UNCANNY v0.20.0-alpha.2 — FINAL ALPHA

This is the last alpha checkpoint before beta. It freezes the exact runtime source candidate `748f80b6a63f64bc811479b185e00dc45d34c373` rather than pulling in the later recovered DLSS5 development work.

## Verified in the exact candidate

- x86/x64 production builds and package integrity passed.
- D3D11 rigid geometry: controlled fixture changed real vertex/index buffers, 48 -> 120 triangles and 39 -> 216 stored vertices, with rasterized depth change.
- Corrected oblique silhouette error improved from 4,464 to 3,816 pixels against an independent analytic reference.
- Normal-only recovery changed normal buffers while depth stayed bit-exact.
- Material isolation: 65,536 selected pixels rendered pure magenta, 65,536 unrelated pixels remained byte-identical, and disabling the replacement restored the original buffer exactly.
- Detail governor: overshoot 0.0391917 -> 0.0129333; flat-region variance 0.00182544 -> 0.000234787 in the controlled fixture.
- Water response was measurable but subtle (maximum float-channel delta about 0.000303).
- Motion/temporal, Windows, GPU/provider, research and flagship test records completed successfully in CI run `35683346915`.

## Deliberate limits

These are controlled fixtures, not real-game certification. No approved game geometry profile ships. Universal auto-tessellation, source-derived rock/gravel displacement, animated replacement, dramatic water geometry and the post-candidate recovered DLSS5 bridge are not part of this release.

## Runtime identity

BuildId: `elysium45-hf18.14`  
ABI: `143`  
Runtime revision: `release-alpha.1.elysium-engine45-hf18.14-recovery.2`
