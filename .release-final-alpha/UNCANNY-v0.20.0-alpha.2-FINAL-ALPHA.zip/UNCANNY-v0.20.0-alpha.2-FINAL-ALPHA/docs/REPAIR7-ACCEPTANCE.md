# Repair 7: installation and acceptance

Revision: `release-repair.7`. Runtime ABI: 138. Status: **hardware acceptance required; not an official stable release**.

## Install

Close the game and its UNCANNY panel. Extract the complete Repair 7 public ZIP to a new folder. Drag the game's original EXE onto `INSTALL-NATIVE.cmd` (an existing UNCANNY-managed EXE can be upgraded by this installer). Do not manually copy only one DLL over an older build.

The installer snapshots every selected provider before conflict quarantine, including an already-compatible provider that does not need an upgrade. This prevents cleanup from removing a dependency the plan had incorrectly skipped.

The installation searches the target folder, UNCANNY/RHI/provider caches, NVIDIA driver locations and known Steam libraries for compatible x64 provider components. If no rendering provider is found, it attempts the fixed release listed in `config/provider-catalog.json`, verifies its SHA-256 and extracts only the expected DLL. It does not fetch arbitrary search results or change the system NVIDIA driver. Internet failures preserve the image-only path and an explicit missing-provider status. `-OfflineProviders` disables network fallback in the PowerShell installer.

For a 32-bit game, the installer deploys the x64 bridge, providers and `UNCANNY.NeuralHost64.exe` under `.uncanny/host64`. The x86 runtime does not load a 64-bit DLL. For a 64-bit game, the existing in-process bridge path is retained. Provider discovery is not proof of a successful neural evaluation. The driver core must be available from a compatible installed NVIDIA driver.

Start the game normally from its EXE. Inspect `.uncanny/provider-state.json` for setup status. It may contain local paths: redact before sharing. The legacy `UNCANNY-PROVIDERS.cmd` now opens automatic setup rather than the manual DLL chooser. Setup must run with the game closed.

## First check: menu and ghost guard

Open Home, move the mouse away from the center, click each page, scroll, drag the title bar, resize the bottom-right corner, and close/reopen ten times. Repeat after Alt+Tab and a resolution change. Confirm the game regains its mouse on close. Do not mark this passed from a counter or screenshot of a stationary menu.

In the exact scene where blocks appeared, compare Guard OFF and ON while moving. Try image-only and combined DLSS 5 modes. Repair 7 no longer uses coarse flow/history cells to choose between differently graded final pixels. The final guard uses a continuous current-frame neural-residual limiter. This is a conservative safeguard, not semantic HUD extraction or a new learned model. Explicit HUD corner protection still bypasses whole rectangular regions, including any scene content there. Check text, minimap, sky and faces.

## Separate transport from actual DLSS 5

From the public package directory:

```powershell
powershell -NoProfile -ExecutionPolicy Bypass -File .\RUN-NEURAL-HOST-TEST.ps1 -Architecture both -Consent
```

This runs an x86 client and x64 client against the real x64 helper on the same D3D12 adapter. It checks repeated exact shared-copy pixels and a resized session. **It deliberately never calls a NVIDIA provider. PASS does not mean DLSS 5 works.** Lack of a suitable device/transport returns UNAVAILABLE or FAIL, not invented success.

Then, with the game closed, run the current synthetic tests from the public package:

```powershell
powershell -NoProfile -ExecutionPolicy Bypass -File .\RUN-GPU-ACCEPTANCE.ps1 -Architecture both -Consent -IncludeLegacyOn12 -IncludeNeural9 -IncludeNeural11 -IncludeCursor -ProviderRoot 'C:\Path\To\InstalledGame'
```

The optional cursor test opens its own foreground window and checks production warp/confinement suppression and restoration. It does not certify every game's raw-input/DirectInput behavior. The neural tests require the installed providers, compatible driver/GPU and Windows On12/shared-fence support. They must show real Feature-18 create/evaluate success and usable returned output. Keep their individual failures visible.

Finally, test the actual 32-bit D3D9 game, a D3D11 game, the known-working D3D12 game and PCSX2. Use the exact same binary set and record the active engine. Test Master OFF/ON, resize/reset, fullscreen, exit and rollback. The preserved Lucid engine uses its old ABI 136 implementation and does not gain Repair 7's helper or cursor fixes.

## Performance and limits

The first cross-process helper implementation favors bounded, exact-current-frame correctness. The parent waits up to 100 ms for a current result; a missed deadline retains source and discards that late result. There is no stale-frame reuse, but this is **not a low-latency or FPS-parity guarantee**. Cold initialization may cause bypassed neural frames. Measure actual frame times before endorsing this route.

No generic native MV/depth/reactive acquisition, D3D10/Vulkan/OpenGL enhancement, universal D3D12 REVENANT, broad PBR/geometry reconstruction or universal game compatibility is claimed. Existing REVENANT paths remain bounded and require visible-use checks. No original NVIDIA model is included.

## Recovery

Use `ROLLBACK-NATIVE.ps1` for the installed game, preserving its `.uncanny` backup and journal directories. Do not delete backups to troubleshoot a failed install. Do not manually swap providers while the game or helper is running. If setup cannot find the NVIDIA driver core, update the driver through its normal trusted distribution; never download a random `_nvngx.dll` from a DLL mirror.

Run `UNCANNY-ACCEPTANCE.cmd` for a consent-based local evidence report. It records revision/ABI from the runtime and hashes the actual on-disk bridge/helper names; file hashes are not loaded-module proof. The collector supports explicit current and historical revisions and rejects unknown layouts.
