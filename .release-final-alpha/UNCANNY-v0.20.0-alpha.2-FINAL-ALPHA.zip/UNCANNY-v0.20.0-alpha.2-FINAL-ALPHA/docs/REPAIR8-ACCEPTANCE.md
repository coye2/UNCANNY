# Repair 8 — Windows acceptance and recovery

Revision: `release-repair.8`; ABI 138. Status: **HARDWARE ACCEPTANCE REQUIRED, NOT OFFICIAL**.

This build contains source repairs and cross-compiled Windows binaries. Portable logic tests ran on the build host. Compiled Windows tests are not evidence of WIC, driver interoperability, physical input or rendered output execution.

## Optional codec/ownership smoke test

From the fresh extracted public package, run `RUN-REPAIR8-CHECKS.cmd`. It prompts for consent, verifies diagnostic hashes, and runs the compiled x86/x64 WIC/ownership fixtures with a 60-second timeout per executable. It touches only test-owned temporary files, not game textures. Reports are saved locally. Passing this does not establish actual game rendering or NVIDIA inference.

## 1. Confirm the exact runtime

Install a fresh complete Repair 8 extraction with the game closed. Keep the Default/current engine for this test. Read the exported status report and verify `Revision=release-repair.8`, `ABI=138`, a current heartbeat and advancing Present counter. Previous Lucid ABI 136 is intentionally different and lacks Repair 8 fixes.

## 2. Restore an already-corrupted PCSX2 replacement set

1. Preserve the texture folder. Open the connected in-game REVENANT page.
2. Click **Restore original game textures…**, then confirm within ten seconds. The command is only offered with the existing supported worker control path; a connected worker and active game identity are required.
3. Generation is paused and proof/rebuild cancellation requested. The request carries the selected game serial; a changed/unknown active serial blocks restoration. The worker resolves existing proof journals first, then copies each receipt-owned output into `<texture root>/<serial>/.uncanny-quarantine/<transaction>/...`.
4. The copy must hash-match its ownership receipt before the original is removed. The original is opened with sharing that denies concurrent writes/deletes; busy files are retained. Unknown/user-modified outputs are not removed.
5. Close the panel so the emulator may receive the reload input. Read `.uncanny/restore-assets-<PID>.result.txt`. A request is not success; verify its result and the scene.
6. If restoration cannot run or the scene stays corrupted, close the game, temporarily disable PCSX2 texture replacement loading, restart and compare. Do not delete user textures. Compare with UNCANNY/DLSS processing off as a separate isolation test.

Quarantined bytes are retained as verified backups, not automatically loaded. There is no one-click re-enable-quarantined-assets button. A hand-edited or busy file may require manual review. Restoring here means allowing the emulator to use its original game assets, not overwriting game archives.

## 3. Re-enable reconstruction cautiously

Once the original scene is clean, re-enable REVENANT and observe a small set. Confirm real inference counters, new files, reload state, and visible source-faithful surfaces. Test color-coded patterns, foliage alpha, signs, faces and repeating texture detail. Safety gates are heuristics: they may reject a legitimate enhancement or miss a subtle corruption. Visible proof remains separate from generated-file counts.

An unchanged source must settle for two seconds. Inference reads a separate PNG snapshot, whose encoder roundtrip must match. A source that changes during processing is deferred. Large color/alpha changes or unsupported noisy detail reject the new asset. Restore does not automatically resume rebuilding.

## 4. Fullscreen and frame scheduling

Run the same scene in windowed, borderless and fullscreen. Repeat Alt+Tab, resize and mode changes. Test DLSS off/on, Clean Stages, Ghosting Guard and protected HUD regions. Record present/evaluation/bypass counters and GPU timing.

The new recorder selects a completed slot; it never resets a busy allocator. Under sustained saturation all slots can still be busy and the source bypass remains. This is not a promise that every cause of blinking is eliminated. More slots use extra GPU memory. No FPS improvement has been measured here.

Verify D3D9On12 resource returns/presents, D3D11 shared-fence completion and the known-good PCSX2/native-D3D12 route. Run the existing GPU acceptance suite; accept only current-version results with actual execution evidence. The x64-helper transport-only test does not execute NVIDIA inference.

## 5. Controls and engine selection

Home must open/close repeatedly without unwanted focus changes. Test wheel/scrollbar, drag/resize, saved position, mouse movement, click targeting, keyboard navigation and return of game input on close.

Expand **Select engine** on Home. Default/current and the installed real Lucid bundle are the only functional generations. The checkmark records the next-launch preference; it is not a claim that the running binary changed instantly. Exit and relaunch; confirm the actual ABI/revision. Return to current using the desktop engine manager if an older runtime cannot show the new picker.

## 6. Public-release blockers

Actual Windows/NVIDIA/game verification; repeatable corruption-free replacements; frame-pacing measurements; legacy neural create/evaluate/return/present proof; physical controls; safe rollback. Broad native input recovery, generic D3D12 REVENANT, universal emulator replacement, general PBR/scene rebuilding and instantaneous historical-runtime swapping remain incomplete features, not merely pending tests.

No competitor-quality, 60-FPS, photorealism or universal-compatibility certification is made.
