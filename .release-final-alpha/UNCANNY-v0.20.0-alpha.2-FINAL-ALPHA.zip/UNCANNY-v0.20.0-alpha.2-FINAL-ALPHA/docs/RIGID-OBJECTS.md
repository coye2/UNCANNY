# Experimental rigid objects

This alpha includes one narrow D3D11 geometry path. It can capture eligible immutable position/normal/UV meshes, make a small curvature-based shape change, validate it, cache it and submit replacement geometry. It is disabled by default. Most layouts, animated characters, instancing, deferred rendering and other APIs are outside this experiment.

The CPU reconstruction test passes. The compiled Windows test has not been executed in the development environment. No game has verified visible geometry improvement for this revision.

## Try the controlled test first

Run `RUN-GPU-ACCEPTANCE.cmd` from the extracted candidate. The Geometry entry runs separately for x86 and x64 with a timeout. It exercises the production capture and replacement path on a controlled curved prop using the Windows WARP software device.

A successful execution saves original/reconstructed/restored BMPs, two wireframe BMPs and a JSON result with changed-depth counts and hashes. It checks actual rasterized depth changes, exact original restoration, persistent cache reuse, corrupt-cache rejection and an unsupported instance draw. These outputs are created only when the test runs; they are not pre-generated evidence. PASS is limited to that fixture and architecture.

## Try an explicitly selected D3D11 game

1. Install the full candidate and launch the installed game EXE. Open HOME → REVENANT.
2. Enable experimental rigid objects, close the game and restart its normal EXE. This allows creation-time capture.
3. Revisit a stable scene for at least 30 displayed frames. Captured, validated, uploaded and submitted counters are separate cumulative events. More vertices or submitted draws alone do not prove visible improvement.
4. Open the rigid-object report for rejection or unavailable information. Capture the same camera/scene with the experiment enabled and disabled. Check edges, attachments, textures, shadows, reflections and motion.
5. Disable the experiment to return to original draws. The setting is polled within roughly half a second when the worker is idle; a bounded current job can delay polling. Master OFF bypasses geometry immediately on subsequent draws. Original buffers are never overwritten.

Hold Ctrl+Shift+Backspace compares live image/neural processing only. It leaves cached geometry and textures active. Disable their separate controls for an original-asset comparison.

## Limits

Open boundaries, UV seams and original corner positions remain fixed. Shape changes are small; this is not whole-object redesign, semantic restoration or an AI model generating new weapons or characters. Original shader/constants/material bindings remain in use, and their semantic meanings are unknown.

Observed shader/layout changes or unsupported direct draws quarantine a shared vertex resource. Observed deferred command-list execution blocks this experiment for the process until restart. Pass completeness is still unknown: different resources may represent related shadow, reflection or motion passes. No animation, physics or attachment compatibility is certified. Treat visual mismatch as a failed game test and disable the experiment.

Capture and reconstruction are bounded. At most eight draw entries are retained, with 64 MiB CPU capture and 64 MiB owned replacement GPU limits. Persistent mesh data has a 128 MiB / 64-entry budget per installed folder. New work pauses under the existing frame-time governor. This is not a measurement of total VRAM or a performance guarantee. A full live-entry set stops new captures until restart.

Cache identities change with the game executable, runtime binary, shader programs and source content. Only validated cache data is accepted; invalid data is regenerated from captured originals and revalidated. Closing the game and deleting its `.uncanny/rigid-cache` removes only this experimental cache. Do not redistribute captured game assets.

Copyright © 2026 Coye Stillwagen. All rights reserved.

UNCANNY is an independent project and is not affiliated with or endorsed by NVIDIA. NVIDIA and DLSS are trademarks of NVIDIA Corporation.
