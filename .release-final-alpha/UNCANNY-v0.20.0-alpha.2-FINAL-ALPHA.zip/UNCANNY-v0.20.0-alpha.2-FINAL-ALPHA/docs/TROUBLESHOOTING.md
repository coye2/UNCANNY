# UNCANNY Final Alpha troubleshooting

Current distribution: `v0.20.0-alpha.2 FINAL ALPHA`  
Runtime BuildId: `elysium45-hf18.14` / ABI `143`.

## Game does not launch or attach

Confirm you selected the real rendering executable and installed the complete package. Run `Tools/UNCANNY-STATUS.cmd` and keep the launch/runtime logs. Do not copy individual DLLs from another release.

## HOME / Control Deck missing

First verify the native presentation stream is alive and the runtime actually attached. A provider file on disk or a worker process is not enough.

## DLSS 5 says waiting

Provider discovery/readiness is separate from Feature-18 creation/evaluation and presented output. This Final Alpha intentionally does not include the later recovered bridge work.

## REVENANT counters but no visible change

Capture/inference/commit and visible replacement are separate. The controlled rigid/material tests prove the admitted fixture path only; no universal game profile is implied.

## Rollback

Close the target before rollback. Preserve `.uncanny` backups and retained conflict evidence. The rollback path does not overwrite a user-modified conflict silently.
