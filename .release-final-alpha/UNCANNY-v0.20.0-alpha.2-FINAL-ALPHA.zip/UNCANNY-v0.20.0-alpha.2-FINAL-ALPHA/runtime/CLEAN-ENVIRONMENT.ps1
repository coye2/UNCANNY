﻿param([Parameter(Mandatory=$true)][string]$TargetDir,[switch]$Clean,[string]$BackupRoot='')
$ErrorActionPreference='Stop'
. (Join-Path (Split-Path -Parent $MyInvocation.MyCommand.Path) 'UNCANNY-InstallCommon.ps1')
. (Join-Path (Split-Path -Parent $MyInvocation.MyCommand.Path) 'UNCANNY-Environment.ps1')
if($Clean){$names=@(Get-ChildItem -LiteralPath $TargetDir -Filter '*.exe' -File|ForEach-Object Name);Assert-UncannyClosed $TargetDir $names;Clear-UncannyEnvironment $TargetDir $BackupRoot|ConvertTo-Json -Depth 12}else{Get-UncannyEnvironment $TargetDir|ConvertTo-Json -Depth 12}
