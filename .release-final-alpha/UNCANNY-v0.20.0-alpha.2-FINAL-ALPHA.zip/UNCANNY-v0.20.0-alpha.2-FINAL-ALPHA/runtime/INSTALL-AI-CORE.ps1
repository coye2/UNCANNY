﻿[CmdletBinding(DefaultParameterSetName='Directory')]
param(
  [Parameter(Mandatory=$true,ParameterSetName='Directory')][string]$TargetDir,
  [Parameter(Mandatory=$true,ParameterSetName='Installed')][switch]$RepairInstalledTarget,
  [switch]$ForceRepair
)
Set-StrictMode -Version Latest
$ErrorActionPreference='Stop'
. (Join-Path (Split-Path -Parent $MyInvocation.MyCommand.Path) 'UNCANNY-InstallCommon.ps1')
if($RepairInstalledTarget){
  $record=Join-Path $env:LOCALAPPDATA 'UNCANNY/last-native-target.txt'
  $TargetDir=Resolve-UncannyNeuralRepairTarget $env:UNCANNY_AI_TARGET_EXE $env:UNCANNY_PACKAGE_ROOT $record
  . (Join-Path (Split-Path -Parent $MyInvocation.MyCommand.Path) 'UNCANNY-Environment.ps1')
  Stop-UncannyOrphanCompanions $TargetDir
  Assert-UncannyClosed $TargetDir @()
}
$TargetDir=Resolve-UncannySetupTarget $TargetDir
Assert-UncannyNoReparsePath (Join-Path $TargetDir '.uncanny/ai/realesrgan')
Write-Host ('NeuralCoreTargetDirectory='+$TargetDir)
$state = Join-Path $TargetDir '.uncanny\ai'
$dest = Join-Path $state 'realesrgan'
$exe = Join-Path $dest 'realesrgan-ncnn-vulkan.exe'
$modelParam = Join-Path $dest 'models\realesrgan-x4plus.param'
$modelBin = Join-Path $dest 'models\realesrgan-x4plus.bin'
$expectedArchive = 'abc02804e17982a3be33675e4d471e91ea374e65b70167abc09e31acb412802d'
$url = 'https://github.com/xinntao/Real-ESRGAN/releases/download/v0.2.5.0/realesrgan-ncnn-vulkan-20220424-windows.zip'
$expectedFiles = @{
    'realesrgan-ncnn-vulkan.exe'='07e49f7cbb4ede01ae4dd4c399d3a7e5846e3d2085c3128eff881e55cb7b1a0c';
    'models\realesrgan-x4plus.param'='35330ececcea33b6c397a72548e788d5d53becee4734c50b7fada36e89f10a86';
    'models\realesrgan-x4plus.bin'='713ee713b0353afaa27976f0563a64a5043bd70b9bd8936c2e26e25ebcdbcddf';
    'vcomp140.dll'='8f72ef2e483465444b2059fc6744d6cb22cd8d8a27f6fa56befd2a42dcd0f78b'
  }
function Test-NeuralCore([string]$base,[switch]$Quiet){
  $checks = @(
    @{ Name='runner'; Path=(Join-Path $base 'realesrgan-ncnn-vulkan.exe'); Min=6000000 },
    @{ Name='x4plus param'; Path=(Join-Path $base 'models\realesrgan-x4plus.param'); Min=116029 },
    @{ Name='x4plus bin'; Path=(Join-Path $base 'models\realesrgan-x4plus.bin'); Min=33424520 }
  )
  $missing=@()
  foreach($c in $checks){
    if(!(Test-Path -LiteralPath $c.Path -PathType Leaf)){ $missing += "$($c.Name): missing"; continue }
    if((Get-Item -LiteralPath $c.Path).Length -lt [int64]$c.Min){ $missing += "$($c.Name): truncated" }
  }
  if($missing.Count){
    if(!$Quiet){ $missing | ForEach-Object { Write-Host "  $_" -ForegroundColor Yellow } }
    return $false
  }
  foreach($rel in $expectedFiles.Keys){
    $fp=Join-Path $base $rel
    if(!(Test-Path -LiteralPath $fp -PathType Leaf) -or (Get-FileHash -LiteralPath $fp -Algorithm SHA256).Hash -ine $expectedFiles[$rel]){
      if(!$Quiet){Write-Host "  Hash verification failed: $rel" -ForegroundColor Yellow}
      return $false
    }
  }
  return $true
}
New-Item -ItemType Directory -Force -Path $state | Out-Null
if(!$ForceRepair -and (Test-NeuralCore $dest -Quiet)){
  Write-Host 'NEURAL ASSET CORE: verified runner + realesrgan-x4plus model already installed.' -ForegroundColor Green
  exit 0
}
if(Test-Path -LiteralPath $dest){
  Write-Host 'NEURAL ASSET CORE: existing install is incomplete; repairing transactionally...' -ForegroundColor Yellow
  [void](Test-NeuralCore $dest)
}else{
  Write-Host 'NEURAL ASSET CORE: installing verified Real-ESRGAN NCNN core...' -ForegroundColor Magenta
}
$cacheRoot = Join-Path $env:LOCALAPPDATA 'UNCANNY\NeuralCache'
New-Item -ItemType Directory -Force -Path $cacheRoot | Out-Null
$zip = Join-Path $cacheRoot 'realesrgan-ncnn-vulkan-20220424-windows.zip'
$tmp = Join-Path $state ('extract-'+[guid]::NewGuid().ToString('N'))
$stage = Join-Path $state ('realesrgan.stage-'+[guid]::NewGuid().ToString('N'))
$old = Join-Path $state ('realesrgan.old-'+[guid]::NewGuid().ToString('N'))
$partial = Join-Path $cacheRoot ('download-'+[guid]::NewGuid().ToString('N')+'.partial')
$installed=$false
try {
  [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
  if(Test-Path -LiteralPath $zip){
    $cachedHash=(Get-FileHash -LiteralPath $zip -Algorithm SHA256).Hash.ToLowerInvariant()
    if($cachedHash -eq $expectedArchive){
      Write-Host 'NEURAL ASSET CORE: verified package cache hit.' -ForegroundColor Green
    } else {
      Remove-Item -LiteralPath $zip -Force
    }
  }
  if(!(Test-Path -LiteralPath $zip)){
    Write-Host 'NEURAL ASSET CORE: downloading pinned v0.2.5.0 portable package...' -ForegroundColor Magenta
    Invoke-WebRequest -UseBasicParsing -Uri $url -OutFile $partial -TimeoutSec 120
    if((Get-Item -LiteralPath $partial).Length -ne 45474481 -or (Get-FileHash -LiteralPath $partial -Algorithm SHA256).Hash -ine $expectedArchive){throw 'Downloaded neural archive failed pinned size/hash verification.'}
    Move-Item -LiteralPath $partial -Destination $zip -Force
  }
  if((Get-Item -LiteralPath $zip).Length -ne 45474481){ throw "Real-ESRGAN archive size mismatch. Expected 45474481 bytes." }
  $got=(Get-FileHash -LiteralPath $zip -Algorithm SHA256).Hash.ToLowerInvariant()
  if($got -ne $expectedArchive){throw "Real-ESRGAN archive SHA256 mismatch. Expected $expectedArchive, got $got"}
  Expand-Archive -LiteralPath $zip -DestinationPath $tmp -Force
  $found=Get-ChildItem -LiteralPath $tmp -Filter 'realesrgan-ncnn-vulkan.exe' -File -Recurse | Select-Object -First 1
  if(!$found){throw 'Pinned Real-ESRGAN executable was not present in archive.'}
  $srcRoot=$found.Directory.FullName
  New-Item -ItemType Directory -Force -Path $stage | Out-Null
  Copy-Item -Path (Join-Path $srcRoot '*') -Destination $stage -Recurse -Force
  if(!(Test-NeuralCore $stage)){throw 'Pinned package extracted, but the realesrgan-x4plus model set is incomplete.'}
  foreach($rel in $expectedFiles.Keys){
    $fp=Join-Path $stage $rel
    if(!(Test-Path -LiteralPath $fp -PathType Leaf)){ throw "Verified runtime file missing: $rel" }
    $fh=(Get-FileHash -LiteralPath $fp -Algorithm SHA256).Hash.ToLowerInvariant()
    if($fh -ne $expectedFiles[$rel]){ throw "Verified runtime file hash mismatch: $rel" }
  }
  if(Test-Path -LiteralPath $dest){ Move-Item -LiteralPath $dest -Destination $old }
  try {
    Move-Item -LiteralPath $stage -Destination $dest
  } catch {
    if((Test-Path -LiteralPath $old) -and !(Test-Path -LiteralPath $dest)){ Move-Item -LiteralPath $old -Destination $dest -ErrorAction SilentlyContinue }
    throw
  }
  if(!(Test-NeuralCore $dest -Quiet)){throw 'Neural core failed verification after transactional install.'}
  $exeHash=(Get-FileHash -LiteralPath $exe -Algorithm SHA256).Hash.ToLowerInvariant()
  $paramHash=(Get-FileHash -LiteralPath $modelParam -Algorithm SHA256).Hash.ToLowerInvariant()
  $binHash=(Get-FileHash -LiteralPath $modelBin -Algorithm SHA256).Hash.ToLowerInvariant()
  @"
UNCANNY Alpha Neural Asset Core
Engine=Real-ESRGAN-ncnn-vulkan
Version=0.2.5.0-portable-20220424
ArchiveSHA256=$expectedArchive
RunnerSHA256=$exeHash
X4PlusParamSHA256=$paramHash
X4PlusBinSHA256=$binHash
Source=$url
Installed=$(Get-Date -Format o)
Status=VERIFIED-OFFICIAL-PORTABLE+X4PLUS-MODEL
"@ | Set-Content -LiteralPath (Join-Path $state 'NEURAL-CORE.txt') -Encoding UTF8
  $installed=$true
  Write-Host 'NEURAL ASSET CORE: VERIFIED runner + x4plus model installed.' -ForegroundColor Green
}
finally {
  Remove-Item -LiteralPath $tmp -Recurse -Force -ErrorAction SilentlyContinue
  Remove-Item -LiteralPath $stage -Recurse -Force -ErrorAction SilentlyContinue
  Remove-Item -LiteralPath $partial -Force -ErrorAction SilentlyContinue
  if(Test-Path -LiteralPath $old){Write-Warning "Previous neural core retained for recovery: $old"}
}
