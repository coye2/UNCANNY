﻿param(
  [Parameter(Mandatory=$true)][string]$Target,
  [switch]$SkipBuild,[switch]$ForceRebuild,[switch]$CleanEnvironment=$true,
  [string]$PCSX2DataDir='',
  [string]$NeuralRuntimeDir='',
  [switch]$OfflineProviders,
  [switch]$LegacyDirectX,[switch]$TranslateD3D8,
  [string]$ProgressFile=''
)
Set-StrictMode -Version Latest
$ErrorActionPreference='Stop'
$runtimeRoot=[IO.Path]::GetFullPath((Split-Path -Parent $MyInvocation.MyCommand.Path))
$runtimeParent=[IO.Path]::GetFullPath((Split-Path -Parent $runtimeRoot))
if($env:UNCANNY_PACKAGE_ROOT -and (Test-Path -LiteralPath (Join-Path $env:UNCANNY_PACKAGE_ROOT 'VERSION.json') -PathType Leaf)){
  $root=[IO.Path]::GetFullPath($env:UNCANNY_PACKAGE_ROOT)
}elseif(Test-Path -LiteralPath (Join-Path $runtimeRoot 'VERSION.json') -PathType Leaf){
  $root=$runtimeRoot
}elseif(Test-Path -LiteralPath (Join-Path $runtimeParent 'VERSION.json') -PathType Leaf){
  $root=$runtimeParent
}else{
  throw ('UNCANNY package root could not be resolved from runtime path: '+$runtimeRoot)
}
function Write-UncannyInstallProgress([int]$Percent,[string]$Stage){if(!$ProgressFile){return};try{[IO.File]::WriteAllText($ProgressFile,([Math]::Max(0,[Math]::Min(100,$Percent))).ToString()+'|'+($Stage -replace '[\r\n|]',' '),[Text.UTF8Encoding]::new($false))}catch{}}
Write-UncannyInstallProgress 2 'Validating target'
$version=Get-Content -LiteralPath (Join-Path $root 'VERSION.json') -Raw|ConvertFrom-Json
$packageMetaPath=Join-Path $root 'PACKAGE-REVISION.json'
$packageMeta=if(Test-Path -LiteralPath $packageMetaPath){Get-Content -LiteralPath $packageMetaPath -Raw|ConvertFrom-Json}else{$null}
$packageRevision=if($packageMeta -and $packageMeta.revision){[string]$packageMeta.revision}else{[string]$version.revision}
$packageBuildId=if($packageMeta -and $packageMeta.PSObject.Properties['buildId'] -and $packageMeta.buildId){[string]$packageMeta.buildId}else{$packageRevision}
. (Join-Path $runtimeRoot 'UNCANNY-InstallCommon.ps1')
. (Join-Path $runtimeRoot 'UNCANNY-Environment.ps1')
. (Join-Path $runtimeRoot 'UNCANNY-ProviderCommon.ps1')
Write-UncannyInstallProgress 3 'Resolving target path'
$exe=(Resolve-Path -LiteralPath $Target).Path;$dir=Split-Path -Parent $exe;$name=[IO.Path]::GetFileName($exe)
$isPCSX2=$name -ieq 'pcsx2-qt.exe'
Write-UncannyInstallProgress 4 'Validating existing install state'
$launchPlan=Get-UncannyLaunchTarget $exe;$actual=$launchPlan.Actual;$actualSHA256=[string]$launchPlan.ActualSHA256;$legacyOriginal=[string]$launchPlan.LegacyOriginal;$legacyMigration=[bool]$launchPlan.LegacyMigration;$sidecar=[string]$launchPlan.Launcher
Write-UncannyInstallProgress 5 'Inspecting target executable'
$targetInfo=Get-UncannyTargetPeInfo $actual;$suffix=$targetInfo.Architecture
if($env:OS -eq 'Windows_NT' -and ![Environment]::Is64BitOperatingSystem){throw 'UNCANNY requires 64-bit Windows. It supports both x86 and x64 games on that system; no target file was changed.'}
$translate8=$TranslateD3D8 -or $targetInfo.ApiHints -contains 'd3d8'
$persistentDirect=!$isPCSX2
$attachPolicy='preload'
$launchRecords=Join-Path $dir '.uncanny/launch'
if(Test-Path -LiteralPath $launchRecords){foreach($record in Get-ChildItem -LiteralPath $launchRecords -File -Filter '*.ini'){
  if($record.FullName -ine $launchPlan.Record -and (Get-UncannyIni $record.FullName 'Launch' 'Architecture') -ne $suffix){throw 'This folder already contains an installed target of the other architecture. Keep 32-bit and 64-bit installations in separate folders.'}
}}
Write-UncannyInstallProgress 6 'Checking running UNCANNY processes'
Request-UncannyIdleLauncherStop $dir
Stop-UncannyOrphanCompanions $dir
[void](Stop-UncannyVerifiedStuckLaunchTarget $dir $exe)
Assert-UncannyClosed $dir @($name,[IO.Path]::GetFileName($legacyOriginal),'UNCANNY.Launch.exe','UNCANNY.NativeLauncher.exe','UNCANNY.Revenant.exe','UNCANNY.AssetForge.exe','UNCANNY.ControlDeck.exe')
Write-Host 'Copyright (c) 2026 Coye Stillwagen. All rights reserved.'
Write-Host 'UNCANNY is independent and is not affiliated with or endorsed by NVIDIA.'
Write-Host 'NVIDIA and DLSS are trademarks of NVIDIA Corporation.'
Write-Host "Target: $name / $suffix-bit" -ForegroundColor Cyan
Write-Host ('API imports: '+($targetInfo.ApiHints -join ', ')+' (runtime detection pending)')
Write-UncannyInstallProgress 7 'Verifying release binaries'
$buildVerified=Test-UncannyBuild $root $suffix
if(!$buildVerified -or $ForceRebuild){
  if($SkipBuild -or (Test-Path -LiteralPath (Join-Path $root 'public-build.json'))){
    $detail=if($script:UncannyBuildFailure){$script:UncannyBuildFailure}else{'Unknown package verification failure.'}
    throw ("Release binary verification failed: "+$detail+" Target files were not changed. Do not disable security software. If this is the official release, review your security product's protection/quarantine history for the named UNCANNY file, then redownload the verified package if needed.")
  }
  & (Join-Path $runtimeRoot 'BUILD.ps1') -Architecture $suffix -ForceRebuild:$ForceRebuild
  $buildVerified=Test-UncannyBuild $root $suffix
}
if(!$buildVerified){
  $detail=if($script:UncannyBuildFailure){$script:UncannyBuildFailure}else{'Unknown build verification failure.'}
  throw ("Build provenance, binary hashes, or architecture validation failed: "+$detail)
}
function Test-UncannyExactCurrentInstall([string]$TargetExe,[string]$Architecture,[string]$BuildId,[bool]$ForPCSX2){
  try{
    $targetDir=Split-Path -Parent $TargetExe
    $record=Join-Path $targetDir ('.uncanny/launch/'+[IO.Path]::GetFileName($TargetExe)+'.ini')
    if(!(Test-Path -LiteralPath $record -PathType Leaf)){return $false}
    if((Get-UncannyIni $record 'Launch' 'BuildId') -ne $BuildId){return $false}
    $mode=Get-UncannyIni $record 'Launch' 'Mode'
    $expectedMode=if($ForPCSX2){'sidecar'}else{'direct-wrapper'}
    if($mode -ine $expectedMode){return $false}
    if((Get-UncannyIni $record 'Launch' 'Target') -cne [IO.Path]::GetFileName($TargetExe)){return $false}
    $targetExpected=Get-UncannyIni $record 'Launch' 'TargetSHA256'
    if($targetExpected -notmatch '^[a-fA-F0-9]{64}$'){return $false}
    if($ForPCSX2){
      if((Get-UncannySHA256 $TargetExe) -ine $targetExpected){return $false}
    }else{
      $original=Join-Path $targetDir ([IO.Path]::GetFileNameWithoutExtension($TargetExe)+'.uncanny-original.exe')
      $wrapperExpected=Get-UncannyIni $record 'Launch' 'WrapperSHA256'
      if(!(Test-Path -LiteralPath $original -PathType Leaf)){return $false}
      if((Get-UncannySHA256 $original) -ine $targetExpected){return $false}
      if($wrapperExpected -notmatch '^[a-fA-F0-9]{64}$'){return $false}
      if((Get-UncannySHA256 $TargetExe) -ine $wrapperExpected){return $false}
    }
    $provenancePath=if(Test-Path -LiteralPath (Join-Path $root 'public-build.json')){Join-Path $root 'public-build.json'}else{Join-Path $root 'dist/build-provenance.json'}
    if(!(Test-Path -LiteralPath $provenancePath -PathType Leaf)){return $false}
    $prov=Get-Content -LiteralPath $provenancePath -Raw|ConvertFrom-Json
    $targets=@($prov.targets|Where-Object{$_.architecture -eq $Architecture -and $_.compiled})
    if($targets.Count -ne 5){return $false}
    foreach($t in $targets){
      $dest=switch([string]$t.target){
        'NativeLauncher' {Join-Path $targetDir 'UNCANNY.Launch.exe'}
        'NativeRuntime' {Join-Path $targetDir 'UNCANNY.NativeRuntime.dll'}
        'Revenant' {Join-Path $targetDir 'UNCANNY.Revenant.exe'}
        'ControlDeck' {Join-Path $targetDir 'UNCANNY.ControlDeck.exe'}
        'DLSS5Bridge' {Join-Path $targetDir ("UNCANNY-nvngx.dll.bridge"+$Architecture+".dll")}
        default {return $false}
      }
      if(!(Test-Path -LiteralPath $dest -PathType Leaf)){return $false}
      if((Get-UncannySHA256 $dest).ToLowerInvariant() -ne ([string]$t.sha256).ToLowerInvariant()){return $false}
    }
    $providerState=Join-Path $targetDir '.uncanny/provider-state.json'
    if(!(Test-Path -LiteralPath $providerState -PathType Leaf)){return $false}
    $provider=Get-Content -LiteralPath $providerState -Raw|ConvertFrom-Json
    if(!$provider.status -or ([string]$provider.status) -notmatch 'FILES_READY|DRIVER_CORE_MISSING|RENDERING_PROVIDER_MISSING'){return $false}
    if($ForPCSX2){
      if(!(Get-UncannyReusableNeuralCore $targetDir)){return $false}
      $dataRoot=Get-UncannyIni $record 'Launch' 'PCSX2DataRootObserved'
      if(!$dataRoot){return $false}
      $mainConfig=Join-Path $dataRoot 'inis\PCSX2.ini'
      if(!(Test-Path -LiteralPath $mainConfig -PathType Leaf)){return $false}
      if(!(Test-Path -LiteralPath (Join-Path $targetDir '.uncanny/pcsx2-config-ownership.ini') -PathType Leaf)){return $false}
    }
    return $true
  }catch{return $false}
}
if(!$ForceRebuild -and (Test-UncannyExactCurrentInstall $exe $suffix $packageBuildId $isPCSX2)){
  Write-UncannyInstallProgress 100 'Already up to date'
  Write-Host ('INSTALL FAST PATH: exact '+$packageBuildId+' install verified; no files changed.')
  exit 0
}
Write-UncannyInstallProgress 15 'Preparing installation'
if(Test-Path -LiteralPath (Join-Path $dir '.uncanny/engine-transaction/journal.json')){. (Join-Path $runtimeRoot 'UNCANNY-EngineCommon.ps1');$null=Invoke-UncannyEngineSelection $dir '0' $suffix 'Restore' 0}
$compatSource='';$compatHash='';$compatDest=Join-Path $dir 'd3d8.dll'
if($translate8){
  if($suffix -ne '32'){throw 'The D3D8 translation dependency supports 32-bit games only. UNCANNY itself includes both x86 and x64 runtimes.'}
  $metadataFile=Join-Path $root 'compatibility/d3d8to9.json'
  if(!(Test-Path -LiteralPath $metadataFile)){throw 'D3D8 compatibility metadata is missing from this package.'}
  $metadata=Get-Content -LiteralPath $metadataFile -Raw|ConvertFrom-Json
  $entry=@($metadata.targets|Where-Object architecture -eq $suffix);if($entry.Count -ne 1){throw 'D3D8 compatibility architecture is missing.'}
  $compatSource=Join-Path $root "dist/compat/d3d8to9$suffix.dll";$compatHash=$entry[0].sha256
  if(!(Test-Path -LiteralPath $compatSource) -or (Get-UncannySHA256 $compatSource) -ine $compatHash -or (Get-UncannyTargetPeInfo $compatSource).Architecture -ne $suffix){throw 'D3D8 dependency integrity failed.'}
  if(Test-Path -LiteralPath $compatDest){
    $managed=Join-Path $dir '.uncanny/d3d8to9.sha256';$known=(Test-Path -LiteralPath $managed) -and (Get-Content -LiteralPath $managed -Raw).Trim() -ieq (Get-UncannySHA256 $compatDest)
    $conflict=@((Get-UncannyEnvironment $dir).files|Where-Object {$_.path -ieq $compatDest -and $_.classification -eq 'CONFIRMED_CONFLICT'})
    if(!$known -and !$conflict.Count){
      $existing=Get-UncannyPeInfo $compatDest
      $looksTranslator=($existing.Exports -contains 'Direct3DCreate8') -and ($existing.Imports -contains 'd3d9.dll')
      if($looksTranslator){$translate8=$false;$LegacyDirectX=$true;Write-Warning 'Existing D3D8-to-D3D9 wrapper retained; UNCANNY will attach downstream without replacing it.'}
      else{
        $existingHash=(Get-UncannySHA256 $compatDest).ToLowerInvariant()
        $translate8=$false;$LegacyDirectX=$true
        Write-Warning ('Existing unrecognized d3d8.dll retained unchanged (SHA256 '+$existingHash+'). UNCANNY will not replace it; D3D8 translation/Feature-18 availability depends on that existing wrapper.')
      }
    }
  }
  if($env:OS -eq 'Windows_NT'){
    $system=if($suffix -eq '32' -and [Environment]::Is64BitOperatingSystem){'SysWOW64'}elseif($suffix -eq '64' -and ![Environment]::Is64BitProcess){'Sysnative'}else{'System32'}
    $legacyRuntime=@((Join-Path $dir 'd3dx9_43.dll'),(Join-Path $env:WINDIR "$system/d3dx9_43.dll"))|Where-Object{Test-Path -LiteralPath $_}
    if(!$legacyRuntime){throw 'D3D8 translation requires Microsoft DirectX End-User Runtimes (June 2010), including d3dx9_43.dll. Install it from https://www.microsoft.com/en-us/download/details.aspx?id=8109, then rerun this installer.'}
  }
}
$dataDir='';$mainIni='';$gameDir='';$textures='';$gameInis=@()
if($isPCSX2){
  if($PCSX2DataDir){$dataDir=(Resolve-Path -LiteralPath $PCSX2DataDir).Path}
  elseif(Test-Path -LiteralPath (Join-Path $dir 'portable.ini')){$dataDir=$dir}
  elseif(Test-Path -LiteralPath (Join-Path $dir '.uncanny\pcsx2-paths.ini')){$dataDir=Get-UncannyIni (Join-Path $dir '.uncanny\pcsx2-paths.ini') 'Paths' 'DataRoot'}
  else{
    $candidates=@($dir,(Join-Path ([Environment]::GetFolderPath('MyDocuments')) 'PCSX2'),(Join-Path $env:LOCALAPPDATA 'PCSX2'),(Join-Path $env:APPDATA 'PCSX2')) | Select-Object -Unique
    $found=@($candidates|Where-Object{Test-Path -LiteralPath (Join-Path $_ 'inis\PCSX2.ini')})
    if($found.Count -eq 1){$dataDir=$found[0]}else{throw 'PCSX2 configuration is ambiguous or missing. Launch PCSX2 once, then run with -PCSX2DataDir pointing to its settings/data folder.'}
  }
  $mainIni=Join-Path $dataDir 'inis\PCSX2.ini'
  if(!(Test-Path -LiteralPath $mainIni)){throw "PCSX2.ini missing: $mainIni"}
  $textures=Get-UncannyFolder $mainIni $dataDir 'Textures' 'textures'
  $gameDir=Get-UncannyFolder $mainIni $dataDir 'GameSettings' 'gamesettings'
  if(Test-Path -LiteralPath $gameDir){$gameInis=@(Get-ChildItem -LiteralPath $gameDir -File -Filter '*.ini')}
  & (Join-Path $runtimeRoot 'RECOVER-REVENANT.ps1') -TargetDir $dir -Textures $textures
}
Assert-UncannyNoReparsePath $dir
Assert-UncannyNoReparsePath (Join-Path $dir '.uncanny')
$pcAssetsMarker=Join-Path $dir '.uncanny/pc-assets.enabled'
Assert-UncannyNoReparsePath $pcAssetsMarker
$pcAssetsEnabled=Test-Path -LiteralPath $pcAssetsMarker -PathType Leaf
$transaction=[guid]::NewGuid().ToString('N');$state=Join-Path $dir '.uncanny';New-Item -ItemType Directory -Path $state -Force|Out-Null
$stage=Join-Path $state "stage-$transaction";$backup=Join-Path $state ('backup-native-'+(Get-Date -Format 'yyyyMMdd-HHmmss')+'-'+$transaction)
New-Item -ItemType Directory -Path $stage,$backup -Force|Out-Null
Write-UncannyInstallProgress 24 'Staging runtime files'
$installPerf=[Diagnostics.Stopwatch]::StartNew()
$changes=[Collections.Generic.List[object]]::new();$manifest=$null;$graphicsBackup='';$installCommitted=$false
function Add-Change([string]$Source,[string]$Destination,[string]$KnownSourceSHA256=''){
  Assert-UncannyNoReparsePath $Destination
  $known=if($KnownSourceSHA256 -match '^[a-fA-F0-9]{64}$'){$KnownSourceSHA256.ToLowerInvariant()}else{''}
  $changes.Add([pscustomobject]@{source=$Source;destination=[IO.Path]::GetFullPath($Destination);sourceSHA256=$known})
}
function Resolve-UncannyPackageSupportSource([string]$Name){
  if([string]::IsNullOrWhiteSpace($Name)){throw 'Installer support filename is empty.'}
  if($Name -match '(?i)\.cmd$'){
    $tool=Join-Path $root ('Tools/'+$Name)
    if(Test-Path -LiteralPath $tool -PathType Leaf){return [IO.Path]::GetFullPath($tool)}
  }
  $runtime=Join-Path $runtimeRoot $Name
  if(Test-Path -LiteralPath $runtime -PathType Leaf){return [IO.Path]::GetFullPath($runtime)}
  $legacy=Join-Path $root $Name
  if(Test-Path -LiteralPath $legacy -PathType Leaf){return [IO.Path]::GetFullPath($legacy)}
  throw ('Required installer support file is missing from the package: '+$Name)
}
function Get-UncannyReusableNeuralCore([string]$TargetDir){
  $expected=[ordered]@{
    'realesrgan-ncnn-vulkan.exe'='07e49f7cbb4ede01ae4dd4c399d3a7e5846e3d2085c3128eff881e55cb7b1a0c'
    'models\realesrgan-x4plus.param'='35330ececcea33b6c397a72548e788d5d53becee4734c50b7fada36e89f10a86'
    'models\realesrgan-x4plus.bin'='713ee713b0353afaa27976f0563a64a5043bd70b9bd8936c2e26e25ebcdbcddf'
    'vcomp140.dll'='8f72ef2e483465444b2059fc6744d6cb22cd8d8a27f6fa56befd2a42dcd0f78b'
  }
  $candidates=[Collections.Generic.List[string]]::new()
  $candidates.Add((Join-Path $TargetDir '.uncanny\ai\realesrgan'))
  if($env:LOCALAPPDATA){
    $remember=Join-Path $env:LOCALAPPDATA 'UNCANNY\last-native-target.txt'
    try{
      if(Test-Path -LiteralPath $remember -PathType Leaf){
        $last=[IO.File]::ReadAllText($remember).Trim()
        if($last -and [IO.Path]::IsPathRooted($last)){
          $lastDir=if(Test-Path -LiteralPath $last -PathType Container){$last}else{Split-Path -Parent $last}
          if($lastDir){$candidates.Add((Join-Path $lastDir '.uncanny\ai\realesrgan'))}
        }
      }
    }catch{}
  }
  foreach($base in @($candidates|Select-Object -Unique)){
    if(!(Test-Path -LiteralPath $base -PathType Container)){continue}
    $ok=$true
    foreach($rel in $expected.Keys){
      $path=Join-Path $base $rel
      if(!(Test-Path -LiteralPath $path -PathType Leaf) -or (Get-UncannySHA256 $path).ToLowerInvariant() -ne $expected[$rel]){$ok=$false;break}
    }
    if($ok){return [pscustomobject]@{Base=$base;Expected=$expected}}
  }
  return $null
}
function Get-UncannyProfileKey([string]$ImagePath){
  if(-not ('UncannyProfileKey' -as [type])){
    Add-Type -TypeDefinition @'
using System;
public static class UncannyProfileKey {
  public static string FromImage(string image) {
    unchecked {
      ulong h=14695981039346656037UL;
      foreach(char raw in image.Replace('/','\\').ToLowerInvariant()) { h ^= (uint)raw; h *= 1099511628211UL; }
      return h.ToString();
    }
  }
}
'@
  }
  return [UncannyProfileKey]::FromImage([IO.Path]::GetFullPath($ImagePath))
}
function New-UncannyRealityProfile([string]$ImagePath,[bool]$ForPCSX2){
  $profileKey=Get-UncannyProfileKey $ImagePath
  $profileDest=Join-Path $state ("profiles\\$profileKey.ini")
  $profileStage=Join-Path $stage ("profile-$profileKey.ini")
  if(Test-Path -LiteralPath $profileDest -PathType Leaf){Copy-Item -LiteralPath $profileDest -Destination $profileStage -Force}
  else{New-Item -ItemType File -Path $profileStage -Force|Out-Null}
  $settings=[ordered]@{
    enabled='1'; quality_mode='4'; dlss5_passes_x2='5'; uncanny_content_mode='5';
    nr_intensity='1.96'; nr_structure='2.00'; nr_skin_structure='2.00'; nr_global_tone='1.00'; nr_local_tone='1.08';
    uncanny_strength='2.00'; uncanny_photorealism='2.00'; uncanny_detail_recovery='2.00'; uncanny_reality='2.00';
    uncanny_clarity='1.82'; uncanny_reality_lock='2.00'; uncanny_sharpen='0.10'; uncanny_denoise='0.06';
    uncanny_local_contrast='0.72'; uncanny_microtexture='1.00'; uncanny_skin_protect='0.03';
    uncanny_edge_preserve='0.99'; uncanny_anti_halo='1.00'; uncanny_flat_color_protect='0.88'; uncanny_line_art_protect='0.90';
    uncanny_saturation='1.00'; uncanny_vibrance='1.00'; uncanny_temperature='0.00'; uncanny_exposure='0.00'; uncanny_contrast='1.00'; uncanny_highlights='0.00'; uncanny_shadows='0.00';
    motion_guard='1'; ghosting_guard='1'; revenant_enabled='1'; reality_memory='1'; revenant_strength='3';
    performance_guard=$(if($ForPCSX2){'0'}else{'1'})
  }
  foreach($kv in $settings.GetEnumerator()){Set-UncannyIni $profileStage 'Controls' $kv.Key ([string]$kv.Value)}
  Set-UncannyIni $profileStage 'UNCANNY' 'Preset' 'ELYSIUM-4.5'
  Set-UncannyIni $profileStage 'UNCANNY' 'SeededBy' $packageRevision
  Add-Change $profileStage $profileDest
  $receipt=Join-Path $stage ("reality-profile-$profileKey.json")
  [ordered]@{schema='UNCANNY-REALITY-PROFILE-1';profileKey=$profileKey;image=[IO.Path]::GetFullPath($ImagePath);preset='ELYSIUM-4.5';pcsx2=$ForPCSX2;performanceGuard=$(if($ForPCSX2){0}else{1});controls=$settings}|ConvertTo-Json -Depth 5|Set-Content -LiteralPath $receipt -Encoding UTF8
  Add-Change $receipt (Join-Path $state ("profiles\\$profileKey.reality.json"))
  return $profileKey
}
try{
  foreach($component in @('NativeRuntime','NativeLauncher','Revenant','ControlDeck')){
    $ext=if($component -eq 'NativeRuntime'){'dll'}else{'exe'}
    Add-Change (Join-Path $root "dist\UNCANNY.$component$suffix.$ext") (Join-Path $dir "UNCANNY.$component.$ext")
  }
  Add-Change (Join-Path $root "dist\UNCANNY-nvngx.dll.bridge$suffix.dll") (Join-Path $dir "UNCANNY-nvngx.dll.bridge$suffix.dll")
  Add-Change (Join-Path $root "dist/UNCANNY.ControlDeck$suffix.exe") (Join-Path $dir 'UNCANNY.EngineManager.exe')
  foreach($script in @('UNCANNY-ProviderCommon.ps1','SETUP-DLSS5.ps1','SETUP-DLSS5.cmd')){Add-Change (Resolve-UncannyPackageSupportSource $script) (Join-Path $dir $script)}
  Add-Change (Join-Path $root 'config/provider-catalog.json') (Join-Path $dir 'config/provider-catalog.json')
  Add-Change (Join-Path $root "dist/UNCANNY.NativeLauncher$suffix.exe") (Join-Path $dir 'UNCANNY.EngineLauncher.exe')
  Write-UncannyInstallProgress 27 'Preparing compatibility engine bundle'
  $engineFolder=Join-Path $root ("engines/release-fix.5/$suffix")
  if(Test-Path -LiteralPath $engineFolder){. (Join-Path $runtimeRoot 'UNCANNY-EngineCommon.ps1');$engineBundle=Read-UncannyEngineBundle $root 'release-fix.5' $suffix -PublicRoot;foreach($engineFile in @($engineBundle.Manifest.files.binary)+@('engine.json')){Add-Change (Join-Path $engineFolder $engineFile) (Join-Path $dir (".uncanny/engine-bundles/release-fix.5/$suffix/"+$engineFile))}}
  Write-UncannyInstallProgress 31 'Preparing installer support files'
  foreach($script in @('ROLLBACK-NATIVE.ps1','UNCANNY-InstallCommon.ps1','RECOVER-REVENANT.ps1','UNCANNY-DIAGNOSTICS.ps1','UNCANNY-STATUS.cmd','UNCANNY-ACCEPTANCE.cmd','UNCANNY-ACCEPTANCE.ps1','UNCANNY-AcceptanceCommon.ps1','UNCANNY-PROVIDERS.cmd','UNCANNY-ENGINES.cmd','UNCANNY-ENGINE-SWITCH.ps1','UNCANNY-EngineCommon.ps1','SETUP-PC-ASSETS.cmd','SETUP-PC-ASSETS.ps1','REPAIR-NEURAL-CORE.cmd','INSTALL-AI-CORE.ps1','UNCANNY-Environment.ps1','CLEAN-ENVIRONMENT.ps1','RESTORE-GRAPHICS-MODS.ps1')){Add-Change (Resolve-UncannyPackageSupportSource $script) (Join-Path $dir $script)}
  if($isPCSX2 -or $pcAssetsEnabled){
    $reusableCore=Get-UncannyReusableNeuralCore $dir
    if($reusableCore){
      Write-UncannyInstallProgress 33 'Reusing verified neural asset core'
      Write-Host ('NEURAL ASSET CORE: reusing verified files from '+$reusableCore.Base)
      foreach($rel in $reusableCore.Expected.Keys){
        Add-Change (Join-Path $reusableCore.Base $rel) (Join-Path $dir ('.uncanny\ai\realesrgan\'+$rel)) $reusableCore.Expected[$rel]
      }
      $receipt=Join-Path (Split-Path -Parent $reusableCore.Base) 'NEURAL-CORE.txt'
      if(Test-Path -LiteralPath $receipt -PathType Leaf){Add-Change $receipt (Join-Path $dir '.uncanny\ai\NEURAL-CORE.txt')}
    }else{
      Write-UncannyInstallProgress 33 'Preparing verified neural asset core'
      & (Join-Path $runtimeRoot 'INSTALL-AI-CORE.ps1') -TargetDir $stage
      Get-ChildItem -LiteralPath (Join-Path $stage '.uncanny\ai') -Recurse -File|ForEach-Object{
        $relative=$_.FullName.Substring($stage.Length).TrimStart('\','/');Add-Change $_.FullName (Join-Path $dir $relative)
      }
    }
  }
  if($isPCSX2){
    $paths=Join-Path $stage 'pcsx2-paths.ini'
    Set-UncannyIni $paths 'Paths' 'DataRoot' $dataDir
    Set-UncannyIni $paths 'Paths' 'MainConfig' $mainIni
    Set-UncannyIni $paths 'Paths' 'Textures' $textures
    Set-UncannyIni $paths 'Launch' 'OriginalExe' $actual
    Set-UncannyIni $paths 'Launch' 'OriginalWorkingDirectory' $dir
    Set-UncannyIni $paths 'Launch' 'OriginalFilename' $name
    Set-UncannyIni $paths 'Launch' 'PortableMode' ([string](Test-Path -LiteralPath (Join-Path $dir 'portable.ini')))
    Set-UncannyIni $paths 'Launch' 'Architecture' $suffix
    Add-Change $paths (Join-Path $state 'pcsx2-paths.ini')
    $ownership=Join-Path $stage 'pcsx2-config-ownership.ini'
    New-Item -ItemType File -Path $ownership -Force|Out-Null
    $ownedConfigs=@($mainIni)+@($gameInis|ForEach-Object{$_.FullName})
    Set-UncannyIni $ownership 'Ownership' 'Version' '1'
    Set-UncannyIni $ownership 'Ownership' 'Count' ([string]$ownedConfigs.Count)
    Set-UncannyIni $ownership 'Ownership' 'Policy' 'runtime-scoped-revenant'
    $ownedIndex=0
    foreach($configPath in $ownedConfigs){
      $section='Config'+$ownedIndex
      Set-UncannyIni $ownership $section 'Path' $configPath
      foreach($key in @('DumpReplaceableTextures','LoadTextureReplacements','LoadTextureReplacementsAsync')){
        $value=Get-UncannyIni $configPath 'EmuCore/GS' $key
        if([string]::IsNullOrEmpty($value)){$value='__UNCANNY_ABSENT__'}
        Set-UncannyIni $ownership $section ('Original'+$key) $value
      }
      $hotkey=Get-UncannyIni $configPath 'Hotkeys' 'ReloadTextureReplacements'
      if([string]::IsNullOrEmpty($hotkey)){$hotkey='__UNCANNY_ABSENT__'}
      Set-UncannyIni $ownership $section 'OriginalReloadTextureReplacements' $hotkey
      $ownedIndex++
    }
    Add-Change $ownership (Join-Path $state 'pcsx2-config-ownership.ini')
    $revenantConfig=Join-Path $stage 'revenant-pcsx2-install.json'
    [ordered]@{
      schema='UNCANNY-PCSX2-REVENANT-INSTALL-3';mainConfig=$mainIni;gameOverridesPatched=0;
      textures=$textures;rendererPolicy='preserve-user-selection';configMutation='runtime-scoped-revenant';
      dumpReplaceableTextures='while-active';loadTextureReplacements='while-active';
      ownershipFile='.uncanny/pcsx2-config-ownership.ini';transactionalBackup=$true;cloudPlaceholderAware=$true
    }|ConvertTo-Json -Depth 4|Set-Content -LiteralPath $revenantConfig -Encoding UTF8
    Add-Change $revenantConfig (Join-Path $state 'revenant-pcsx2-install.json')
  }
  if($translate8){Add-Change $compatSource $compatDest;$receipt=Join-Path $stage 'd3d8to9.sha256';[IO.File]::WriteAllText($receipt,$compatHash);Add-Change $receipt (Join-Path $state 'd3d8to9.sha256')}
  if($LegacyDirectX -or $translate8){$marker=Join-Path $stage 'd3d9on12.enabled';[IO.File]::WriteAllText($marker,"WINDOWS_D3D9ON12_OPT_IN`n");Add-Change $marker (Join-Path $state 'd3d9on12.enabled')}
  Write-UncannyInstallProgress 35 ($(if($persistentDirect){'Preparing persistent per-game bootstrap'}else{'Preparing verified sidecar launch'}))
  if(!$actualSHA256){$actualSHA256=(Get-UncannySHA256 $actual).ToLowerInvariant()}
  $launcherSource=Join-Path $root "dist/UNCANNY.NativeLauncher$suffix.exe"
  $launcherSHA=(Get-UncannySHA256 $launcherSource).ToLowerInvariant()
  if($persistentDirect){
    if([IO.Path]::GetFullPath($actual) -ine [IO.Path]::GetFullPath($legacyOriginal)){
      Add-Change $actual $legacyOriginal $actualSHA256
    }
    Add-Change $launcherSource $exe $launcherSHA
  }elseif($legacyMigration){
    Add-Change $actual $exe $actualSHA256
  }
  Add-Change $launcherSource $sidecar $launcherSHA
  $launchRecord=Join-Path $stage 'launch-record.ini'
  Set-UncannyIni $launchRecord 'Launch' 'Mode' ($(if($persistentDirect){'direct-wrapper'}else{'sidecar'}))
  Set-UncannyIni $launchRecord 'Launch' 'Target' $name
  Set-UncannyIni $launchRecord 'Launch' 'TargetSHA256' $actualSHA256
  Set-UncannyIni $launchRecord 'Launch' 'Launcher' 'UNCANNY.Launch.exe'
  Set-UncannyIni $launchRecord 'Launch' 'LauncherSHA256' $launcherSHA
  Set-UncannyIni $launchRecord 'Launch' 'Original' ($(if($persistentDirect){[IO.Path]::GetFileName($legacyOriginal)}else{$name}))
  Set-UncannyIni $launchRecord 'Launch' 'SHA256' $actualSHA256
  Set-UncannyIni $launchRecord 'Launch' 'WrapperSHA256' $launcherSHA
  Set-UncannyIni $launchRecord 'Launch' 'Architecture' $suffix
  Set-UncannyIni $launchRecord 'Launch' 'Revision' $packageRevision
  Set-UncannyIni $launchRecord 'Launch' 'BuildId' $packageBuildId
  Set-UncannyIni $launchRecord 'Launch' 'AttachPolicy' $attachPolicy
  Set-UncannyIni $launchRecord 'Launch' 'WorkingDirectory' $dir
  if($isPCSX2){
    $observedRenderer=Get-UncannyIni $mainIni 'EmuCore/GS' 'Renderer'
    Set-UncannyIni $launchRecord 'Launch' 'PCSX2DataRootObserved' $dataDir
    Set-UncannyIni $launchRecord 'Launch' 'PCSX2PortableMode' ([string](Test-Path -LiteralPath (Join-Path $dir 'portable.ini')))
    Set-UncannyIni $launchRecord 'Launch' 'PCSX2RendererPolicy' 'PreserveUserSelection'
    Set-UncannyIni $launchRecord 'Launch' 'PCSX2RendererValueObserved' $observedRenderer
  }
  Add-Change $launchRecord $launchPlan.Record
  Write-UncannyInstallProgress 39 'Preparing game profile'
  $profileImage=if($persistentDirect){$legacyOriginal}else{$exe}
  $installedProfileKey=New-UncannyRealityProfile $profileImage $isPCSX2
  $enginePreferenceDest=Join-Path $state ("engine-preferences\\$installedProfileKey.ini")
  $explicitEngineChoice=if(Test-Path -LiteralPath $enginePreferenceDest){Get-UncannyIni $enginePreferenceDest 'Engine' 'UserSelected'}else{''}
  if($explicitEngineChoice -ne '1'){
    $enginePreferenceStage=Join-Path $stage ("engine-preference-$installedProfileKey.ini")
    New-Item -ItemType File -Path $enginePreferenceStage -Force|Out-Null
    Set-UncannyIni $enginePreferenceStage 'Engine' 'Id' 'automatic'
    Set-UncannyIni $enginePreferenceStage 'Engine' 'Confirmed' 'elysium'
    Set-UncannyIni $enginePreferenceStage 'Engine' 'UserSelected' '0'
    Set-UncannyIni $enginePreferenceStage 'Engine' 'LastResult' 'INSTALL_MIGRATED_TO_CURRENT_ELYSIUM'
    Set-UncannyIni $enginePreferenceStage 'Engine' 'Revision' $packageRevision
    Add-Change $enginePreferenceStage $enginePreferenceDest
  }
  $engineActiveStage=Join-Path $stage 'engine-active.ini'
  New-Item -ItemType File -Path $engineActiveStage -Force|Out-Null
  Set-UncannyIni $engineActiveStage 'Engine' 'Id' 'elysium'
  Set-UncannyIni $engineActiveStage 'Engine' 'ABI' ([string]$version.abi)
  Set-UncannyIni $engineActiveStage 'Engine' 'Name' 'UNCANNY 4.5 - ELYSIUM'
  Set-UncannyIni $engineActiveStage 'Engine' 'Generation' '4.5'
  Set-UncannyIni $engineActiveStage 'Engine' 'FallbackReason' 'NONE'
  Set-UncannyIni $engineActiveStage 'Engine' 'LastResult' 'INSTALL_ACTIVE'
  Set-UncannyIni $engineActiveStage 'Engine' 'SwitchCount' '0'
  Set-UncannyIni $engineActiveStage 'Engine' 'Revision' $packageRevision
  Add-Change $engineActiveStage (Join-Path $state 'engine-active.ini')
  Write-Host ('INSTALL PERF staging_ms='+$installPerf.ElapsedMilliseconds)
  Write-UncannyInstallProgress 48 'Preparing graphics runtime'
  $providerStage=Join-Path $stage 'provider-stage';New-Item -ItemType Directory -Path $providerStage -Force|Out-Null
  $providerPlan=New-UncannyProviderPlan -TargetDir $dir -Stage $providerStage -PackageRoot $root -Architecture $suffix -Explicit $NeuralRuntimeDir -AllowDownload:(!$OfflineProviders)
  $providerIndex=0
  foreach($item in $providerPlan.changes){
    $saved=Join-Path $providerStage ("candidate-$providerIndex.dll");Copy-Item -LiteralPath $item.source -Destination $saved
    if((Get-UncannySHA256 $saved) -ine $item.sha256){throw 'Provider changed during discovery; target retained.'}
    Add-Change $saved $item.destination;$providerIndex++
  }
    $hostInfo=Get-Content -LiteralPath (Join-Path $root 'dist/neural-host-provenance.json') -Raw|ConvertFrom-Json
    if($hostInfo.revision -ne $version.revision){throw 'Neural host belongs to a different release; use the complete current ZIP.'}
    if(!$hostInfo.compiled -or $hostInfo.architecture -ne '64'){throw 'x64 neural helper build is unavailable.'}
    $helper=Join-Path $root 'dist/UNCANNY.NeuralHost64.exe'
    $helperSHA=([string]$hostInfo.sha256).ToLowerInvariant()
    if((Get-UncannySHA256 $helper) -ine $helperSHA -or (Get-UncannyTargetPeInfo $helper).Architecture -ne '64'){throw 'x64 neural helper verification failed.'}
    $bridge64=Join-Path $root 'dist/UNCANNY-nvngx.dll.bridge64.dll'
    $bridge64SHA=''
    if($suffix -eq '64'){
      if(!$buildVerified){throw 'x64 neural bridge provenance failed.'}
    }else{
      $provenancePath=if(Test-Path -LiteralPath (Join-Path $root 'public-build.json')){Join-Path $root 'public-build.json'}else{Join-Path $root 'dist/build-provenance.json'}
      $provenance=Get-Content -LiteralPath $provenancePath -Raw|ConvertFrom-Json
      $bridgeRecord=@($provenance.targets|Where-Object{$_.architecture -eq '64' -and $_.target -eq 'DLSS5Bridge' -and $_.compiled})
      if($bridgeRecord.Count -ne 1){throw 'x64 neural bridge provenance failed.'}
      $bridge64SHA=([string]$bridgeRecord[0].sha256).ToLowerInvariant()
      if(!(Test-Path -LiteralPath $bridge64 -PathType Leaf) -or (Get-UncannySHA256 $bridge64) -ine $bridge64SHA -or (Get-UncannyTargetPeInfo $bridge64).Architecture -ne '64'){throw 'x64 neural bridge provenance failed.'}
    }
    Add-Change $helper (Join-Path $dir '.uncanny/host64/UNCANNY.NeuralHost64.exe') $helperSHA
    Add-Change $bridge64 (Join-Path $dir '.uncanny/host64/UNCANNY-nvngx.dll.bridge64.dll') $bridge64SHA
  Write-UncannyInstallProgress 62 'Preparing neural provider route'
  $providerReceipt=Join-Path $providerStage 'provider-state.json';$providerPlan|ConvertTo-Json -Depth 12|Set-Content -LiteralPath $providerReceipt -Encoding UTF8
  Add-Change $providerReceipt (Join-Path $state 'provider-state.json')
  Write-Host ("DLSS 5 setup: "+$providerPlan.status+" / "+$providerPlan.route) -ForegroundColor Cyan
  if($providerPlan.status -ne 'FILES_READY_INFERENCE_NOT_TESTED'){Write-Warning 'UNCANNY image processing remains available. DLSS 5 is not ready; see .uncanny/provider-state.json. Missing driver core requires a compatible NVIDIA driver, not a random DLL.'}
  $launch=Join-Path $stage 'UNCANNY-LAUNCH.cmd'
  $launchText='@echo off'+"`r`n"+'cd /d "%~dp0"'+"`r`n"+'"%~dp0UNCANNY.Launch.exe" "%~dp0'+$name+'" %*'+"`r`n"+'exit /b %ERRORLEVEL%'
  [IO.File]::WriteAllText($launch,$launchText,[Text.Encoding]::ASCII);Add-Change $launch (Join-Path $dir 'UNCANNY-LAUNCH.cmd')
  $environment=Get-UncannyEnvironment $dir
  if($environment.confirmed -and !$CleanEnvironment){throw 'Graphics conflicts detected. Use -CleanEnvironment for verified backup/quarantine, or run CLEAN-ENVIRONMENT.ps1 to review.'}
  if($CleanEnvironment){$clean=Clear-UncannyEnvironment $dir;$environment=$clean.scan;$graphicsBackup=$clean.backup}
  $environmentPath=Join-Path $stage 'environment.json';Save-UncannyEnvironmentJson $environment $environmentPath;Add-Change $environmentPath (Join-Path $state 'environment.json')
  if($environment.unknown){Write-Warning 'Unknown graphics proxies were retained. Runtime compatibility remains unverified.'}
  Write-UncannyInstallProgress 70 'Checking changed files'
  $backupWatch=[Diagnostics.Stopwatch]::StartNew()
  $planned=@($changes);$effective=[Collections.Generic.List[object]]::new();$files=@();$scanIndex=0;$skippedUnchanged=0;$sourceHashes=@{}
  foreach($c in $planned){
    $scanIndex++
    $pct=70+[int](8*$scanIndex/[Math]::Max(1,$planned.Count))
    Write-UncannyInstallProgress $pct ('Checking changed files '+$scanIndex.ToString()+' / '+$planned.Count.ToString())
    $sourcePath=[string]$c.source
    if([string]::IsNullOrWhiteSpace($sourcePath) -or !(Test-Path -LiteralPath $sourcePath -PathType Leaf)){throw ('Install plan source is missing: '+$sourcePath+' -> '+[string]$c.destination)}
    $sourceKey=$sourcePath.ToLowerInvariant()
    if($c.sourceSHA256){$after=[string]$c.sourceSHA256}
    elseif($sourceHashes.ContainsKey($sourceKey)){$after=[string]$sourceHashes[$sourceKey]}
    else{$after=(Get-UncannySHA256 $c.source).ToLowerInvariant();$sourceHashes[$sourceKey]=$after}
    $exists=Test-Path -LiteralPath $c.destination;$before=''
    if($exists){
      $before=(Get-UncannySHA256 $c.destination).ToLowerInvariant()
      if($before -eq $after){$skippedUnchanged++;continue}
    }
    $bn='file-'+$files.Count+'.bin'
    if($exists){
      Copy-Item -LiteralPath $c.destination -Destination (Join-Path $backup $bn) -ErrorAction Stop
      if((Get-UncannySHA256 (Join-Path $backup $bn)).ToLowerInvariant() -ne $before){throw 'Installation backup verification failed; target retained.'}
    }
    $ownership=if($legacyMigration -and $c.destination -ieq $exe){'UNCANNY_MANAGED'}else{Get-UncannyOwnershipClass $c.destination $dir}
    $effective.Add($c)
    $files+=[pscustomobject]@{destination=$c.destination;existed=$exists;backup=$bn;beforeSHA256=$before;installedSHA256=$after;ownershipClass=$ownership}
  }
  $changes=$effective
  Write-UncannyInstallProgress 79 ('Rollback backup ready - '+$changes.Count+' changed files')
  Write-Host ('INSTALL PERF backup_plan_ms='+$backupWatch.ElapsedMilliseconds+' planned='+$planned.Count+' changed='+$changes.Count+' unchanged_skipped='+$skippedUnchanged)
  $manifest=[pscustomobject]@{version=$version.version;build=$version.build;abi=$version.abi;revision=$version.revision;buildId=$packageBuildId;target=$exe;targetDir=$dir;allowedRoots=@($dir,$dataDir,$gameDir)|Where-Object{$_}|Select-Object -Unique;created=(Get-Date -Format o);phase='prepared';graphicsBackup=$graphicsBackup;files=$files}
  $manifest|ConvertTo-Json -Depth 8|Set-Content -LiteralPath (Join-Path $backup 'manifest.json') -Encoding UTF8
  Write-UncannyInstallProgress 80 'Installing verified changed files'
  $index=0
  foreach($c in $changes){
    $f=$files[$index]
    Set-UncannyVerifiedFile $c.source $c.destination $f.installedSHA256 $f.beforeSHA256 -SourceHashPrevalidated
    $index++
    $pct=80+[int](15*$index/[Math]::Max(1,$changes.Count))
    Write-UncannyInstallProgress $pct ('Installing changed files '+$index.ToString()+' / '+$changes.Count.ToString())
  }
  $manifest.phase='committed';$manifest|ConvertTo-Json -Depth 8|Set-Content -LiteralPath (Join-Path $backup 'manifest.json') -Encoding UTF8
  $installCommitted=$true
  Write-UncannyInstallProgress 97 'Finalizing launch record'
  $targetInfo|ConvertTo-Json -Depth 5|Set-Content -LiteralPath (Join-Path $state 'target-api.json') -Encoding UTF8
  $remember=Join-Path $env:LOCALAPPDATA 'UNCANNY';New-Item -ItemType Directory -Path $remember -Force|Out-Null
  [IO.File]::WriteAllText((Join-Path $remember 'last-native-target.txt'),$exe,[Text.UTF8Encoding]::new($false))
  Write-UncannyInstallProgress 100 'Installation complete'
  Write-Host 'INSTALLATION COMPLETE - release binary hashes verified.' -ForegroundColor Green
  if($isPCSX2){Write-Host 'REVENANT PCSX2 CONFIG OWNERSHIP READY - renderer preserved; capture/load keys are runtime-scoped.' -ForegroundColor Green}
  Write-Host 'RUNTIME ATTACHMENT PENDING - launch the game; files do not establish runtime activity.' -ForegroundColor Yellow
  Write-Host "Launch normally: $exe" -ForegroundColor Cyan
  if($persistentDirect){Write-Host 'UNCANNY per-game bootstrap is installed at the normal game entry point; Steam/Epic/direct EXE and the UNCANNY launcher converge on the same verified runtime path.'}
  else{Write-Host 'PCSX2 keeps its original executable; use the verified UNCANNY sidecar for attachment while emulator identity/configuration remain untouched.'}
  Write-Host 'HOME requests the in-game Deck on D3D9/10/11/12; the game retains focus. Run fullscreen acceptance on your system.'
  Write-Host "Rollback backup: $backup" -ForegroundColor DarkGray
}catch{
  Write-Host ('INSTALL FAILURE '+$_.Exception.Message)
  if($_.ScriptStackTrace){Write-Host ('INSTALL STACK '+$_.ScriptStackTrace)}
  if(!$installCommitted -and $manifest){try{& (Join-Path $runtimeRoot 'ROLLBACK-NATIVE.ps1') -TargetDir $dir -BackupDir $backup -FailedInstall}catch{Write-Warning "Recovery needs attention; backup retained: $backup :: $_"}}
  if(!$installCommitted -and !$manifest -and $graphicsBackup){try{Restore-UncannyEnvironment $dir $graphicsBackup|Out-Null}catch{Write-Warning "Graphics backup needs manual restore: $graphicsBackup :: $_"}}
  throw
}finally{Remove-Item -LiteralPath $stage -Recurse -Force -ErrorAction SilentlyContinue}
