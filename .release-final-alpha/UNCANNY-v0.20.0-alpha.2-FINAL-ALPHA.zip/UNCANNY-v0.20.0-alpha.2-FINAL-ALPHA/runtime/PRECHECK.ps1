﻿Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'
$root=[IO.Path]::GetFullPath($env:UNCANNY_PACKAGE_ROOT)
$failed = $false
Get-ChildItem -LiteralPath $root -Filter '*.ps1' -File | ForEach-Object {
    $tokens = $null
    $errors = $null
    [System.Management.Automation.Language.Parser]::ParseFile($_.FullName, [ref]$tokens, [ref]$errors) | Out-Null
    if($errors.Count -gt 0){
        $failed = $true
        Write-Host ("PowerShell parse FAILED: " + $_.Name) -ForegroundColor Red
        foreach($e in $errors){ Write-Host ("  line {0}: {1}" -f $e.Extent.StartLineNumber,$e.Message) -ForegroundColor Red }
    }
}
if($failed){ exit 98 }
Write-Host 'PowerShell parser preflight: PASS' -ForegroundColor Green
exit 0
