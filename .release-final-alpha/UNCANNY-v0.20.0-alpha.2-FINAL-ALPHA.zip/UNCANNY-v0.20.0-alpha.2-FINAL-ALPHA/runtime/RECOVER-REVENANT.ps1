﻿param([Parameter(Mandatory=$true)][string]$TargetDir,[string]$Textures='')
Set-StrictMode -Version Latest
$ErrorActionPreference='Stop'
$scriptPath=[string]$MyInvocation.MyCommand.Path
if([string]::IsNullOrWhiteSpace($scriptPath)){$scriptPath=[string]$PSCommandPath}
if([string]::IsNullOrWhiteSpace($scriptPath)){throw 'REVENANT recovery script path is unavailable; backups remain untouched.'}
$root=[IO.Path]::GetFullPath((Split-Path -Parent $scriptPath))
. (Join-Path (Split-Path -Parent $MyInvocation.MyCommand.Path) 'UNCANNY-InstallCommon.ps1')
$TargetDir=(Resolve-Path -LiteralPath $TargetDir).Path
$state=Join-Path $TargetDir '.uncanny'
$journals=Join-Path $state 'revenant-proof'
if(!(Test-Path -LiteralPath $journals)){return}
$pending=@(Get-ChildItem -LiteralPath $journals -Directory|Where-Object{(Test-Path -LiteralPath (Join-Path $_.FullName 'manifest.tsv')) -and !(Test-Path -LiteralPath (Join-Path $_.FullName 'restored.ok'))})
if(!$pending.Count){return}
Assert-UncannyClosed $TargetDir @('pcsx2-qt.exe','pcsx2-qt.uncanny-original.exe','UNCANNY.Revenant.exe','UNCANNY.AssetForge.exe')
if(!$Textures){
  $pcsx2Paths=Join-Path $state 'pcsx2-paths.ini'
  if(Test-Path -LiteralPath $pcsx2Paths -PathType Leaf){$Textures=Get-UncannyIni $pcsx2Paths 'Paths' 'Textures'}
}
if(!$Textures){throw 'Pending proof found. Supply -Textures with the exact configured texture root; backups have been preserved.'}
$worker=Join-Path $root 'dist\UNCANNY.Revenant64.exe'
if(!(Test-Path -LiteralPath $worker)){$worker=Join-Path $TargetDir 'UNCANNY.Revenant.exe'}
if(!(Test-Path -LiteralPath $worker)){throw 'Recovery worker missing. Use the complete UNCANNY release package. Backups remain untouched.'}
& $worker --recover-proofs $Textures --state-root $state
if($LASTEXITCODE -ne 0){throw 'STOP_PROOF_RESTORE_CONFLICT: verified backups retained; resolve conflicting files before launch.'}
Write-Host 'REVENANT proof recovery: original SHA-256 hashes restored. Launching PCSX2 rebuilds its cache.' -ForegroundColor Green
