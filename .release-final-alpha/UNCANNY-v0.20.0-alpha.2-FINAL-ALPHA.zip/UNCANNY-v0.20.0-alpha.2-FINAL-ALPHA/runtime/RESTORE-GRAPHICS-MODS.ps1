﻿param([Parameter(Mandatory=$true)][string]$TargetDir,[Parameter(Mandatory=$true)][string]$BackupDir)
$ErrorActionPreference='Stop'
. (Join-Path (Split-Path -Parent $MyInvocation.MyCommand.Path) 'UNCANNY-InstallCommon.ps1')
. (Join-Path (Split-Path -Parent $MyInvocation.MyCommand.Path) 'UNCANNY-Environment.ps1')
$names=@(Get-ChildItem -LiteralPath $TargetDir -Filter '*.exe' -File|ForEach-Object Name);Assert-UncannyClosed $TargetDir $names
Restore-UncannyEnvironment $TargetDir $BackupDir
