﻿param([Parameter(Mandatory=$true)][string]$TexturePack)
Set-StrictMode -Version Latest
$ErrorActionPreference='Stop'
. (Join-Path (Split-Path -Parent $MyInvocation.MyCommand.Path) 'UNCANNY-InstallCommon.ps1')
Assert-UncannyNoReparsePath $TexturePack
$pack=(Resolve-Path -LiteralPath $TexturePack).Path
if((Split-Path -Leaf $pack) -cnotmatch '^[A-Z]{4}[0-9]{5}$'){throw 'Select the existing PPSSPP game texture pack.'}
if(@(Get-CimInstance Win32_Process -ErrorAction Stop|Where-Object {$_.Name -match '^PPSSPP.*\.exe$'}).Count){throw 'Close PPSSPP before restoring its texture pack.'}
$lockPath=Join-Path $pack '.uncanny-ppsspp.lock';Assert-UncannyNoReparsePath $lockPath
$packLock=[IO.File]::Open($lockPath,[IO.FileMode]::OpenOrCreate,[IO.FileAccess]::ReadWrite,[IO.FileShare]::None)
try{
$state=Join-Path $pack '.uncanny-ppsspp';Assert-UncannyNoReparsePath $state
if(!(Test-Path -LiteralPath $state)){throw 'No UNCANNY PPSSPP ownership receipts found.'}
$restores=Join-Path $state 'restores';Assert-UncannyNoReparsePath $restores
New-Item -ItemType Directory -Path $restores -Force|Out-Null
function Save-RestoreJournal($Object,[string]$Path){
 $temp=$Path+'.tmp';Assert-UncannyNoReparsePath $temp
 $Object|ConvertTo-Json -Depth 8|Set-Content -LiteralPath $temp -Encoding UTF8
 $old=if(Test-Path -LiteralPath $Path){(Get-FileHash -LiteralPath $Path).Hash}else{''}
 try{Set-UncannyVerifiedFile $temp $Path (Get-FileHash -LiteralPath $temp).Hash $old}finally{Remove-Item -LiteralPath $temp -Force -ErrorAction SilentlyContinue}
}
function Complete-Restore([string]$Journal){
 Assert-UncannyNoReparsePath $Journal;$folder=Split-Path -Parent $Journal
 $m=Get-Content -LiteralPath $Journal -Raw|ConvertFrom-Json
 if($m.schema -ne 1 -or $m.pack -ine $pack -or $m.phase -notin @('prepared','complete')){throw 'Invalid PPSSPP restore journal.'}
 if($m.phase -eq 'complete'){return}
 foreach($f in $m.files){
  if($f.name -cnotmatch '^[0-9A-Fa-f]{24}(?:_[0-7])?\.png(?:\.(?:receipt|pending))?$' -or $f.sha256 -notmatch '^[0-9A-Fa-f]{64}$'){throw 'Invalid ownership record.'}
  $root=if($f.name -match '\.(receipt|pending)$'){$state}else{$pack}
  $source=Join-Path $root $f.name;$saved=Join-Path $folder ($f.name+'.bin')
  Assert-UncannyNoReparsePath $source;Assert-UncannyNoReparsePath $saved
  if(Test-Path -LiteralPath $source){if((Get-FileHash -LiteralPath $source).Hash -ine $f.sha256){throw "Modified file retained; restore stopped: $source"}}
  elseif(!(Test-Path -LiteralPath $saved)){throw 'Restore journal has neither source nor archived bytes.'}
  if((Test-Path -LiteralPath $saved) -and (Get-FileHash -LiteralPath $saved).Hash -ine $f.sha256){throw 'Restore archive hash mismatch.'}
 }
 foreach($f in $m.files){
  $root=if($f.name -match '\.(receipt|pending)$'){$state}else{$pack}
  $source=Join-Path $root $f.name;$saved=Join-Path $folder ($f.name+'.bin')
  if(Test-Path -LiteralPath $source){
   Assert-UncannyNoReparsePath $source
   if((Get-FileHash -LiteralPath $source).Hash -ine $f.sha256){throw 'File changed during restore; retained.'}
   if(Test-Path -LiteralPath $saved){Remove-Item -LiteralPath $source}else{[IO.File]::Move($source,$saved)}
  }
 }
 $m.phase='complete';Save-RestoreJournal $m $Journal
}
Get-ChildItem -LiteralPath $restores -Directory|ForEach-Object{$journal=Join-Path $_.FullName 'manifest.json';if(Test-Path -LiteralPath $journal){Complete-Restore $journal}}
$ownership=@{}
foreach($record in Get-ChildItem -LiteralPath $state -File|Where-Object {$_.Extension -in @('.receipt','.pending')}|Sort-Object @{Expression={if($_.Extension -eq '.pending'){1}else{0}}}){
 Assert-UncannyNoReparsePath $record.FullName
 $name=$record.Name -replace '\.(receipt|pending)$',''
 if($name -cnotmatch '^[0-9A-Fa-f]{24}(?:_[0-7])?\.png$'){throw 'Invalid texture receipt name.'}
 $parts=@((Get-Content -LiteralPath $record.FullName -Raw).Trim() -split '\s+')
 if($parts.Count -ne 3 -or $parts[0] -notmatch '^[0-9a-fA-F]{64}$' -or $parts[1] -notmatch '^[0-9a-fA-F]{64}$'){throw 'Invalid texture receipt contents.'}
 $dest=Join-Path $pack $name;Assert-UncannyNoReparsePath $dest
 if(Test-Path -LiteralPath $dest){$current=(Get-FileHash -LiteralPath $dest).Hash;if($current -ieq $parts[1]){$ownership[$name]=$parts[1]}}
}
$files=@()
foreach($record in Get-ChildItem -LiteralPath $state -File|Where-Object {$_.Extension -in @('.receipt','.pending')}){
 $name=$record.Name -replace '\.(receipt|pending)$','';$dest=Join-Path $pack $name
 if((Test-Path -LiteralPath $dest) -and !$ownership.ContainsKey($name)){throw "User-modified replacement retained: $name"}
 $files+=@{name=$record.Name;sha256=(Get-FileHash -LiteralPath $record.FullName).Hash}
}
foreach($name in $ownership.Keys){$files+=@{name=$name;sha256=$ownership[$name]}}
if(!$files.Count){Write-Host 'No active UNCANNY replacements to restore.';return}
$folder=Join-Path $restores ([guid]::NewGuid().ToString('N'));New-Item -ItemType Directory -Path $folder|Out-Null
$journal=Join-Path $folder 'manifest.json';Save-RestoreJournal @{schema=1;pack=$pack;phase='prepared';files=$files} $journal
Complete-Restore $journal
Write-Host "UNCANNY-owned replacements removed from the active pack; exact bytes retained in $folder. Restart PPSSPP to observe the original assets. User replacements and source dumps were preserved."
}finally{$packLock.Dispose()}
