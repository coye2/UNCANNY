﻿param(
 [Parameter(Mandatory=$true)][string]$TexturePack,
 [Parameter(Mandatory=$true)][string]$NeuralExe,
 [ValidateRange(0,3)][int]$Strength=2,
 [ValidateRange(1,128)][int]$MaxAssets=16,
 [ValidateRange(10,1800)][int]$BudgetSeconds=120
)
Set-StrictMode -Version Latest
$ErrorActionPreference='Stop'
. (Join-Path (Split-Path -Parent $MyInvocation.MyCommand.Path) 'UNCANNY-InstallCommon.ps1')
$pack=(Resolve-Path -LiteralPath $TexturePack).Path
$runner=(Resolve-Path -LiteralPath $NeuralExe).Path
Assert-UncannyNoReparsePath $pack
$running=@(Get-CimInstance Win32_Process -ErrorAction Stop|Where-Object {$_.Name -match '(?i)^PPSSPP.*\.exe$'})
if($running.Count){throw 'Close PPSSPP before rebuilding this texture pack.'}
$arch=if([Environment]::Is64BitOperatingSystem){'64'}else{'32'}
if(!(Test-UncannyBuild $env:UNCANNY_PACKAGE_ROOT $arch)){throw 'The worker does not match the release/build manifest.'}
$worker=Join-Path $env:UNCANNY_PACKAGE_ROOT "dist/UNCANNY.Revenant$arch.exe"
& $worker --ppsspp-pack $pack $runner $Strength $MaxAssets $BudgetSeconds
if($LASTEXITCODE -ne 0){throw "Pack builder stopped with code $LASTEXITCODE. Inspect the message and .uncanny-ppsspp/last-run.tsv; existing user replacements are retained."}
