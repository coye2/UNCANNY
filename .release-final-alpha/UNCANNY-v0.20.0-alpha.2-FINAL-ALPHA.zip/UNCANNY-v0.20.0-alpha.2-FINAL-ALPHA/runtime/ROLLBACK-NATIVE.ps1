﻿param([Parameter(Mandatory=$true)][string]$TargetDir,[string]$BackupDir='', [string]$TargetExe='', [switch]$FailedInstall,[switch]$AllLayers)
Set-StrictMode -Version Latest
$ErrorActionPreference='Stop'
$root=[IO.Path]::GetFullPath((Split-Path -Parent $MyInvocation.MyCommand.Path))
. (Join-Path (Split-Path -Parent $MyInvocation.MyCommand.Path) 'UNCANNY-InstallCommon.ps1')
. (Join-Path (Split-Path -Parent $MyInvocation.MyCommand.Path) 'UNCANNY-Environment.ps1')
Assert-UncannyNoReparsePath $TargetDir
$TargetDir=(Resolve-Path -LiteralPath $TargetDir).Path
$state=Join-Path $TargetDir '.uncanny'
if($TargetExe){
  if(![IO.Path]::IsPathRooted($TargetExe)){throw 'Rollback target EXE must be an absolute path.'}
  $requestedTarget=[IO.Path]::GetFullPath($TargetExe)
  $targetLeaf=[IO.Path]::GetFileName($requestedTarget)
  if([string]::IsNullOrWhiteSpace($targetLeaf) -or [IO.Path]::GetExtension($targetLeaf) -ine '.exe'){throw 'Rollback target selector must identify an EXE.'}
  $TargetExe=Join-Path $TargetDir $targetLeaf
  Assert-UncannyNoReparsePath $TargetExe
}
function Remove-UncannyManagedResidue {
  $remaining=@(Get-UncannyRollbackChoices)
  if($remaining.Count){throw 'UNCANNY cleanup refused because an unrestored installation layer remains.'}
  if(Test-Path -LiteralPath $state){
    Assert-UncannyNoReparsePath $state
    Remove-Item -LiteralPath $state -Recurse -Force -ErrorAction Stop
  }
  foreach($pattern in @(
    'UNCANNY-RUNTIME-TRACE-*.log',
    'UNCANNY-NATIVE-STATUS-*.txt',
    'UNCANNY-DLSS5-PROVIDER-*.txt',
    'UNCANNY-SHADER-*.log',
    'UNCANNY-LAUNCH-SESSION-*.log'
  )){
    foreach($file in @(Get-ChildItem -LiteralPath $TargetDir -File -Filter $pattern -ErrorAction SilentlyContinue)){
      Assert-UncannyNoReparsePath $file.FullName
      Remove-Item -LiteralPath $file.FullName -Force -ErrorAction SilentlyContinue
    }
  }
}
function Get-UncannyRollbackChoices {
  @(
    Get-ChildItem -LiteralPath $state -Directory -Filter 'backup-native-*' -ErrorAction SilentlyContinue |
      Sort-Object Name -Descending |
      Where-Object { !(Test-Path -LiteralPath (Join-Path $_.FullName 'rollback.ok')) } |
      Where-Object {
        if(!$TargetExe){return $true}
        $mp=Join-Path $_.FullName 'manifest.json'
        if(!(Test-Path -LiteralPath $mp)){return $false}
        try{
          $cm=Get-Content -LiteralPath $mp -Raw|ConvertFrom-Json
          if(!$cm.target){return $false}
          $candidateRaw=[IO.Path]::GetFullPath([string]$cm.target)
          $candidateLeaf=[IO.Path]::GetFileName($candidateRaw)
          if([string]::IsNullOrWhiteSpace($candidateLeaf)){return $false}
          $candidate=Join-Path $TargetDir $candidateLeaf
          return $candidate -ieq $TargetExe
        }catch{return $false}
      }
  )
}
if($AllLayers -and !$BackupDir){
  $restored=0
  while($restored -lt 16){
    $layers=@(Get-UncannyRollbackChoices)
    if(!$layers.Count){break}
    & $PSCommandPath -TargetDir $TargetDir -BackupDir $layers[0].FullName -TargetExe $TargetExe -FailedInstall:$FailedInstall
    $restored++
  }
  $remaining=@(Get-UncannyRollbackChoices)
  if($remaining.Count){throw 'Remove stopped after 16 rollback layers. No additional files were changed; inspect the retained backups before continuing.'}
  if(!$restored){throw 'No unrestored UNCANNY backup matches the exact selected installation target.'}
  Remove-UncannyManagedResidue
  Write-Host ("UNCANNY full-stack rollback complete. Restored {0} installation layer(s); managed state and diagnostics removed." -f $restored) -ForegroundColor Green
  return
}
if(!$BackupDir){
  $choices=@(Get-UncannyRollbackChoices)
  if(!$choices.Count){throw 'No unrestored UNCANNY backup matches the exact selected installation target.'}
  $BackupDir=$choices[0].FullName
}
$BackupDir=(Resolve-Path -LiteralPath $BackupDir).Path
if(!(Test-UncannyPathWithin $BackupDir $state)){throw 'Backup must be inside this target .uncanny directory.'}
$m=Get-Content -LiteralPath (Join-Path $BackupDir 'manifest.json') -Raw|ConvertFrom-Json
function Convert-UncannyLegacyRollbackManifest([object]$Manifest){
  if(!$Manifest.PSObject.Properties['target'] -or !$Manifest.target){throw 'Rollback manifest does not identify its original target. No files were changed.'}
  $manifestTargetRaw=[IO.Path]::GetFullPath([string]$Manifest.target)
  $manifestTargetLeaf=[IO.Path]::GetFileName($manifestTargetRaw)
  if([string]::IsNullOrWhiteSpace($manifestTargetLeaf) -or [IO.Path]::GetExtension($manifestTargetLeaf) -ine '.exe'){throw 'Rollback manifest target is not a valid EXE. No files were changed.'}
  $manifestParentRaw=[IO.Path]::GetFullPath((Split-Path -Parent $manifestTargetRaw))
  $manifestParent=(Resolve-Path -LiteralPath $manifestParentRaw).Path
  Assert-UncannyNoReparsePath $manifestParent
  $targetBoundary=$TargetDir.TrimEnd([IO.Path]::DirectorySeparatorChar,[IO.Path]::AltDirectorySeparatorChar)
  if($Manifest.PSObject.Properties['targetDir'] -and $Manifest.targetDir){
    $recordedDirRaw=[IO.Path]::GetFullPath([string]$Manifest.targetDir)
    $recordedDir=(Resolve-Path -LiteralPath $recordedDirRaw).Path
    $recordedBoundary=$recordedDir.TrimEnd([IO.Path]::DirectorySeparatorChar,[IO.Path]::AltDirectorySeparatorChar)
    $rawRecordedBoundary=$recordedDirRaw.TrimEnd([IO.Path]::DirectorySeparatorChar,[IO.Path]::AltDirectorySeparatorChar)
    $rawManifestBoundary=$manifestParentRaw.TrimEnd([IO.Path]::DirectorySeparatorChar,[IO.Path]::AltDirectorySeparatorChar)
    if($manifestParent.TrimEnd([IO.Path]::DirectorySeparatorChar,[IO.Path]::AltDirectorySeparatorChar) -ine $recordedBoundary -and $rawManifestBoundary -ine $rawRecordedBoundary){throw 'Rollback manifest target escapes its recorded installation directory. No files were changed.'}
    $Manifest.targetDir=$TargetDir
  }else{
    if($manifestParent.TrimEnd([IO.Path]::DirectorySeparatorChar,[IO.Path]::AltDirectorySeparatorChar) -ine $targetBoundary){throw 'Rollback manifest belongs to a different installation directory. No files were changed.'}
    $Manifest|Add-Member -NotePropertyName targetDir -NotePropertyValue $TargetDir -Force
  }
  $manifestTarget=Join-Path $TargetDir $manifestTargetLeaf
  if($TargetExe -and $manifestTarget -ine $TargetExe){throw 'Rollback manifest target does not match the selected game/emulator. No files were changed.'}
  if(!$Manifest.PSObject.Properties['allowedRoots'] -or !@($Manifest.allowedRoots).Count){
    $roots=[Collections.Generic.List[string]]::new();$roots.Add($TargetDir)
    foreach($legacyFile in @($Manifest.files)){
      if(!$legacyFile.PSObject.Properties['destination'] -or !$legacyFile.destination){throw 'Legacy rollback entry is missing a destination. No files were changed.'}
      $dest=[IO.Path]::GetFullPath([string]$legacyFile.destination)
      if(Test-UncannyPathWithin $dest $TargetDir){continue}
      $ownership=Get-UncannyOwnershipClass $dest $TargetDir
      if($ownership -ne 'HOST_CONFIG'){throw "Legacy rollback contains an untrusted external destination; retained: $dest"}
      $hostRoot=Split-Path -Parent $dest
      if(!$roots.Contains($hostRoot)){$roots.Add($hostRoot)}
    }
    $Manifest|Add-Member -NotePropertyName allowedRoots -NotePropertyValue @($roots) -Force
    Write-Host 'Migrated a verified legacy UNCANNY rollback manifest in memory.' -ForegroundColor DarkCyan
  }else{
    $normalized=[Collections.Generic.List[string]]::new()
    foreach($rootEntry in @($Manifest.allowedRoots)){
      if(!$rootEntry){continue}
      $fullRoot=[IO.Path]::GetFullPath([string]$rootEntry)
      if(!$normalized.Contains($fullRoot)){$normalized.Add($fullRoot)}
    }
    if(!$normalized.Contains($TargetDir)){$normalized.Add($TargetDir)}
    $Manifest.allowedRoots=@($normalized)
  }
  return $Manifest
}
$m=Convert-UncannyLegacyRollbackManifest $m
Request-UncannyIdleLauncherStop $TargetDir
$preservedOriginalName=([IO.Path]::GetFileNameWithoutExtension([string]$m.target)+'.uncanny-original.exe')
Assert-UncannyClosed $TargetDir @([IO.Path]::GetFileName($m.target),$preservedOriginalName,'UNCANNY.Launch.exe','UNCANNY.NativeLauncher.exe','UNCANNY.Revenant.exe','UNCANNY.AssetForge.exe','UNCANNY.ControlDeck.exe')
$engineFiles=@{};$engineJournal=Join-Path $TargetDir '.uncanny/engine-transaction/journal.json'
if(Test-Path -LiteralPath $engineJournal){. (Join-Path (Split-Path -Parent $MyInvocation.MyCommand.Path) 'UNCANNY-EngineCommon.ps1');Restore-UncannyEngineBase $TargetDir -PreflightOnly;$engineState=Get-Content -LiteralPath $engineJournal -Raw|ConvertFrom-Json;foreach($file in $engineState.files){$engineFiles[(Join-Path $TargetDir $file.name)]=$file}}
& (Join-Path (Split-Path -Parent $MyInvocation.MyCommand.Path) 'RECOVER-REVENANT.ps1') -TargetDir $TargetDir
$conflicts=[Collections.Generic.List[string]]::new()
function Get-RollbackOwnership([object]$File,[string]$Destination){
  if($File.PSObject.Properties['ownershipClass'] -and $File.ownershipClass){return [string]$File.ownershipClass}
  if($m.target -and ([IO.Path]::GetFullPath([string]$m.target) -ieq $Destination)){return 'UNCANNY_MANAGED'}
  return Get-UncannyOwnershipClass $Destination $TargetDir
}
function Remove-UncannyIniKey([string]$Path,[string]$Section,[string]$Key){
  if(!(Test-Path -LiteralPath $Path)){return}
  $lines=@(Get-Content -LiteralPath $Path);$out=[Collections.Generic.List[string]]::new();$inside=$false
  foreach($line in $lines){
    if($line -match '^\s*\[([^\]]+)\]\s*$'){$inside=$Matches[1] -ieq $Section;$out.Add($line);continue}
    if($inside -and $line -match ('^\s*'+[regex]::Escape($Key)+'\s*=')){continue};$out.Add($line)
  }
  [IO.File]::WriteAllLines($Path,$out,[Text.UTF8Encoding]::new($false))
}
function Restore-UncannyPCSX2OwnedKeys([string]$Destination,[string]$Backup){
  if(!(Test-Path -LiteralPath $Destination) -or !(Test-Path -LiteralPath $Backup)){return}
  $owned=@(
    @('EmuCore/GS','DumpReplaceableTextures','true'),@('EmuCore/GS','DumpReplaceableMipmaps','false'),
    @('EmuCore/GS','DumpTexturesWithFMVActive','true'),@('EmuCore/GS','DumpDirectTextures','true'),
    @('EmuCore/GS','DumpPaletteTextures','true'),@('EmuCore/GS','LoadTextureReplacements','true'),
    @('EmuCore/GS','LoadTextureReplacementsAsync','true'),@('EmuCore/GS','PrecacheTextureReplacements','false'),
    @('EmuCore/GS','OsdShowTextureReplacements','true'),@('Hotkeys','ReloadTextureReplacements','Keyboard/Control & Keyboard/Shift & Keyboard/F10')
  )
  foreach($entry in $owned){
    $section=$entry[0];$key=$entry[1];$installed=$entry[2];$current=Get-UncannyIni $Destination $section $key
    if($current -cne $installed){continue}
    $before=Get-UncannyIni $Backup $section $key
    if($before){Set-UncannyIni $Destination $section $key $before}else{Remove-UncannyIniKey $Destination $section $key}
  }
}
$files=@($m.files)
foreach($f in $files){
  $dest=[IO.Path]::GetFullPath($f.destination);Assert-UncannyNoReparsePath $dest
  $allowed=@($m.allowedRoots|Where-Object{Test-UncannyPathWithin $dest $_})
  if(!$allowed.Count){throw "Destination escapes recorded target/configuration roots: $dest"}
  $backup=Join-Path $BackupDir $f.backup;Assert-UncannyNoReparsePath $backup
  if(!(Test-UncannyPathWithin $backup $BackupDir)){throw 'Invalid backup path.'}
  if($f.existed -and (!(Test-Path -LiteralPath $backup) -or (Get-UncannySHA256 $backup) -ine $f.beforeSHA256)){throw "Backup hash mismatch: $backup"}
  $ownership=Get-RollbackOwnership $f $dest
  if(Test-Path -LiteralPath $dest){
    $current=Get-UncannySHA256 $dest
    if($current -ine $f.installedSHA256 -and $current -ine $f.beforeSHA256){
      if($ownership -in @('UNCANNY_MUTABLE_RUNTIME','HOST_CONFIG')){continue}
      $managed=$engineFiles.ContainsKey($dest) -and $engineFiles[$dest].before -ieq $f.installedSHA256 -and $engineFiles[$dest].after -ieq $current
      if(!$managed){$conflicts.Add($dest)}
    }
  }
}
if($conflicts.Count){throw ('Rollback preserved original/user files changed since installation. UNCANNY did not overwrite them: '+($conflicts -join '; '))}
$plannedRemovals=@{};foreach($file in $files){$dest=[IO.Path]::GetFullPath($file.destination);$ownership=Get-RollbackOwnership $file $dest;if(!$file.existed -and $ownership -ne 'HOST_CONFIG'){$plannedRemovals[$dest]=$file.installedSHA256}}
if($m.PSObject.Properties['graphicsBackup'] -and $m.graphicsBackup){Restore-UncannyEnvironment $TargetDir $m.graphicsBackup -PreflightOnly -PlannedRemovals $plannedRemovals}
if($engineFiles.Count){Restore-UncannyEngineBase $TargetDir}
[Array]::Reverse($files)
foreach($f in $files){
  $dest=[IO.Path]::GetFullPath($f.destination);Assert-UncannyNoReparsePath $dest
  $ownership=Get-RollbackOwnership $f $dest
  $current=if(Test-Path -LiteralPath $dest){Get-UncannySHA256 $dest}else{''}
  $backup=Join-Path $BackupDir $f.backup
  if($ownership -eq 'HOST_CONFIG'){
    if($f.existed){Restore-UncannyPCSX2OwnedKeys $dest $backup}
    continue
  }
  if($ownership -eq 'UNCANNY_MUTABLE_RUNTIME'){
    if($f.existed){Set-UncannyVerifiedFile $backup $dest $f.beforeSHA256 $current}
    elseif(Test-Path -LiteralPath $dest){Remove-Item -LiteralPath $dest -Force}
    continue
  }
  if($current -and $current -ine $f.installedSHA256 -and $current -ine $f.beforeSHA256){throw "File changed during rollback; retained: $dest"}
  if($f.existed){Set-UncannyVerifiedFile $backup $dest $f.beforeSHA256 $current}
  elseif($current){Remove-Item -LiteralPath $dest -Force}
}
if($m.PSObject.Properties['graphicsBackup'] -and $m.graphicsBackup){Restore-UncannyEnvironment $TargetDir $m.graphicsBackup|Out-Null}
'ALL_RECORDED_FILES_RESTORED'|Set-Content -LiteralPath (Join-Path $BackupDir 'rollback.ok') -Encoding ASCII
Write-Host 'UNCANNY rollback complete. Verified backups retained; user-created textures and profiles preserved.' -ForegroundColor Green
