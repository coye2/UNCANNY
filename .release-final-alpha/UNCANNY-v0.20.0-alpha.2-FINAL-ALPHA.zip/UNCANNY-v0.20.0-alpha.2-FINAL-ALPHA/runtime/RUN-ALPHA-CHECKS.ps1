﻿param([switch]$Consent)
Set-StrictMode -Version Latest
$ErrorActionPreference='Stop'
$root=[IO.Path]::GetFullPath($env:UNCANNY_PACKAGE_ROOT)
Write-Host 'UNCANNY v0.20 ELYSIUM local release checks'
Write-Host 'Checks encrypted shader decoding/compilation and reversible proof-journal/codec fixtures.'
Write-Host 'No game folder is scanned, no game is attached, and no GPU inference is attempted.'
if(!$Consent -and (Read-Host 'Run these local checks and save reports? Type YES') -cne 'YES'){exit 0}
$version=Get-Content -LiteralPath (Join-Path $root 'VERSION.json') -Raw | ConvertFrom-Json
if($version.revision -ne 'release-alpha.1.elysium' -or $version.abi -ne 140){throw 'Extract the complete UNCANNY v0.20 ELYSIUM package.'}
$build=Get-Content -LiteralPath (Join-Path $root 'public-build.json') -Raw | ConvertFrom-Json
$outDir=Join-Path $root ('.uncanny/reports/alpha-local-'+[guid]::NewGuid().ToString('N'))
New-Item -ItemType Directory -Path $outDir -Force | Out-Null
$results=@()
foreach($bits in @('32','64')){
 foreach($test in @('protected-resources','proof-journal','revenant-commit')){
  $name=$test+$bits
  $relative='diagnostics/'+$name+'.exe';$exe=Join-Path $root $relative
  $expected=@($build.diagnostics | Where-Object {$_.file -eq $relative})
  if($expected.Count -ne 1 -or !(Test-Path -LiteralPath $exe -PathType Leaf)){throw ('Missing diagnostic: '+$relative)}
  $hash=(Get-FileHash -LiteralPath $exe -Algorithm SHA256).Hash.ToLowerInvariant()
  if($hash -ne $expected[0].sha256){throw ('Diagnostic integrity failed: '+$relative)}
  $status='NOT_RUN';$code=$null;$argsForTest=@();if($test -eq 'protected-resources'){$argsForTest=@('--compile')}
  try{
   $start=@{FilePath=$exe;WorkingDirectory=$root;PassThru=$true;RedirectStandardOutput=(Join-Path $outDir ($name+'.txt'));RedirectStandardError=(Join-Path $outDir ($name+'-error.txt'))}
   if($argsForTest.Count){$start.ArgumentList=$argsForTest}
   $process=Start-Process @start
   if(!$process.WaitForExit(60000)){$process.Kill();$status='TIMEOUT'}
   else{$process.WaitForExit();$process.Refresh();$code=$process.ExitCode;$status=if($code -eq 0){'PASS'}else{'FAIL'}}
  }catch{$status='LAUNCH_FAILED';$_ | Out-String | Set-Content -LiteralPath (Join-Path $outDir ($name+'-error.txt')) -Encoding UTF8}
  $results+=[ordered]@{test=$test;architecture=$bits;status=$status;exit_code=$code;sha256=$hash}
  Write-Host ($name+': '+$status)
 }
}
[ordered]@{schema='UNCANNY-ALPHA-LOCAL-1';revision=$version.revision;results=$results;scope='Windows CNG, shader compiler, WIC and filesystem fixtures. No emulator proof, GPU inference or game certification.'} | ConvertTo-Json -Depth 6 | Set-Content -LiteralPath (Join-Path $outDir 'results.json') -Encoding UTF8
Write-Host ('Reports: '+$outDir)
if(@($results | Where-Object {$_.status -ne 'PASS'}).Count){exit 1}
exit 0
