﻿param([ValidateSet('32','64','both')][string]$Architecture='both',[ValidateRange(30,180)][int]$TimeoutSeconds=90,[switch]$Consent,[switch]$HardwareInteropOnly,[switch]$IncludeHardwareInterop,[switch]$IncludeNeural11,[switch]$IncludeDeepNeural,[switch]$IncludeNativeLegacy,[switch]$IncludeNativeLegacyNeural,[switch]$IncludeLegacyOn12,[switch]$IncludeNeural9,[string]$ProviderRoot='',[switch]$IncludeFullscreenHome,[switch]$IncludeHomeProducer,[switch]$IncludeCursor)
$ErrorActionPreference='Stop'
Write-Host 'Runs synthetic graphics tests in separate processes. No game attachment or provider installation.'
if($IncludeFullscreenHome){Write-Host 'The optional HOME test enters exclusive fullscreen, presses HOME and tests keyboard controls in its own window.'}
if($IncludeDeepNeural){Write-Host 'Deep-neural acceptance requires actual Feature-18 evaluations. A bypassed second stage does NOT pass this test.'}
Write-Host 'WARP validates software-device behavior; D3D9 requires an available HAL device. Results do not certify a game.'
if(!$Consent -and (Read-Host 'Run the synthetic tests and create a local report? Type YES') -cne 'YES'){exit 0}
$session=Join-Path $env:UNCANNY_PACKAGE_ROOT ('.uncanny/reports/synthetic-'+[guid]::NewGuid().ToString('N'));New-Item -ItemType Directory -Path $session -Force|Out-Null
$build=Get-Content -LiteralPath (Join-Path $env:UNCANNY_PACKAGE_ROOT 'public-build.json') -Raw | ConvertFrom-Json
$results=@();$architectures=if($Architecture -eq 'both'){@('32','64')}else{@($Architecture)}
foreach($arch in $architectures){
 $tests=@('--d3d9','--d3d11','--d3d11-msaa','--d3d12','--motion','--depth','--geometry','--pc9','--interop11','--materials9','--deck9','--deck11','--deck12','--hud-guard');if($IncludeNativeLegacy){$tests+=@('--d3d10','--d3d10-1','--d3d10-msaa','--deck10')};if($IncludeNativeLegacyNeural){$tests+=@('--native-neural9','--neural10')};if($IncludeHardwareInterop){$tests+=@('--interop11-hardware')};if($IncludeNeural11){$tests+=@('--neural11')};if($IncludeDeepNeural){$tests+=@('--neural11-deep')};if($IncludeLegacyOn12){$tests+=@('--d3d9on12','--bootstrap9','--bootstrap9-ex')};if($IncludeNeural9){$tests+=@('--neural9','--neural9-auto','--neural9-auto-ex')};if($IncludeHomeProducer){$tests+=@('--home-producer')};if($IncludeCursor){$tests+=@('--cursor')};if($IncludeFullscreenHome){$tests+=@('--home11-windowed','--home11-fullscreen')}
 if($HardwareInteropOnly){$tests=@('--interop11-hardware')}
 foreach($test in $tests){
  $name=$test.Substring(2)+'-'+$arch;$exe=Join-Path $env:UNCANNY_PACKAGE_ROOT "diagnostics/gpu-acceptance$arch.exe";$out=Join-Path $session ($name+'.txt');$err=Join-Path $session ($name+'-error.txt');$status='UNAVAILABLE';$code=$null
  try{
   if(Test-Path -LiteralPath $exe){$matching=@($build.diagnostics | Where-Object {$_.file -eq ('diagnostics/gpu-acceptance'+$arch+'.exe')});if($matching.Count -ne 1 -or (Get-FileHash -LiteralPath $exe -Algorithm SHA256).Hash -ine $matching[0].sha256){throw 'Diagnostic integrity check failed.'};$work=Join-Path $session $name;$testArguments=@($test);if($test -in @('--native-neural9','--neural10','--neural9-auto','--neural9-auto-ex','--neural9','--neural11','--neural11-deep','--home11-fullscreen','--home11-windowed','--home-producer')){if(!$ProviderRoot -or !(Test-Path -LiteralPath $ProviderRoot -PathType Container)){throw 'Use -ProviderRoot with the installed game folder containing the matching Control Deck and any required neural provider.'};$testArguments+=@('--provider-root',('"'+(Resolve-Path -LiteralPath $ProviderRoot).Path+'"'))};New-Item -ItemType Directory -Path $work|Out-Null;$proc=Start-Process -FilePath $exe -WorkingDirectory $work -ArgumentList $testArguments -PassThru -RedirectStandardOutput $out -RedirectStandardError $err
    if(!$proc.WaitForExit($TimeoutSeconds*1000)){$status='TIMEOUT';Stop-Process -Id $proc.Id -ErrorAction SilentlyContinue}
    else{$proc.WaitForExit();$proc.Refresh();$code=$proc.ExitCode;$status=if($code -eq 0){'PASS'}elseif($code -eq 77){'UNAVAILABLE'}else{'FAIL'}}
   }
  }catch{$status='LAUNCH_FAILED';$_|Out-String|Set-Content -LiteralPath $err -Encoding UTF8}
  $results+=[ordered]@{test=$test;architecture=$arch;status=$status;exit_code=$code;binary_sha256=$(if(Test-Path -LiteralPath $exe){(Get-FileHash -LiteralPath $exe -Algorithm SHA256).Hash.ToLowerInvariant()}else{$null})}
  Write-Host "$name : $status"
 }
}
[ordered]@{schema='UNCANNY-SYNTHETIC-GPU-1';results=$results;scope='Synthetic production processors; --pc9 uses declared synthetic replacement data. --interop11 and --interop11-hardware are not neural inference. Optional --neural9/11 require a user-installed provider and NVIDIA hardware; --d3d9on12 requires Windows On12; --home11-fullscreen uses the production panel on the current desktop. Native legacy modes use production D3D9 fallback/D3D10 paths on hardware; neural modes require an installed matching helper/provider. The optional --neural11-deep test requires a real second provider evaluation and production policy eligibility, not transport-only output. It does not prove perceptual improvement, three-stage acceptance, neural asset inference or game compatibility.';game_compatibility='NOT_TESTED'}|ConvertTo-Json -Depth 6|Set-Content -LiteralPath (Join-Path $session 'results.json') -Encoding UTF8
Write-Host ('Saved: '+$session)
$notPassed=@($results | Where-Object {$_.status -ne 'PASS'})
if($notPassed.Count -gt 0){Write-Host 'One or more tests did not pass. See results.json for FAIL, TIMEOUT, or UNAVAILABLE.';exit 1}
exit 0
