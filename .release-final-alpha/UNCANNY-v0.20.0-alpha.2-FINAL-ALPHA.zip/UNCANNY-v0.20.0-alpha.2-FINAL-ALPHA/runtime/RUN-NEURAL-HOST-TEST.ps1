﻿param([ValidateSet('32','64','both')][string]$Architecture='both',[string]$HostRoot=(Join-Path $env:UNCANNY_PACKAGE_ROOT 'dist'),[switch]$Consent)
Set-StrictMode -Version Latest;$ErrorActionPreference='Stop'
Write-Host 'Synthetic cross-process GPU transport test. No DLSS5 provider loaded; no game is hooked.'
if(!$Consent -and (Read-Host 'Run GPU shared-copy tests and write local reports? Type YES') -cne 'YES'){exit 0}
$resolved=(Resolve-Path -LiteralPath $HostRoot).Path
if(!(Test-Path -LiteralPath (Join-Path $resolved 'UNCANNY.NeuralHost64.exe'))){throw 'Select the public dist folder or installed .uncanny/host64 folder.'}
$outDir=Join-Path $env:UNCANNY_PACKAGE_ROOT ('.uncanny/reports/host-transport-'+[guid]::NewGuid().ToString('N'));New-Item -ItemType Directory -Path $outDir|Out-Null
$results=@();$arches=if($Architecture -eq 'both'){@('32','64')}else{@($Architecture)}
foreach($bits in $arches){$exe=Join-Path $env:UNCANNY_PACKAGE_ROOT "diagnostics/neural-host-transport$bits.exe";$out=Join-Path $outDir "$bits.txt";$err=Join-Path $outDir "$bits-error.txt";$status='NOT_RUN';$code=$null
 try{$p=Start-Process -FilePath $exe -ArgumentList ('"'+$resolved+'"') -PassThru -RedirectStandardOutput $out -RedirectStandardError $err
  if(!$p.WaitForExit(90000)){$p.Kill();$status='TIMEOUT'}else{$p.WaitForExit();$p.Refresh();$code=$p.ExitCode;$status=if($code -eq 0){'PASS'}elseif($code -eq 77){'UNAVAILABLE'}else{'FAIL'}}
 }catch{$status='LAUNCH_FAILED';$_|Out-String|Set-Content $err}
 $results+=[ordered]@{parent_bits=$bits;helper_bits=64;status=$status;exit_code=$code;parent_sha256=(Get-FileHash -LiteralPath $exe).Hash.ToLowerInvariant();helper_sha256=(Get-FileHash -LiteralPath (Join-Path $resolved 'UNCANNY.NeuralHost64.exe')).Hash.ToLowerInvariant();neural_inference='NOT_EXECUTED'}
 Write-Host "$bits -> 64 transport: $status"
}
[ordered]@{schema='UNCANNY-NEURAL-HOST-TRANSPORT-1';results=$results;scope='Exact shared-copy pixels, sequence reuse, resized sessions. Not provider inference, performance, physical input or game compatibility.'}|ConvertTo-Json -Depth 6|Set-Content -LiteralPath (Join-Path $outDir 'results.json') -Encoding UTF8
Write-Host "Reports saved locally: $outDir"
