﻿param([ValidateSet('32','64','both')][string]$Architecture='both',[string]$HostRoot=(Join-Path $env:UNCANNY_PACKAGE_ROOT 'dist'))
Set-StrictMode -Version Latest
$ErrorActionPreference='Stop'
Write-Host 'UNCANNY helper startup check: CPU/IPC ONLY. No GPU, provider, game injection or inference.'
$resolved=(Resolve-Path -LiteralPath $HostRoot).Path
$helper=Join-Path $resolved 'UNCANNY.NeuralHost64.exe'
if(!(Test-Path -LiteralPath $helper -PathType Leaf)){throw 'The helper is missing. Extract the complete Windows package.'}
$build=Get-Content -LiteralPath (Join-Path $env:UNCANNY_PACKAGE_ROOT 'public-build.json') -Raw|ConvertFrom-Json
$expectedHelper=@($build.auxiliary|Where-Object {$_.file -match 'UNCANNY[.]NeuralHost64[.]exe$'})
$helperHash=(Get-FileHash -LiteralPath $helper -Algorithm SHA256).Hash.ToLowerInvariant()
if($expectedHelper.Count -ne 1 -or $helperHash -ne $expectedHelper[0].sha256){throw 'Helper hash does not match this complete package; do not mix release files.'}
$outDir=Join-Path $env:UNCANNY_PACKAGE_ROOT ('.uncanny/reports/host-startup-'+[guid]::NewGuid().ToString('N'))
foreach($parent in @((Join-Path $env:UNCANNY_PACKAGE_ROOT '.uncanny'),(Join-Path $env:UNCANNY_PACKAGE_ROOT '.uncanny/reports'))){
 if((Test-Path -LiteralPath $parent) -and ((Get-Item -LiteralPath $parent).Attributes -band [IO.FileAttributes]::ReparsePoint)){throw ('Unsafe report directory: '+$parent)}
}
New-Item -ItemType Directory -Path $outDir -Force|Out-Null
$results=@();$arches=if($Architecture -eq 'both'){@('32','64')}else{@($Architecture)}
foreach($bits in $arches){
 $exe=Join-Path $env:UNCANNY_PACKAGE_ROOT "diagnostics/neural-host-startup$bits.exe"
 $relative="diagnostics/neural-host-startup$bits.exe"
 $expectedTest=@($build.diagnostics|Where-Object {$_.file -eq $relative})
 if($expectedTest.Count -ne 1 -or !(Test-Path -LiteralPath $exe -PathType Leaf)){throw ('Missing startup diagnostic: '+$relative)}
 if((Get-FileHash -LiteralPath $exe -Algorithm SHA256).Hash.ToLowerInvariant() -ne $expectedTest[0].sha256){throw ('Diagnostic hash mismatch: '+$relative)}
 $out=Join-Path $outDir "$bits.txt";$err=Join-Path $outDir "$bits-error.txt";$status='NOT_RUN';$code=$null
 try{
  $p=Start-Process -FilePath $exe -ArgumentList ('"'+[regex]::Replace($resolved,'(\\+)$','$1$1')+'"') -PassThru -RedirectStandardOutput $out -RedirectStandardError $err
  if(!$p.WaitForExit(90000)){$p.Kill();$status='TIMEOUT'}else{$p.WaitForExit();$p.Refresh();$code=$p.ExitCode;$status=if($code -eq 0){'PASS'}else{'FAIL'}}
 }catch{$status='LAUNCH_FAILED';$_|Out-String|Set-Content -LiteralPath $err}
 $results+=[ordered]@{parent_bits=$bits;helper_bits=64;status=$status;exit_code=$code;helper_sha256=(Get-FileHash -LiteralPath $helper).Hash.ToLowerInvariant();gpu='NOT_EXECUTED';neural_inference='NOT_EXECUTED'}
 Write-Host "$bits -> 64 startup: $status"
 if(Test-Path -LiteralPath $out){Get-Content -LiteralPath $out|Write-Host}
 if(Test-Path -LiteralPath $err){Get-Content -LiteralPath $err|Write-Host}
}
[ordered]@{schema='UNCANNY-NEURAL-STARTUP-1';results=$results;scope='Exact helper entry, IPC request/reply, version and parent identity rejection. Not graphics, provider initialization, inference or visual proof.'}|ConvertTo-Json -Depth 6|Set-Content -LiteralPath (Join-Path $outDir 'results.json') -Encoding UTF8
Write-Host "Reports: $outDir"
Write-Host "Helper bootstrap logs: $(Join-Path $resolved 'logs')"
if(@($results|Where-Object {$_.status -ne 'PASS'}).Count){exit 1}
