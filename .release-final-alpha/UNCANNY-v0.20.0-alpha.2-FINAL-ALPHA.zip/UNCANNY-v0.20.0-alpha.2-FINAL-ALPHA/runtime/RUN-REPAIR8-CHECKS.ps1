﻿param([switch]$Consent)
Set-StrictMode -Version Latest
$ErrorActionPreference='Stop'
$root=[IO.Path]::GetFullPath($env:UNCANNY_PACKAGE_ROOT)
Write-Host 'Repair 8 codec/ownership tests. No game is hooked and no game texture folder is scanned.'
Write-Host 'Tests create and remove their own temporary fixtures. They do not run NVIDIA inference.'
if(!$Consent -and (Read-Host 'Run the local checks and save reports? Type YES') -cne 'YES'){exit 0}
$version=Get-Content -LiteralPath (Join-Path $root 'VERSION.json') -Raw | ConvertFrom-Json
if($version.revision -notin @('release-alpha.1.elysium','release-alpha.rc2.hotfix.2','release-alpha.rc2.hotfix.1','release-alpha.rc2','release-alpha.rc1','release-repair.8','release-repair.8.hotfix.1')){throw 'This runner requires a complete compatible public package.'}
$build=Get-Content -LiteralPath (Join-Path $root 'public-build.json') -Raw | ConvertFrom-Json
$outDir=Join-Path $root ('.uncanny/reports/repair8-codec-'+[guid]::NewGuid().ToString('N'))
New-Item -ItemType Directory -Path $outDir -Force | Out-Null
$records=@()
foreach($bits in @('32','64')){
    $relative="diagnostics/revenant-commit$bits.exe"
    $exe=Join-Path $root $relative
    $entries=@($build.diagnostics | Where-Object {$_.file -eq $relative})
    if($entries.Count -ne 1 -or !(Test-Path -LiteralPath $exe)){throw "Missing diagnostic metadata or executable: $relative"}
    $hash=(Get-FileHash -LiteralPath $exe -Algorithm SHA256).Hash.ToLowerInvariant()
    if($hash -ne $entries[0].sha256){throw "Diagnostic integrity failed: $relative"}
    $stdout=Join-Path $outDir "$bits.txt"
    $stderr=Join-Path $outDir "$bits-error.txt"
    $status='NOT_RUN'
    $code=$null
    try{
        $process=Start-Process -FilePath $exe -PassThru -RedirectStandardOutput $stdout -RedirectStandardError $stderr
        if(!$process.WaitForExit(60000)){
            $process.Kill()
            $status='TIMEOUT'
        }else{
            $process.WaitForExit()
            $process.Refresh()
            $code=$process.ExitCode
            $status=if($code -eq 0){'PASS'}else{'FAIL'}
        }
    }catch{
        $status='LAUNCH_FAILED'
        $_ | Out-String | Set-Content -LiteralPath $stderr -Encoding UTF8
    }
    $records+=[ordered]@{architecture=$bits;status=$status;exit_code=$code;sha256=$hash}
    Write-Host ("Codec/ownership {0}-bit: {1}" -f $bits,$status)
}
[ordered]@{schema='UNCANNY-REPAIR8-CODEC-1';revision=$version.revision;results=$records;scope='WIC exact pixels, commits, receipts, ownership restoration. No game, GPU inference, physical input or performance evidence.'} | ConvertTo-Json -Depth 6 | Set-Content -LiteralPath (Join-Path $outDir 'results.json') -Encoding UTF8
Write-Host "Reports: $outDir"
if(@($records | Where-Object {$_.status -ne 'PASS'}).Count -gt 0){exit 1}
exit 0
