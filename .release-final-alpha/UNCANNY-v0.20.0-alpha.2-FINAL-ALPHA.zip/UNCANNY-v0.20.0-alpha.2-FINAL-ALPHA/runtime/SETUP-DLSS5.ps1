﻿param([string]$TargetDir=$env:UNCANNY_PACKAGE_ROOT,[switch]$Offline)
Set-StrictMode -Version Latest;$ErrorActionPreference='Stop'
. (Join-Path (Split-Path -Parent $MyInvocation.MyCommand.Path) 'UNCANNY-InstallCommon.ps1')
. (Join-Path (Split-Path -Parent $MyInvocation.MyCommand.Path) 'UNCANNY-ProviderCommon.ps1')
$TargetDir=Resolve-UncannySetupTarget $TargetDir
Assert-UncannyClosed $TargetDir @('UNCANNY.NativeRuntime.dll','UNCANNY.Revenant.exe','UNCANNY.ControlDeck.exe')
$runtime=Join-Path $TargetDir 'UNCANNY.NativeRuntime.dll';$arch=(Get-UncannyPeInfo $runtime).Architecture
$state=Join-Path $TargetDir '.uncanny';$id=[guid]::NewGuid().ToString('N');$stage=Join-Path $state "provider-setup-$id";$backup=Join-Path $state "provider-backup-$id"
New-Item -ItemType Directory -Path $stage,$backup -Force|Out-Null
$records=[Collections.Generic.List[object]]::new();$committed=$false
try{
 $plan=New-UncannyProviderPlan $TargetDir $stage $env:UNCANNY_PACKAGE_ROOT $arch '' (!$Offline)
 foreach($change in $plan.changes){Assert-UncannyNoReparsePath $change.destination;$before='';$copy=Join-Path $backup ($records.Count.ToString()+'.dll')
  if(Test-Path -LiteralPath $change.destination){$before=(Get-FileHash -LiteralPath $change.destination).Hash;Copy-Item -LiteralPath $change.destination -Destination $copy;if((Get-FileHash -LiteralPath $copy).Hash -ine $before){throw 'Backup validation failed.'}}
  $records.Add([pscustomobject]@{destination=$change.destination;source=$change.source;before=$before;after=$change.sha256;backup=$copy})
 }
 $records.ToArray()|ConvertTo-Json -Depth 8|Set-Content -LiteralPath (Join-Path $backup 'journal.json') -Encoding UTF8
 foreach($item in $records){Set-UncannyVerifiedFile $item.source $item.destination $item.after $item.before}
 $plan|ConvertTo-Json -Depth 12|Set-Content -LiteralPath (Join-Path $state 'provider-state.json') -Encoding UTF8
 $committed=$true;Write-Host "DLSS 5 setup: $($plan.status). Restart the game. File setup does not prove inference." -ForegroundColor Cyan
 if($plan.status -ne 'FILES_READY_INFERENCE_NOT_TESTED'){Write-Warning 'See provider-state.json. Update your NVIDIA driver if its core is missing; no manual DLL guessing is required.'}
}catch{
 foreach($item in $records){try{
  if((Test-Path -LiteralPath $item.destination) -and (Get-FileHash -LiteralPath $item.destination).Hash -ieq $item.after){
   if($item.before){Set-UncannyVerifiedFile $item.backup $item.destination $item.before $item.after}else{Remove-Item -LiteralPath $item.destination -Force}
  }
 }catch{Write-Warning "Backup retained at $backup; manual restoration required for $($item.destination)."}}
 throw
}finally{if($committed){Remove-Item -LiteralPath $stage -Recurse -Force -ErrorAction SilentlyContinue}else{Write-Warning "Recovery evidence retained: $stage / $backup"}}
