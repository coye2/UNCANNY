﻿param([string]$TargetDir=$env:UNCANNY_PACKAGE_ROOT)
Set-StrictMode -Version Latest
$ErrorActionPreference='Stop'
. (Join-Path (Split-Path -Parent $MyInvocation.MyCommand.Path) 'UNCANNY-InstallCommon.ps1')
. (Join-Path (Split-Path -Parent $MyInvocation.MyCommand.Path) 'UNCANNY-Environment.ps1')
Assert-UncannyNoReparsePath $TargetDir
if(!(Test-Path -LiteralPath (Join-Path $TargetDir 'UNCANNY.NativeRuntime.dll'))){throw 'Run this setup from an installed UNCANNY game folder.'}
Stop-UncannyOrphanCompanions $TargetDir
Assert-UncannyClosed $TargetDir @()
& (Join-Path (Split-Path -Parent $MyInvocation.MyCommand.Path) 'INSTALL-AI-CORE.ps1') -TargetDir $TargetDir
$runner=Join-Path $TargetDir '.uncanny/ai/realesrgan/realesrgan-ncnn-vulkan.exe'
if(!(Test-Path -LiteralPath $runner)){throw 'Neural core installation did not complete.'}
$marker=Join-Path $TargetDir '.uncanny/pc-assets.enabled'
Assert-UncannyNoReparsePath $marker
'EXPERIMENTAL_PC_COLOR_OPT_IN'|Set-Content -LiteralPath $marker -Encoding ASCII
Write-Host 'PC asset experiment enabled. Restart the game normally. Eligible D3D9/Ex and D3D11 textures are captured; inspect upload/binding evidence in the REVENANT page.'
