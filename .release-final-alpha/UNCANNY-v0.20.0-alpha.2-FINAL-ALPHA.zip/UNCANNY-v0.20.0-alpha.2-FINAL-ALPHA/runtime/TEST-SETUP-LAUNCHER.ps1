﻿param()
Set-StrictMode -Version Latest
$ErrorActionPreference='Stop'
if($env:OS -ne 'Windows_NT'){throw 'This test requires Windows PowerShell and cmd.exe.'}
. (Join-Path (Split-Path -Parent $MyInvocation.MyCommand.Path) 'UNCANNY-InstallCommon.ps1')
$lines=@(Get-Content -LiteralPath (Join-Path $env:UNCANNY_PACKAGE_ROOT 'Tools/SETUP-DLSS5.cmd') | Where-Object { $_ -match '^powershell\.exe ' })
if($lines.Count -ne 1){throw 'Unexpected setup launcher; refusing to simulate a different invocation.'}
$line=$lines[0]
if($line -match '-TargetDir'){throw 'Regression: setup launcher is passing a redundant native path argument.'}
$root=Join-Path ([IO.Path]::GetTempPath()) ('UNCANNY-SetupTest-'+[guid]::NewGuid().ToString('N'))
New-Item -ItemType Directory -Path $root | Out-Null
$records=[Collections.Generic.List[object]]::new()
try {
 foreach($name in @('Binaries','Game With Spaces','Game (test) & [x]','Name!Bang')) {
  $dir=Join-Path $root $name
  New-Item -ItemType Directory -Path $dir | Out-Null
  $receiver=@'
param([string]$TargetDir=$env:UNCANNY_PACKAGE_ROOT)
$ErrorActionPreference='Stop'
[IO.File]::WriteAllText((Join-Path $env:UNCANNY_PACKAGE_ROOT 'observed.txt'),$TargetDir,[Text.UTF8Encoding]::new($false))
'@
  [IO.File]::WriteAllText((Join-Path $dir 'SETUP-DLSS5.ps1'),$receiver,[Text.UTF8Encoding]::new($true))
  $bat=Join-Path $dir 'RUN.cmd'
  $batch="@echo off`r`nsetlocal DisableDelayedExpansion`r`n"+$line+"`r`nexit /b %ERRORLEVEL%`r`n"
  [IO.File]::WriteAllText($bat,$batch,[Text.Encoding]::ASCII)
  $p=[Diagnostics.Process]::new()
  $p.StartInfo.FileName=$env:ComSpec
  $p.StartInfo.Arguments='/d /s /c ""'+$bat+'""'
  $p.StartInfo.UseShellExecute=$false
  $p.StartInfo.CreateNoWindow=$true
  try {
   $null=$p.Start()
   if(!$p.WaitForExit(20000)){try{$p.Kill()}catch{};throw 'Temporary setup receiver timed out.'}
   if($p.ExitCode -ne 0){throw ('Temporary receiver failed: '+$p.ExitCode)}
  } finally {$p.Dispose()}
  $got=[IO.File]::ReadAllText((Join-Path $dir 'observed.txt'))
  if($got -cne $dir){throw ('Native argv changed the fixture folder: '+$got)}
  if((Resolve-UncannySetupTarget $got) -cne $dir){throw 'Resolved path differs from fixture.'}
  $records.Add([pscustomobject]@{fixture=$name;status='PASS'})
 }
 foreach($bad in @(($root+'"'),('"'+$root),($root+[char]10),($root+'\*'),($root+'\'+[char]0),'')) {
  $rejected=$false;try{$null=Resolve-UncannySetupTarget $bad}catch{$rejected=$true}
  if(!$rejected){throw 'Unsafe fixture path was accepted.'}
 }
 [pscustomobject]@{test='SETUP-DLSS5 native argument and folder validation';status='PASS';scope='Windows cmd and PowerShell path fixtures only; no provider/game/GPU test';cases=$records.ToArray()} | ConvertTo-Json -Depth 4
} finally {Remove-Item -LiteralPath $root -Recurse -Force}
