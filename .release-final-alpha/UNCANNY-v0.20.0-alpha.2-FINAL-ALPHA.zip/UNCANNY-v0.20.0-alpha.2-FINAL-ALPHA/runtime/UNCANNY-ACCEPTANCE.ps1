﻿param([string]$TargetDir=$env:UNCANNY_PACKAGE_ROOT,[int]$ProcessId=0,[ValidateRange(20,120)][int]$Seconds=30,[switch]$Consent,[string]$ReportFolder='')
Set-StrictMode -Version Latest
$ErrorActionPreference='Stop'
. (Join-Path (Split-Path -Parent $MyInvocation.MyCommand.Path) 'UNCANNY-AcceptanceCommon.ps1')
Write-Host 'UNCANNY acceptance capture — local report only' -ForegroundColor Cyan
Write-Host 'Records numeric runtime counters, graphics API, Windows/GPU/driver versions, binary hashes and executable SHA256.'
Write-Host 'Excludes names, full paths, PID, screenshots, free-text logs and process command lines. Review the report before sharing. No automatic upload.'
if(!$Consent -and (Read-Host 'Create this report? Type YES') -cne 'YES'){Write-Host 'Cancelled; no report created.';exit 0}
$TargetDir=(Resolve-Path -LiteralPath $TargetDir).Path
$candidates=@(Get-ChildItem -LiteralPath $TargetDir -File -Filter 'UNCANNY-NATIVE-STATUS-*.txt' | Where-Object {$_.Name -match '^UNCANNY-NATIVE-STATUS-(\d+)\.txt$' -and (!$ProcessId -or [int]$matches[1] -eq $ProcessId)} | ForEach-Object {
 try{$idValue=[int]([regex]::Match($_.Name,'\d+(?=\.txt$)').Value);$process=Get-Process -Id $idValue -ErrorAction Stop;if($_.LastWriteTimeUtc -ge $process.StartTime.ToUniversalTime() -and ([DateTime]::UtcNow-$_.LastWriteTimeUtc).TotalSeconds -lt 4){[pscustomobject]@{Status=$_.FullName;Process=$process;Started=$process.StartTime.ToUniversalTime()}}}catch{}
})
if($candidates.Count -ne 1){throw 'Expected one active runtime. Launch the game through UNCANNY, or select it with -ProcessId. No report was created.'}
$selected=$candidates[0];$processKey=$selected.Process.Id
$gameHash='UNAVAILABLE';try{$gameHash=(Get-FileHash -LiteralPath $selected.Process.MainModule.FileName -Algorithm SHA256).Hash.ToLowerInvariant()}catch{}
$gpu=@();try{$gpu=@(Get-CimInstance Win32_VideoController | ForEach-Object {[ordered]@{model=($_.Name -replace '[^A-Za-z0-9 ()._+/-]','').Substring(0,[Math]::Min(120,($_.Name -replace '[^A-Za-z0-9 ()._+/-]','').Length));driver=($_.DriverVersion -replace '[^0-9.]','')}})}catch{}
$binaries=[ordered]@{};foreach($name in @('UNCANNY.NativeRuntime.dll','UNCANNY.Revenant.exe','UNCANNY.ControlDeck.exe','UNCANNY-nvngx.dll.bridge32.dll','UNCANNY-nvngx.dll.bridge64.dll','.uncanny/host64/UNCANNY.NeuralHost64.exe','.uncanny/host64/UNCANNY-nvngx.dll.bridge64.dll')){$file=Join-Path $TargetDir $name;if(Test-Path -LiteralPath $file){$binaries[$name]=(Get-FileHash -LiteralPath $file -Algorithm SHA256).Hash.ToLowerInvariant()}}
Write-Host "Capturing for $Seconds seconds. In the game, open HOME and compare OFF/ON in the same scene."
$clock=[Diagnostics.Stopwatch]::StartNew();$samples=New-Object System.Collections.Generic.List[object];$lastHeartbeat=[ulong]0;$rejected=0;$ended='duration';$lastAttempts=0.0;$runtimeRevision=$null;$runtimeAbi=$null
while($clock.Elapsed.TotalSeconds -lt $Seconds){
 try{
  $p=Get-Process -Id $processKey -ErrorAction Stop;if($p.StartTime.ToUniversalTime() -ne $selected.Started){$ended='process_changed';break}
  $file=Get-Item -LiteralPath $selected.Status;if(([DateTime]::UtcNow-$file.LastWriteTimeUtc).TotalSeconds -gt 4){$rejected++;Start-Sleep -Milliseconds 300;continue}
  $snapshot=ConvertFrom-UncannyAcceptanceStatus ([IO.File]::ReadAllText($selected.Status))
  if($null -eq $snapshot -or $snapshot.ProcessId -ne $processKey){$rejected++}
  elseif($snapshot.Heartbeat -gt $lastHeartbeat){
   if($runtimeRevision -and ($snapshot.Revision -ne $runtimeRevision -or $snapshot.Metrics.ABI -ne $runtimeAbi)){$ended='engine_changed';break}
   $runtimeRevision=$snapshot.Revision;$runtimeAbi=$snapshot.Metrics.ABI
   if($snapshot.Metrics.PresentAttempts -lt $lastAttempts){$ended='counter_reset';break}
   $lastHeartbeat=$snapshot.Heartbeat;$lastAttempts=$snapshot.Metrics.PresentAttempts;$snapshot.Metrics['CaptureOffsetMs']=[Math]::Round($clock.Elapsed.TotalMilliseconds);$samples.Add($snapshot.Metrics)
  }
 }catch{$ended='process_or_status_unavailable';break}
 Start-Sleep -Milliseconds 300
}
if($samples.Count -lt 2){throw 'No continuous, complete supported revision/ABI runtime snapshots were captured. No acceptance result was invented.'}
$first=$samples[0];$last=$samples[$samples.Count-1];$delta=[ordered]@{}
foreach($key in @('PresentAttempts','PresentFailures','HomePresses','PostfxFrames','PostfxFailures','DlssEvaluations','DlssFailures','PcCaptureFiles','PcGpuUploads','PcBindings','PcSampledDraws','AssetAttempts','AssetNeuralSuccess','AssetFilesCommitted','AssetReloadRequests','AssetReloadInputs','AssetIndexObserved','MeshObserved','MeshCaptured','MeshValidated','MeshRejected','MeshUploaded','MeshSubmittedDraws','MeshCacheHits')){if($first.Contains($key) -and $last.Contains($key)){$delta[$key]=$last[$key]-$first[$key]}}
$report=[ordered]@{schema='UNCANNY-ACCEPTANCE-1';build=('0.19.0-alpha.1/'+$runtimeRevision);runtime_abi=$runtimeAbi;binary_hash_scope='on-disk files; loaded-module identity is not inferred';evidence='RUNTIME-REPORTED; rendered appearance and external reproduction require review';copyright='Copyright © 2026 Coye Stillwagen. All rights reserved.';windows=[Environment]::OSVersion.Version.ToString();gpu=$gpu;game_executable_sha256=$gameHash;binaries=$binaries;duration_ms=[Math]::Round($clock.Elapsed.TotalMilliseconds);ended=$ended;rejected_snapshots=$rejected;counter_deltas=$delta;samples=$samples;rendered_use='NOT_AUTOMATICALLY_VERIFIED';compatibility='UNVERIFIED';quality='HUMAN_REVIEW_REQUIRED';frame_time_scope='rolling Present cadence, up to 2048 frames; processor GPU timestamps when fresh; not game GPU time or click-to-photon latency'}
if(!$ReportFolder){$ReportFolder=Join-Path $TargetDir '.uncanny/reports'}
$session=Join-Path $ReportFolder ('acceptance-'+[Guid]::NewGuid().ToString('N'));New-Item -ItemType Directory -Path $session -ErrorAction Stop|Out-Null
$report|ConvertTo-Json -Depth 8|Set-Content -LiteralPath (Join-Path $session 'acceptance.json') -Encoding UTF8
$lines=@('# UNCANNY acceptance capture','','Evidence: runtime-reported counters. This is not automatic proof of visible quality or compatibility.','','| Counter | Change |','| --- | ---: |');foreach($key in $delta.Keys){$lines+="| $key | $($delta[$key]) |"}
$lines+=@('','Review acceptance.json before sharing. No upload was performed.','Record separately: test identifier, API, settings, same-scene OFF/ON screenshots, resize/Alt-Tab outcome, visible asset changes and defects.','Cadence values are rolling runtime windows, not isolated OFF-versus-ON benchmark results.','Copyright © 2026 Coye Stillwagen. All rights reserved.','UNCANNY is independent and is not affiliated with or endorsed by NVIDIA. NVIDIA and DLSS are trademarks of NVIDIA Corporation.')
$lines|Set-Content -LiteralPath (Join-Path $session 'README.md') -Encoding UTF8
Write-Host ('Created report: '+$session) -ForegroundColor Green
