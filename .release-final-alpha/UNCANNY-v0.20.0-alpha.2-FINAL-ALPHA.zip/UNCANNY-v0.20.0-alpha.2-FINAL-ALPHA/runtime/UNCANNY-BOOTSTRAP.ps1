﻿Set-StrictMode -Version Latest
$ErrorActionPreference='Stop'
$root=[IO.Path]::GetFullPath($env:UNCANNY_PACKAGE_ROOT)
$logDir=Join-Path $env:LOCALAPPDATA 'UNCANNY'
$logFile=Join-Path $logDir 'startup-error.log'
try{
  New-Item -ItemType Directory -Force -Path $logDir|Out-Null
  $launcher=Join-Path (Split-Path -Parent $MyInvocation.MyCommand.Path) 'UNCANNY-LAUNCHER.ps1'
  if(!(Test-Path -LiteralPath $launcher)){throw "UNCANNY launcher is missing: $launcher"}
  & $launcher
  exit 0
}catch{
  try{
    $details=@(
      'UNCANNY startup failure'
      ('Time: '+[DateTime]::Now.ToString('s'))
      ('Message: '+$_.Exception.Message)
      ('Exception: '+$_.Exception.ToString())
      ('Stack: '+$_.ScriptStackTrace)
    ) -join "`r`n"
    $details|Set-Content -LiteralPath $logFile -Encoding UTF8
  }catch{}
  try{
    Add-Type -AssemblyName PresentationFramework -ErrorAction SilentlyContinue
    [System.Windows.MessageBox]::Show("UNCANNY could not start.`n`n$($_.Exception.Message)`n`nA startup log was saved to:`n$logFile",'UNCANNY')|Out-Null
  }catch{}
  exit 1
}
