﻿param([string]$TargetDir=$env:UNCANNY_PACKAGE_ROOT,[int]$ProcessId=0,[switch]$Watch,[switch]$SaveReport)
Set-StrictMode -Version Latest
$ErrorActionPreference='Stop'
$TargetDir=(Resolve-Path -LiteralPath $TargetDir).Path
. (Join-Path (Split-Path -Parent $MyInvocation.MyCommand.Path) 'UNCANNY-InstallCommon.ps1')
function Get-UncannyDiagnosticSnapshot {
  $lines=New-Object 'System.Collections.Generic.List[string]'
  $lines.Add('UNCANNY RUNTIME EVIDENCE — '+[DateTime]::UtcNow.ToString('o'))
  $lines.Add('Scope=Local observed process/runtime reports. Installed files are NOT inference proof.')
  $lines.Add('TargetDirectory='+$TargetDir)
  $runtimePath=Join-Path $TargetDir 'UNCANNY.NativeRuntime.dll'
  $lines.Add('RuntimeFileInstalled='+[bool](Test-Path -LiteralPath $runtimePath -PathType Leaf))
  $launchLog=@(Get-ChildItem -LiteralPath $TargetDir -File -Filter 'UNCANNY-LAUNCH-SESSION-*.log' -ErrorAction SilentlyContinue|Sort-Object LastWriteTime -Descending|Select-Object -First 1)
  if($launchLog.Count){
    $lines.Add('--- PCSX2/Direct wrapper self-test ---')
    $recent=@(Get-Content -LiteralPath $launchLog[0].FullName -Tail 80 -ErrorAction SilentlyContinue)
    $map=@{
      'PCSX2_WRAPPER_STARTED'='PCSX2_WRAPPER=STARTED';'PCSX2_ORIGINAL_EXE_FOUND'='PCSX2_ORIGINAL_EXE=FOUND';
      'PCSX2_CHILD_PROCESS_STARTED'='PCSX2_CHILD_PROCESS=STARTED';'PCSX2_WORKING_DIRECTORY_PRESERVED'='PCSX2_WORKING_DIRECTORY=PRESERVED';
      'PCSX2_ARGUMENTS_FORWARDED'='PCSX2_ARGUMENTS=FORWARDED';'UNCANNY_RUNTIME_LOAD_OK'='UNCANNY_RUNTIME_LOAD=OK';
      'UNCANNY_RUNTIME_LOAD_FAILED'='UNCANNY_RUNTIME_LOAD=FAILED';'PCSX2_CHILD_EXITED'='PCSX2_SHUTDOWN=COMPLETED'
    }
    foreach($key in $map.Keys){if(@($recent|Where-Object{$_ -match ('\s'+[regex]::Escape($key)+'\s')}).Count){$lines.Add($map[$key])}}
    $failure=@($recent|Where-Object{$_ -match '\sFAILURE_STAGE\s'}|Select-Object -Last 1)
    if($failure.Count){$stage=($failure[0] -replace '^.*FAILURE_STAGE\s+PID=\d+\s*','').Trim();$lines.Add('FAILURE_STAGE='+$stage)}
    $lines.Add('WrapperLog='+$launchLog[0].FullName)
  }
  $processes=@()
  try {
    $processes=@(Get-CimInstance Win32_Process -OperationTimeoutSec 5 | Where-Object {
      $_.ExecutablePath -and (Test-UncannyPathWithin $_.ExecutablePath $TargetDir) -and
      (!$ProcessId -or $_.ProcessId -eq $ProcessId) -and
      $_.Name -notmatch '^UNCANNY\.(Revenant|ControlDeck|NativeLauncher|NeuralHost)'
    })
  } catch {$lines.Add('ProcessEnumerationError='+$_.Exception.Message)}
  if(!$processes.Count){$lines.Add('TargetProcess=NOT_OBSERVED; launch the installed game normally, then run this report again.')}
  foreach($p in $processes){
    $providerLines=@()
    $lines.Add('');$lines.Add('=== '+$p.Name+' / PID '+$p.ProcessId+' ===')
    $lines.Add('TargetExe='+$p.ExecutablePath);$lines.Add('ProcessCreated='+[string]$p.CreationDate)
    try {$lines.Add('TargetArchitecture='+(Get-UncannyPeInfo $p.ExecutablePath).Architecture)}catch{$lines.Add('TargetArchitecture=UNAVAILABLE: '+$_.Exception.Message)}
    try {
      $mods=@((Get-Process -Id $p.ProcessId -ErrorAction Stop).Modules | Where-Object {$_.FileName -ieq $runtimePath})
      $lines.Add('ExternalRuntimeModuleObserved='+$(if($mods.Count){'YES'}else{'NOT_OBSERVED'}))
      if(!$mods.Count){$lines.Add('ExternalObservationScope=An empty or cross-bitness module enumeration does not prove the runtime is absent. Fresh self-reports below are separate evidence.')}
      foreach($m in $mods){$lines.Add('ObservedRuntimeModulePath='+$m.FileName)}
    }catch{$lines.Add('RuntimeModuleEnumeration=UNAVAILABLE: '+$_.Exception.Message)}
    foreach($kind in @('UNCANNY-NATIVE-STATUS','UNCANNY-DLSS5-PROVIDER','UNCANNY-REVENANT-STATUS','UNCANNY-PC-ASSETS','UNCANNY-PC-D3D9')){
      $path=Join-Path $TargetDir ($kind+'-'+$p.ProcessId+'.txt')
      try {
        if(!(Test-Path -LiteralPath $path -PathType Leaf)){$lines.Add($kind+'=NO_REPORT');continue}
        $file=Get-Item -LiteralPath $path
        if($file.Length -gt 262144){$lines.Add($kind+'=REPORT_TOO_LARGE');continue}
        if($file.LastWriteTime -lt $p.CreationDate -or ((Get-Date)-$file.LastWriteTime).TotalSeconds -gt 5){$lines.Add($kind+'=STALE; not used as current proof');continue}
        $content=@(Get-Content -LiteralPath $path)
        if($kind -eq 'UNCANNY-DLSS5-PROVIDER'){$providerLines=$content}
        $lines.Add('--- '+$kind+' ---');foreach($line in $content){$lines.Add([string]$line)}
      }catch{$lines.Add($kind+'=READ_ERROR: '+$_.Exception.Message)}
    }
    $helperId=[uint32]0
    foreach($line in $providerLines){if($line -match '^Host64PID=([0-9]+)$'){$null=[uint32]::TryParse($matches[1],[ref]$helperId)}}
    if($helperId){
      try{
        $helperProcess=@(Get-CimInstance Win32_Process -Filter ("ProcessId="+$helperId) -OperationTimeoutSec 5)
        if(!$helperProcess.Count){$lines.Add('IndependentHostOSQuery=PID_NOT_PRESENT')}
        else{
          $actual=$helperProcess[0]
          $expectedHelper=[IO.Path]::GetFullPath((Join-Path $TargetDir '.uncanny/host64/UNCANNY.NeuralHost64.exe'))
          if($actual.ExecutablePath -and $actual.ExecutablePath -ieq $expectedHelper -and $actual.ParentProcessId -eq $p.ProcessId -and $actual.CreationDate -ge $p.CreationDate){
            $lines.Add('IndependentHostOSQuery=ALIVE_IMAGE_AND_PARENT_MATCH')
            $lines.Add('IndependentHostImage='+$actual.ExecutablePath);$lines.Add('IndependentHostCreated='+[string]$actual.CreationDate)
          }else{$lines.Add('IndependentHostOSQuery=PID_PRESENT_BUT_IMAGE_OR_SESSION_NOT_VERIFIED')}
        }
      }catch{$lines.Add('IndependentHostOSQuery=UNAVAILABLE: '+$_.Exception.Message)}
      $bootDir=Join-Path $TargetDir '.uncanny/host64/logs'
      $bootPath=Join-Path $bootDir ('UNCANNY-NeuralHost-'+$helperId+'.log')
      try{
        if(Test-Path -LiteralPath $bootPath -PathType Leaf){
          $file=Get-Item -LiteralPath $bootPath
          if(((Get-Item -LiteralPath $bootDir).Attributes -band [IO.FileAttributes]::ReparsePoint) -or ($file.Attributes -band [IO.FileAttributes]::ReparsePoint)){$lines.Add('HelperBootstrapLog=UNSAFE_REPARSE_PATH')}
          elseif($file.Length -gt 65536 -or $file.LastWriteTime -lt $p.CreationDate){$lines.Add('HelperBootstrapLog=STALE_OR_OVERSIZED_NOT_USED')}
          else{
            $bootLines=@(Get-Content -LiteralPath $bootPath -Encoding UTF8)
            $targetMarker='Detail=Local\UNCANNY.NH.'+$p.ProcessId+'.'
            if(@($bootLines|Where-Object {$_.Contains($targetMarker)}).Count){
              $lines.Add('--- Helper bootstrap journal: session history, NOT inference proof ---')
              foreach($line in $bootLines){$lines.Add([string]$line)}
            }else{$lines.Add('HelperBootstrapLog=TARGET_SESSION_NOT_VERIFIED')}
          }
        }else{$lines.Add('HelperBootstrapLog=NOT_FOUND; not proof of process absence')}
      }catch{$lines.Add('HelperBootstrapLog=READ_ERROR: '+$_.Exception.Message)}
    }
    $assetPath=Join-Path $TargetDir '.uncanny/revenant/NEURAL-ASSET-EVIDENCE.txt'
    try {
      if(Test-Path -LiteralPath $assetPath -PathType Leaf){
        $file=Get-Item -LiteralPath $assetPath
        if($file.Length -le 262144 -and $file.LastWriteTime -ge $p.CreationDate){
          $assetLines=@(Get-Content -LiteralPath $assetPath)
          if($assetLines -contains ('TargetPID='+$p.ProcessId)){
            $lines.Add('--- Latest asset inference receipt: NOT rendered-use certification ---')
            foreach($line in $assetLines){$lines.Add([string]$line)}
          }
        }
      }
    }catch{$lines.Add('AssetReceiptReadError='+$_.Exception.Message)}
  }
  $lines.Add('');$lines.Add('Never infer neural success from file presence, checker confirmation, a reload request, or transport-only counters.')
  return $lines.ToArray()
}
function Save-UncannyDiagnosticSnapshot([string[]]$Lines){
  $reports=Join-Path $TargetDir '.uncanny/reports'
  foreach($candidate in @((Join-Path $TargetDir '.uncanny'),$reports)){
    if(Test-Path -LiteralPath $candidate){if((Get-Item -LiteralPath $candidate).Attributes -band [IO.FileAttributes]::ReparsePoint){throw ('Unsafe report directory: '+$candidate)}}
  }
  New-Item -ItemType Directory -Path $reports -Force|Out-Null
  $path=Join-Path $reports ('UNCANNY-RUNTIME-'+[DateTime]::UtcNow.ToString('yyyyMMdd-HHmmss')+'-'+[guid]::NewGuid().ToString('N')+'.txt')
  $temp=$path+'.pending'
  [IO.File]::WriteAllLines($temp,$Lines,(New-Object System.Text.UTF8Encoding($false)))
  Move-Item -LiteralPath $temp -Destination $path
  Write-Host ('Saved report: '+$path)
}
do {
  if($Watch){Clear-Host}
  $snapshot=@(Get-UncannyDiagnosticSnapshot)
  foreach($line in $snapshot){Write-Host $line}
  if($SaveReport){Save-UncannyDiagnosticSnapshot -Lines $snapshot;$SaveReport=$false}
  if($Watch){Start-Sleep -Seconds 2}
}while($Watch)
