﻿param([ValidateSet('Apply','Commit','Rollback','Restore')][string]$Mode='Apply',[Parameter(Mandatory=$true)][ValidatePattern('^[0-9]{1,20}$')][string]$Profile,[ValidateSet('32','64')][string]$Architecture='64',[int]$CallerId=0)
$ErrorActionPreference='Stop'
. (Join-Path (Split-Path -Parent $MyInvocation.MyCommand.Path) 'UNCANNY-InstallCommon.ps1')
. (Join-Path (Split-Path -Parent $MyInvocation.MyCommand.Path) 'UNCANNY-EngineCommon.ps1')
try{$abi=Invoke-UncannyEngineSelection $env:UNCANNY_PACKAGE_ROOT $Profile $Architecture $Mode $CallerId;exit $abi}catch{$_|Out-String|Set-Content -LiteralPath (Join-Path $env:UNCANNY_PACKAGE_ROOT 'UNCANNY-ENGINE-ERROR.txt');exit 1}
