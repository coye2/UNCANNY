﻿Set-StrictMode -Version Latest
function Get-UncannyEnginePreference([string]$Root,[string]$Profile) {
 if($Profile -notmatch '^[0-9]{1,20}$'){throw 'Invalid executable profile identity.'}
 Join-Path (Join-Path $Root '.uncanny/engine-preferences') ($Profile+'.ini')
}
function Get-UncannyEngineFiles([string]$Architecture) {
 @('UNCANNY.NativeRuntime.dll','UNCANNY.ControlDeck.exe','UNCANNY.Revenant.exe',"UNCANNY-nvngx.dll.bridge$Architecture.dll")
}
function Get-UncannyEngineBinaryName([string]$Name,[string]$Architecture) {
 if($Name -like '*bridge*'){return $Name};[IO.Path]::GetFileNameWithoutExtension($Name)+$Architecture+[IO.Path]::GetExtension($Name)
}
function Assert-UncannyEngineClosed([string]$Root,[int]$CallerId) {
 $deadline=[DateTime]::UtcNow.AddSeconds(6)
 do {
  $running=@(Get-UncannyFastLocalProcessSnapshot $Root)
  $blocked=@()
  foreach($process in $running){
   $allowed=$false
   if($process.ProcessId -eq $CallerId -and $CallerId -gt 0){
    $path=$process.ExecutablePath;$record=Join-Path (Join-Path $Root '.uncanny/launch') ([IO.Path]::GetFileName($path)+'.ini')
    if(Test-Path -LiteralPath $record){$hash=Get-UncannyIni $record 'Launch' 'WrapperSHA256';$allowed=$hash -match '^[a-fA-F0-9]{64}$' -and (Get-UncannySHA256 $path) -ieq $hash}
    elseif([IO.Path]::GetFileName($path) -eq 'UNCANNY.NativeLauncher.exe'){$allowed=(Get-UncannySHA256 $path) -ieq (Get-UncannySHA256 (Join-Path $Root 'UNCANNY.EngineLauncher.exe'))}
   }
   if(!$allowed){$blocked+=$process}
  }
  if(!$blocked.Count){return};Start-Sleep -Milliseconds 150
 }while([DateTime]::UtcNow -lt $deadline)
 throw ('Close the running target and companions before changing engine: '+(($blocked|ForEach-Object {$_.Name}) -join ', '))
}
function Read-UncannyEngineBundle([string]$Root,[string]$Id,[string]$Architecture,[switch]$PublicRoot) {
 if($Id -ne 'release-fix.5' -or $Architecture -notin @('32','64')){throw 'Engine bundle is not registered.'}
 $folder=if($PublicRoot){Join-Path $Root ("engines/$Id/$Architecture")}else{Join-Path $Root (".uncanny/engine-bundles/$Id/$Architecture")};Assert-UncannyNoReparsePath $folder
 $manifestPath=Join-Path $folder 'engine.json';$manifest=Get-Content -LiteralPath $manifestPath -Raw|ConvertFrom-Json
 if($manifest.schema -ne 'UNCANNY-ENGINE-1' -or $manifest.id -ne $Id -or $manifest.architecture -ne $Architecture -or $manifest.abi -ne 136 -or $manifest.origin_revision -ne 'release-fix.5'){throw 'Engine manifest/ABI mismatch.'}
 $names=Get-UncannyEngineFiles $Architecture
 if((@($manifest.files.name|Sort-Object) -join '|') -cne (@($names|Sort-Object) -join '|')){throw 'Engine components are incomplete or unexpected.'}
 foreach($file in $manifest.files){
  if($file.sha256 -notmatch '^[a-f0-9]{64}$'){throw 'Invalid engine digest.'};$binary=Get-UncannyEngineBinaryName $file.name $Architecture;if($file.binary -cne $binary){throw 'Invalid component filename.'};$path=Join-Path $folder $binary;Assert-UncannyNoReparsePath $path
  if((Get-UncannySHA256 $path) -ine $file.sha256 -or (Get-UncannyTargetPeInfo $path).Architecture -ne $Architecture){throw 'Engine file integrity or architecture mismatch.'}
 }
 [pscustomobject]@{Folder=$folder;Manifest=$manifest}
}
function Save-UncannyEngineJournal([string]$Path,$Value){
 $text=$Value|ConvertTo-Json -Depth 8;$temporary=$Path+'.write';Assert-UncannyNoReparsePath $Path;Assert-UncannyNoReparsePath $temporary
 $bytes=[Text.UTF8Encoding]::new($false).GetBytes($text);$file=[IO.FileStream]::new($temporary,[IO.FileMode]::Create,[IO.FileAccess]::Write,[IO.FileShare]::None)
 try{$file.Write($bytes,0,$bytes.Length);$file.Flush($true)}finally{$file.Dispose()}
 $hash=(Get-UncannySHA256 $temporary);$prior=if(Test-Path -LiteralPath $Path){(Get-UncannySHA256 $Path)}else{''};Set-UncannyVerifiedFile $temporary $Path $hash $prior;Remove-Item -LiteralPath $temporary
}
function Restore-UncannyEngineBase([string]$Root,[switch]$PreflightOnly){
 $store=Join-Path $Root '.uncanny/engine-transaction';$journal=Join-Path $store 'journal.json';if(!(Test-Path -LiteralPath $journal)){return}
 Assert-UncannyNoReparsePath $store;$j=Get-Content -LiteralPath $journal -Raw|ConvertFrom-Json
 if($j.schema -ne 'UNCANNY-ENGINE-TRANSACTION-1' -or $j.root -ine [IO.Path]::GetFullPath($Root) -or $j.architecture -notin @('32','64')){throw 'Foreign engine journal; files retained.'}
 $expected=Get-UncannyEngineFiles $j.architecture
 if((@($j.files.name|Sort-Object) -join '|') -cne (@($expected|Sort-Object) -join '|')){throw 'Invalid engine recovery component list.'}
 foreach($f in $j.files){
  if($f.before -notmatch '^[a-f0-9]{64}$' -or $f.after -notmatch '^[a-f0-9]{64}$'){throw 'Invalid engine recovery digest.'}
  $backup=Join-Path $store ($f.name+'.original');$destination=Join-Path $Root $f.name;Assert-UncannyNoReparsePath $backup;Assert-UncannyNoReparsePath $destination
  if((Get-UncannySHA256 $backup) -ine $f.before){throw 'Engine original backup failed validation.'}
  if(Test-Path -LiteralPath $destination){$current=(Get-UncannySHA256 $destination);if($current -ine $f.before -and $current -ine $f.after){throw 'Engine restore conflict; externally changed file retained.'}}
 }
 if($PreflightOnly){return}
 foreach($f in $j.files){$destination=Join-Path $Root $f.name;$current=if(Test-Path -LiteralPath $destination){(Get-UncannySHA256 $destination)}else{''};if($current -ine $f.before){Set-UncannyVerifiedFile (Join-Path $store ($f.name+'.original')) $destination $f.before $current}}
 Remove-Item -LiteralPath $journal
 $active=Join-Path $Root '.uncanny/engine-active.ini';Set-UncannyIni $active 'Engine' 'Id' 'elysium';Set-UncannyIni $active 'Engine' 'ABI' '143';Set-UncannyIni $active 'Engine' 'Name' 'UNCANNY 4.5 - ELYSIUM';Set-UncannyIni $active 'Engine' 'Generation' '4.5';Set-UncannyIni $active 'Engine' 'LastResult' 'BASE_ENGINE_RESTORED';Set-UncannyIni $active 'Engine' 'FallbackReason' 'NONE'
}
function Install-UncannyEngineBundle([string]$Root,[string]$Id,[string]$Architecture){
 if($Id -in @('elysium','current')){return 143}
 $bundle=Read-UncannyEngineBundle $Root $Id $Architecture;$store=Join-Path $Root '.uncanny/engine-transaction';Assert-UncannyNoReparsePath $store;New-Item -ItemType Directory -Path $store -Force|Out-Null
 $journal=Join-Path $store 'journal.json';if(Test-Path -LiteralPath $journal){throw 'Restore pending engine transaction first.'}
 $files=@()
 foreach($f in $bundle.Manifest.files){
  $destination=Join-Path $Root $f.name;Assert-UncannyNoReparsePath $destination;$before=(Get-UncannySHA256 $destination).ToLowerInvariant()
  $backup=Join-Path $store ($f.name+'.original');Assert-UncannyNoReparsePath $backup;Copy-Item -LiteralPath $destination -Destination $backup -Force
  if((Get-UncannySHA256 $backup) -ine $before){throw 'Engine backup failed.'}
  $files+=[pscustomobject]@{name=$f.name;before=$before;after=$f.sha256}
 }
 $j=[ordered]@{schema='UNCANNY-ENGINE-TRANSACTION-1';root=[IO.Path]::GetFullPath($Root);architecture=$Architecture;engine=$Id;files=$files}
 Save-UncannyEngineJournal $journal $j
 try{
  foreach($f in $files){Set-UncannyVerifiedFile (Join-Path $bundle.Folder (Get-UncannyEngineBinaryName $f.name $Architecture)) (Join-Path $Root $f.name) $f.after $f.before}
  $active=Join-Path $Root '.uncanny/engine-active.ini';$count=[int64](Get-UncannyIni $active 'Engine' 'SwitchCount');Set-UncannyIni $active 'Engine' 'Id' $Id;Set-UncannyIni $active 'Engine' 'ABI' '136';Set-UncannyIni $active 'Engine' 'Name' 'UNCANNY 2.5 - Lucid';Set-UncannyIni $active 'Engine' 'Generation' '2.5';Set-UncannyIni $active 'Engine' 'SwitchCount' ([string]($count+1));Set-UncannyIni $active 'Engine' 'LastResult' 'SWITCH_OK';Set-UncannyIni $active 'Engine' 'FallbackReason' 'NONE'
 }catch{Restore-UncannyEngineBase $Root;throw}
 return 136
}
function Invoke-UncannyEngineSelection([string]$Root,[string]$Profile,[string]$Architecture,[string]$Mode,[int]$CallerId){
 $Root=[IO.Path]::GetFullPath($Root);Assert-UncannyNoReparsePath $Root;$preference=Get-UncannyEnginePreference $Root $Profile;Assert-UncannyNoReparsePath $preference
 $id=Get-UncannyIni $preference 'Engine' 'Id'
 $userSelected=Get-UncannyIni $preference 'Engine' 'UserSelected'
 if(!$id -or $id -in @('default','automatic','current')){$id='elysium'}
 if($id -eq 'release-fix.5' -and $userSelected -ne '1'){
  $id='elysium'
  Set-UncannyIni $preference 'Engine' 'Id' 'automatic'
  Set-UncannyIni $preference 'Engine' 'Confirmed' 'elysium'
  Set-UncannyIni $preference 'Engine' 'UserSelected' '0'
  Set-UncannyIni $preference 'Engine' 'LastResult' 'LEGACY_PREFERENCE_MIGRATED_TO_ELYSIUM'
 }
 if($id -notin @('elysium','release-fix.5')){throw 'Unrecognized engine preference.'}
 $state=Join-Path $Root '.uncanny';New-Item -ItemType Directory -Path $state -Force|Out-Null
 $lockPath=Join-Path $state 'engine-switch.lock';Assert-UncannyNoReparsePath $lockPath;$lock=[IO.FileStream]::new($lockPath,[IO.FileMode]::OpenOrCreate,[IO.FileAccess]::ReadWrite,[IO.FileShare]::None)
 try{
  if($Mode -eq 'Commit'){$active=Get-UncannyIni (Join-Path $Root '.uncanny/engine-active.ini') 'Engine' 'Id';if(!$active -or $active -in @('current','default','automatic')){$active='elysium'};if($active -notin @('elysium','release-fix.5')){throw 'Invalid active engine.'};Set-UncannyIni $preference 'Engine' 'Confirmed' $active;return $(if($active -eq 'release-fix.5'){136}else{143})}
  Assert-UncannyEngineClosed $Root $CallerId
  if($Mode -eq 'Rollback'){$id=Get-UncannyIni $preference 'Engine' 'Confirmed';if(!$id -or $id -in @('default','automatic','current')){$id='elysium'};if($id -notin @('elysium','release-fix.5')){throw 'Invalid prior engine preference.'}}
  if($Mode -ne 'Restore' -and $id -ne 'elysium'){$null=Read-UncannyEngineBundle $Root $id $Architecture}
  Restore-UncannyEngineBase $Root
  if($Mode -eq 'Restore'){return 143}
  $abi=Install-UncannyEngineBundle $Root $id $Architecture
  if($Mode -eq 'Rollback'){Set-UncannyIni $preference 'Engine' 'Id' $id;Set-UncannyIni $preference 'Engine' 'LastResult' 'STARTUP_FAILED_PREVIOUS_ENGINE_RESTORED';$active=Join-Path $Root '.uncanny/engine-active.ini';Set-UncannyIni $active 'Engine' 'FallbackReason' 'STARTUP_FAILED_PREVIOUS_ENGINE_RESTORED';Set-UncannyIni $active 'Engine' 'LastResult' 'ROLLBACK_OK'}
  return $abi
 }finally{$lock.Dispose()}
}
