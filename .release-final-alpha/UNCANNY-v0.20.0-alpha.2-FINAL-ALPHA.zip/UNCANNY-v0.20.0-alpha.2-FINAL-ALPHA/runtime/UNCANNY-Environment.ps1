﻿Set-StrictMode -Version Latest
function Get-UncannyEnvironment([string]$TargetDir){
 Assert-UncannyNoReparsePath $TargetDir
 $base=(Resolve-Path -LiteralPath $TargetDir).Path
 $proxy='^(dxgi|d3d8|d3d9|d3d10|d3d10core|d3d11|d3d12|opengl32|winmm|version|xinput[\w_]*|nvngx|_nvngx)\.dll$'
 $knownConfig='^(ReShade.*\.(ini|log)|ReShadePreset\.ini|OptiScaler\.(ini|log)|dlss5-feed\.(cfg|log))$'
 $rows=[Collections.Generic.List[object]]::new()
 foreach($item in Get-ChildItem -LiteralPath $base -Force){
  if($item.Attributes -band [IO.FileAttributes]::ReparsePoint){$rows.Add([pscustomobject]@{path=$item.FullName;relative=$item.Name;classification='UNKNOWN_GRAPHICS_MOD';reason='Linked path retained; contents not inspected';sha256='';size=0});continue}
  if($item.PSIsContainer){
   if($item.Name -ieq 'reshade-shaders'){
    foreach($file in Get-ChildItem -LiteralPath $item.FullName -File -Recurse -Force){
     $ancestor=$file.Directory;while($ancestor.FullName -ne $base){if($ancestor.Attributes -band [IO.FileAttributes]::ReparsePoint){throw "Reparse point in mod tree: $($ancestor.FullName)"};$ancestor=$ancestor.Parent;if(!$ancestor){throw 'Invalid ancestor path'}}
     $rows.Add([pscustomobject]@{path=$file.FullName;relative=$file.FullName.Substring($base.Length+1);classification='CONFIRMED_CONFLICT';reason='Known ReShade shader folder';sha256=(Get-UncannySHA256 $file.FullName);size=$file.Length})
    }
   };continue
  }
  $candidate=$item.Name -match $proxy -or $item.Name -match $knownConfig -or $item.Name -match '(?i)(reshade|renodx|shortfuse|optiscaler|dlss5.feed|uncanny|dfc).*\.(dll|addon32|addon64)$' -or $item.Extension -match '^\.addon(32|64)$'
  if(!$candidate){continue}
  if($item.Name -match '^UNCANNY\.(NativeRuntime|NativeLauncher|Revenant|ControlDeck)\.(dll|exe)$' -or $item.Name -match '^UNCANNY-nvngx\.dll\.bridge(32|64)\.dll$'){continue} # managed by the verified install/rollback transaction
  $class='UNKNOWN_GRAPHICS_MOD';$reason='Proxy/mod filename alone does not establish provenance'
  if($item.Name -match $knownConfig){$class='CONFIRMED_CONFLICT';$reason='Known graphics injector configuration/log'}
  else{
   $info=$item.VersionInfo;$metadata="$($info.ProductName) $($info.FileDescription) $($info.CompanyName)"
   if($metadata -match '(?i)(ReShade|RenoDX|ShortFuse|OptiScaler|DLSS5.Feeder|Deep Fried Chicken)'){$class='CONFIRMED_CONFLICT';$reason='Injector identity in PE version metadata'}
   elseif($item.Length -lt 134217728){
    try{$pe=Get-UncannyPeInfo $item.FullName
      if($pe.Exports -contains 'ReShadeRegisterAddon' -and $pe.Exports -contains 'ReShadeUnregisterAddon'){$class='CONFIRMED_CONFLICT';$reason='Verified ReShade export table'}
    }catch{ $reason='Unrecognized or unreadable graphics candidate; retained' }
   }
   if($class -eq 'UNKNOWN_GRAPHICS_MOD' -and (Get-Command Get-AuthenticodeSignature -ErrorAction SilentlyContinue)){
    $sig=Get-AuthenticodeSignature -LiteralPath $item.FullName
    if($sig.Status -eq 'Valid' -and $sig.SignerCertificate.Subject -match 'Microsoft'){$class='SIGNED_PLATFORM_FILE';$reason='Valid Microsoft signature; retained'}
   }
  }
  $rows.Add([pscustomobject]@{path=$item.FullName;relative=$item.Name;classification=$class;reason=$reason;sha256=(Get-UncannySHA256 $item.FullName);size=$item.Length})
 }
 $conflicts=@($rows|Where-Object classification -eq 'CONFIRMED_CONFLICT');$unknown=@($rows|Where-Object classification -eq 'UNKNOWN_GRAPHICS_MOD')
 [pscustomobject]@{target=$base;status=$(if($conflicts.Count){'CONFLICT DETECTED'}elseif($unknown.Count){'UNVERIFIED'}else{'NO KNOWN DISK CONFLICTS'});confirmed=$conflicts.Count;unknown=$unknown.Count;files=@($rows);processVerified=$false;checkedAt=(Get-Date -Format o)}
}
function Save-UncannyEnvironmentJson($Object,[string]$Path){Assert-UncannyNoReparsePath $Path;Assert-UncannyNoReparsePath ($Path+'.tmp');$Object|ConvertTo-Json -Depth 12|Set-Content -LiteralPath ($Path+'.tmp') -Encoding utf8;Move-Item -LiteralPath ($Path+'.tmp') -Destination $Path -Force}
function Clear-UncannyEnvironment([string]$TargetDir,[string]$BackupRoot=''){
 Assert-UncannyClosed $TargetDir @()
 $scan=Get-UncannyEnvironment $TargetDir
 $files=@($scan.files|Where-Object classification -eq 'CONFIRMED_CONFLICT')
 if(!$files.Count){return [pscustomobject]@{backup='';scan=$scan}}
 if(!$BackupRoot){$BackupRoot=Join-Path $env:LOCALAPPDATA 'UNCANNY/GraphicsBackups'}
 $BackupRoot=[IO.Path]::GetFullPath($BackupRoot)
 if($BackupRoot.TrimEnd([IO.Path]::DirectorySeparatorChar) -ieq $scan.target.TrimEnd([IO.Path]::DirectorySeparatorChar) -or (Test-UncannyPathWithin $BackupRoot $scan.target)){throw 'Graphics backup must be outside the active game directory.'}
 Assert-UncannyNoReparsePath $BackupRoot
 $backup=Join-Path $BackupRoot ((Split-Path -Leaf $scan.target)+'-'+[guid]::NewGuid().ToString('N'))
 New-Item -ItemType Directory -Path (Join-Path $backup 'files') -Force|Out-Null
 $manifest=[pscustomobject]@{schema=1;target=$scan.target;created=(Get-Date -Format o);phase='prepared';files=$files}
 Save-UncannyEnvironmentJson $manifest (Join-Path $backup 'manifest.json')
 foreach($file in $files){
  $dest=Join-Path (Join-Path $backup 'files') $file.relative;New-Item -ItemType Directory -Path (Split-Path -Parent $dest) -Force|Out-Null
  Copy-Item -LiteralPath $file.path -Destination $dest
  if((Get-UncannySHA256 $dest) -ne $file.sha256){throw 'Graphics backup verification failed; active files retained.'}
 }
 $manifest.phase='backed-up';Save-UncannyEnvironmentJson $manifest (Join-Path $backup 'manifest.json')
 foreach($file in $files){if((Get-UncannySHA256 $file.path) -ne $file.sha256){throw 'Graphics files changed during scan; verified backups retained.'}}
 try{
 foreach($file in $files){Assert-UncannyNoReparsePath $file.path;if((Get-UncannySHA256 $file.path) -ne $file.sha256){throw 'Graphics file changed before quarantine.'};Remove-Item -LiteralPath $file.path -Force}
 $shaders=Join-Path $scan.target 'reshade-shaders'
 if(Test-Path -LiteralPath $shaders){Get-ChildItem -LiteralPath $shaders -Directory -Recurse|Sort-Object {$_.FullName.Length} -Descending|ForEach-Object{if(!(Get-ChildItem -LiteralPath $_.FullName -Force)){Remove-Item -LiteralPath $_.FullName}};if(!(Get-ChildItem -LiteralPath $shaders -Force)){Remove-Item -LiteralPath $shaders}}
 foreach($file in $files){if(Test-Path -LiteralPath $file.path){throw 'Graphics conflict remains active after cleanup.'}}
 $after=Get-UncannyEnvironment $scan.target;if($after.confirmed){throw 'Confirmed conflicts remain after cleanup.'}
 $manifest.phase='quarantined';Save-UncannyEnvironmentJson $manifest (Join-Path $backup 'manifest.json')
 }catch{
  $failure=$_
  foreach($file in $files){if(!(Test-Path -LiteralPath $file.path)){try{Assert-UncannyNoReparsePath $file.path;New-Item -ItemType Directory -Path (Split-Path -Parent $file.path) -Force|Out-Null;Copy-Item -LiteralPath (Join-Path (Join-Path $backup 'files') $file.relative) -Destination $file.path}catch{Write-Warning "Partial cleanup recovery needed: $backup"}}}
  $manifest.phase='cleanup-failed';Save-UncannyEnvironmentJson $manifest (Join-Path $backup 'manifest.json');throw "Graphics cleanup failed; verified recovery is at $backup :: $failure"
 }
 [pscustomobject]@{backup=$backup;scan=$after}
}
function Test-UncannyMutableGraphicsArtifact([string]$Relative){
 return $Relative -match '(?i)(^|[\\/])(?:ReShade|OptiScaler|dlss5-feed)[^\\/]*\.log$'
}
function Restore-UncannyEnvironment([string]$TargetDir,[string]$BackupDir,[switch]$PreflightOnly,[hashtable]$PlannedRemovals=@{}){
 Assert-UncannyClosed $TargetDir @()
 Assert-UncannyNoReparsePath $TargetDir;Assert-UncannyNoReparsePath $BackupDir
 $base=(Resolve-Path -LiteralPath $TargetDir).Path;$backup=(Resolve-Path -LiteralPath $BackupDir).Path
 $m=Get-Content -LiteralPath (Join-Path $backup 'manifest.json') -Raw|ConvertFrom-Json
 if($m.schema -ne 1 -or $m.target -ine $base){throw 'Foreign graphics backup; nothing restored.'}
 foreach($file in $m.files){
  $dest=[IO.Path]::GetFullPath((Join-Path $base $file.relative));$source=[IO.Path]::GetFullPath((Join-Path (Join-Path $backup 'files') $file.relative))
  if(!(Test-UncannyPathWithin $dest $base) -or !(Test-UncannyPathWithin $source (Join-Path $backup 'files'))){throw 'Backup path escapes its recorded root.'}
  Assert-UncannyNoReparsePath $source;Assert-UncannyNoReparsePath $dest
  if(!(Test-Path -LiteralPath $source) -or (Get-UncannySHA256 $source) -ne $file.sha256){throw 'Graphics backup hash mismatch.'}
  if(Test-Path -LiteralPath $dest){
   $current=(Get-UncannySHA256 $dest)
   if($current -ine $file.sha256){
    $willRemove=$PreflightOnly -and $PlannedRemovals.ContainsKey($dest) -and $current -ieq $PlannedRemovals[$dest]
    $mutableGenerated=Test-UncannyMutableGraphicsArtifact ([string]$file.relative)
    if(!$willRemove -and !$mutableGenerated){throw "Restore conflict; current file retained: $dest"}
    if($mutableGenerated){Write-Verbose "Mutable graphics log changed after install; restore will replace the generated log: $dest"}
   }
  }
 }
 if($PreflightOnly){return}
 foreach($file in $m.files){
  $dest=Join-Path $base $file.relative
  $current=if(Test-Path -LiteralPath $dest){(Get-UncannySHA256 $dest)}else{''}
  Set-UncannyVerifiedFile (Join-Path (Join-Path $backup 'files') $file.relative) $dest $file.sha256 $current
 }
 $m.phase='restored';Save-UncannyEnvironmentJson $m (Join-Path $backup 'manifest.json')
 'Previous graphics files restored and hash verified. Restart required before any runtime verification.'
}
