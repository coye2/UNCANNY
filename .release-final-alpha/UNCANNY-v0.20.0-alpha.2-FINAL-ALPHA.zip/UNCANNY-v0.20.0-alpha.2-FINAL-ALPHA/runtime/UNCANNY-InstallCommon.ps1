﻿Set-StrictMode -Version Latest
function Get-UncannyFileBytes([string]$Path,[int]$Attempts=8){
  $last=$null
  for($attempt=0;$attempt -lt $Attempts;$attempt++){
    try{
      $share=[IO.FileShare]::ReadWrite -bor [IO.FileShare]::Delete
      $stream=[IO.FileStream]::new($Path,[IO.FileMode]::Open,[IO.FileAccess]::Read,$share)
      try{
        if($stream.Length -gt 512MB){throw "File is unexpectedly large: $Path"}
        $memory=[IO.MemoryStream]::new()
        try{$stream.CopyTo($memory);return $memory.ToArray()}finally{$memory.Dispose()}
      }finally{$stream.Dispose()}
    }catch{
      $last=$_.Exception
      if($attempt+1 -lt $Attempts){Start-Sleep -Milliseconds (120+($attempt*80))}
    }
  }
  throw ("Could not read file after bounded retries: "+$Path+" | "+$last.Message)
}
function Get-UncannySHA256([string]$Path,[int]$Attempts=8){
  $last=$null
  for($attempt=0;$attempt -lt $Attempts;$attempt++){
    try{
      $share=[IO.FileShare]::ReadWrite -bor [IO.FileShare]::Delete
      $stream=[IO.FileStream]::new($Path,[IO.FileMode]::Open,[IO.FileAccess]::Read,$share)
      try{
        $sha=[Security.Cryptography.SHA256]::Create()
        try{return -join ($sha.ComputeHash($stream)|ForEach-Object{$_.ToString('x2')})}finally{$sha.Dispose()}
      }finally{$stream.Dispose()}
    }catch{
      $last=$_.Exception
      if($attempt+1 -lt $Attempts){Start-Sleep -Milliseconds (120+($attempt*80))}
    }
  }
  throw ("Could not hash file after bounded retries: "+$Path+" | "+$last.Message)
}
function Get-UncannyPeInfo([string]$Path) {
  $bytes=Get-UncannyFileBytes $Path
  if($bytes.Length -lt 64 -or [BitConverter]::ToUInt16($bytes,0) -ne 0x5a4d){throw "Invalid PE: $Path"}
  $pe=[BitConverter]::ToInt32($bytes,0x3c)
  if($pe -lt 64 -or $pe -gt $bytes.Length-256 -or [BitConverter]::ToUInt32($bytes,$pe) -ne 0x4550){throw "Invalid PE header: $Path"}
  $machine=[BitConverter]::ToUInt16($bytes,$pe+4);$arch=if($machine -eq 0x8664){'64'}elseif($machine -eq 0x14c){'32'}else{throw 'Only x86 and x64 target processes are supported.'}
  $optional=$pe+24;$magic=[BitConverter]::ToUInt16($bytes,$optional)
  if(($arch -eq '64' -and $magic -ne 0x20b) -or ($arch -eq '32' -and $magic -ne 0x10b)){throw 'PE architecture/header mismatch.'}
  $optSize=[BitConverter]::ToUInt16($bytes,$pe+20);$sectionStart=$optional+$optSize;$count=[BitConverter]::ToUInt16($bytes,$pe+6)
  if($count -gt 96 -or $sectionStart+40*$count -gt $bytes.Length){throw 'Invalid PE section table.'}
  $sections=@();for($i=0;$i -lt $count;$i++){$at=$sectionStart+40*$i;$sections+=@{virtualSize=[BitConverter]::ToUInt32($bytes,$at+8);rva=[BitConverter]::ToUInt32($bytes,$at+12);rawSize=[BitConverter]::ToUInt32($bytes,$at+16);raw=[BitConverter]::ToUInt32($bytes,$at+20)}}
  function Local-Rva([uint32]$Address){
    foreach($s in $sections){if($Address -ge $s.rva -and [uint64]$Address -lt [uint64]$s.rva+[Math]::Max($s.virtualSize,$s.rawSize)){$offset=[int64]$s.raw+$Address-$s.rva;if($offset -ge 0 -and $offset -lt $bytes.Length){return $offset}}};return -1
  }
  $dirOffset=if($arch -eq '64'){112}else{96};$imports=@()
  if($optSize -ge $dirOffset+16){$rva=[BitConverter]::ToUInt32($bytes,$optional+$dirOffset+8);if($rva){$pos=Local-Rva $rva
    for($i=0;$pos -ge 0 -and $pos+20 -le $bytes.Length -and $i -lt 4096;$i++){$nameRva=[BitConverter]::ToUInt32($bytes,[int]$pos+12);if(!$nameRva){break};$np=Local-Rva $nameRva;if($np -lt 0){break};$end=$np;while($end -lt $bytes.Length -and $end-$np -lt 256 -and $bytes[$end]){$end++};$imports+=[Text.Encoding]::ASCII.GetString($bytes,[int]$np,[int]($end-$np)).ToLowerInvariant();$pos+=20}
  }}
  $apis=@();foreach($api in @('d3d8','d3d9','d3d10','d3d10_1','d3d11','d3d12','dxgi','opengl32','vulkan-1')){if($imports -contains "$api.dll"){$apis+=$api}}
  $exports=@()
  if($optSize -ge $dirOffset+8){$rva=[BitConverter]::ToUInt32($bytes,$optional+$dirOffset);if($rva){$ep=Local-Rva $rva
    if($ep -ge 0 -and $ep+40 -le $bytes.Length){$names=[BitConverter]::ToUInt32($bytes,[int]$ep+24);$table=Local-Rva ([BitConverter]::ToUInt32($bytes,[int]$ep+32))
      if($names -le 65536 -and $table -ge 0 -and $table+4*$names -le $bytes.Length){for($j=0;$j -lt $names;$j++){$np=Local-Rva ([BitConverter]::ToUInt32($bytes,[int]$table+4*$j));if($np -lt 0){continue};$end=$np;while($end -lt $bytes.Length -and $end-$np -lt 256 -and $bytes[$end]){$end++};if($end -lt $bytes.Length -and $bytes[$end] -eq 0){$exports+=[Text.Encoding]::ASCII.GetString($bytes,[int]$np,[int]($end-$np))}}}
    }
  }}
  [pscustomobject]@{Architecture=$arch;Machine=$machine;Imports=@($imports);Exports=@($exports);ApiHints=@($apis);Evidence='PE tables only; actual API is reported after device capture'}
}
function Get-UncannyTargetPeInfo([string]$Path){
  $share=[IO.FileShare]::ReadWrite -bor [IO.FileShare]::Delete
  $stream=[IO.FileStream]::new($Path,[IO.FileMode]::Open,[IO.FileAccess]::Read,$share)
  try{
    $reader=[IO.BinaryReader]::new($stream,[Text.Encoding]::ASCII,$true)
    try{
      if($stream.Length -lt 256){throw "Invalid PE: $Path"}
      $stream.Position=0
      if($reader.ReadUInt16() -ne 0x5a4d){throw "Invalid PE: $Path"}
      $stream.Position=0x3c;$pe=$reader.ReadInt32()
      if($pe -lt 64 -or $pe -gt $stream.Length-256){throw "Invalid PE header: $Path"}
      $stream.Position=$pe
      if($reader.ReadUInt32() -ne 0x4550){throw "Invalid PE header: $Path"}
      $machine=$reader.ReadUInt16();$sectionCount=$reader.ReadUInt16()
      if($sectionCount -gt 96){throw 'Invalid PE section table.'}
      $arch=if($machine -eq 0x8664){'64'}elseif($machine -eq 0x14c){'32'}else{throw 'Only x86 and x64 target processes are supported.'}
      $stream.Position=$pe+20;$optSize=$reader.ReadUInt16();$optional=$pe+24
      if($optional+$optSize -gt $stream.Length){throw 'Invalid PE optional header.'}
      $stream.Position=$optional;$magic=$reader.ReadUInt16()
      if(($arch -eq '64' -and $magic -ne 0x20b) -or ($arch -eq '32' -and $magic -ne 0x10b)){throw 'PE architecture/header mismatch.'}
      $dirOffset=if($arch -eq '64'){112}else{96}
      $importRva=[uint32]0
      if($optSize -ge $dirOffset+16){$stream.Position=$optional+$dirOffset+8;$importRva=$reader.ReadUInt32()}
      $sections=@()
      $sectionStart=$optional+$optSize
      for($i=0;$i -lt $sectionCount;$i++){
        $at=$sectionStart+40*$i
        if($at+40 -gt $stream.Length){throw 'Invalid PE section table.'}
        $stream.Position=$at+8
        $virtualSize=$reader.ReadUInt32();$rva=$reader.ReadUInt32();$rawSize=$reader.ReadUInt32();$raw=$reader.ReadUInt32()
        $sections+=[pscustomobject]@{virtualSize=$virtualSize;rva=$rva;rawSize=$rawSize;raw=$raw}
      }
      function Resolve-TargetRva([uint32]$Address){
        foreach($s in $sections){
          $span=[Math]::Max([uint64]$s.virtualSize,[uint64]$s.rawSize)
          if([uint64]$Address -ge [uint64]$s.rva -and [uint64]$Address -lt [uint64]$s.rva+$span){
            $offset=[uint64]$s.raw+([uint64]$Address-[uint64]$s.rva)
            if($offset -lt [uint64]$stream.Length){return [int64]$offset}
          }
        }
        return [int64]-1
      }
      $imports=@()
      if($importRva){
        $pos=Resolve-TargetRva $importRva
        for($i=0;$pos -ge 0 -and $pos+20 -le $stream.Length -and $i -lt 4096;$i++){
          $stream.Position=$pos+12;$nameRva=$reader.ReadUInt32()
          if(!$nameRva){break}
          $namePos=Resolve-TargetRva $nameRva
          if($namePos -lt 0){break}
          $stream.Position=$namePos
          $bytes=[Collections.Generic.List[byte]]::new()
          for($j=0;$j -lt 256 -and $stream.Position -lt $stream.Length;$j++){
            $b=$reader.ReadByte();if($b -eq 0){break};$bytes.Add($b)
          }
          if($bytes.Count){$imports+=[Text.Encoding]::ASCII.GetString($bytes.ToArray()).ToLowerInvariant()}
          $pos+=20
        }
      }
      $apis=@();foreach($api in @('d3d8','d3d9','d3d10','d3d10_1','d3d11','d3d12','dxgi','opengl32','vulkan-1')){if($imports -contains "$api.dll"){$apis+=$api}}
      return [pscustomobject]@{Architecture=$arch;Machine=$machine;Imports=@($imports);Exports=@();ApiHints=@($apis);Evidence='PE headers/import table only; actual API is reported after device capture'}
    }finally{$reader.Dispose()}
  }finally{$stream.Dispose()}
}
function Test-UncannyPathWithin([string]$Path,[string]$Root){
  $full=[IO.Path]::GetFullPath($Path);$base=[IO.Path]::GetFullPath($Root).TrimEnd([IO.Path]::DirectorySeparatorChar,[IO.Path]::AltDirectorySeparatorChar)
  $full.StartsWith($base+[IO.Path]::DirectorySeparatorChar,[StringComparison]::OrdinalIgnoreCase)
}
function Get-UncannyOwnershipClass([string]$Path,[string]$TargetDir=''){
  $full=[IO.Path]::GetFullPath($Path)
  $leaf=[IO.Path]::GetFileName($full)
  if($leaf -ieq 'PCSX2.ini' -or $full -match '(?i)[\\/](inis|gamesettings)[\\/].*\.ini$'){return 'HOST_CONFIG'}
  if($TargetDir){
    $state=Join-Path ([IO.Path]::GetFullPath($TargetDir)) '.uncanny'
    foreach($mutable in @('profiles','cache','runtime','runtime-state','revenant-proof','proof','status','generated')){
      if(Test-UncannyPathWithin $full (Join-Path $state $mutable)){return 'UNCANNY_MUTABLE_RUNTIME'}
    }
    if(Test-UncannyPathWithin $full $state){return 'UNCANNY_MANAGED'}
    if(Test-UncannyPathWithin $full $TargetDir){
      if($leaf -match '^(?i)UNCANNY[.\-]' -or $leaf -match '(?i)\.uncanny-original\.exe$'){return 'UNCANNY_MANAGED'}
    }
  }
  return 'ORIGINAL_USER'
}
function Test-UncannyOwnedHelperProcess([object]$Process,[string]$TargetDir){
  if(!$Process -or !$Process.ExecutablePath -or !$Process.Name){return $false}
  $path=[IO.Path]::GetFullPath([string]$Process.ExecutablePath);$target=[IO.Path]::GetFullPath($TargetDir);$state=Join-Path $target '.uncanny'
  $top=@('UNCANNY.Revenant.exe','UNCANNY.ControlDeck.exe','UNCANNY.EngineManager.exe','UNCANNY.AssetForge.exe','UNCANNY.NeuralHost32.exe','UNCANNY.NeuralHost64.exe')
  if((Split-Path -Parent $path) -ieq $target -and $Process.Name -in $top){return $true}
  if((Test-UncannyPathWithin $path $state) -and ($Process.Name -match '^(?i)UNCANNY\.(NeuralHost(?:32|64)?|Revenant(?:32|64)?|ControlDeck(?:32|64)?|EngineManager|AssetForge).*\.exe$' -or $Process.Name -match '^(?i)(realesrgan|real-esrgan).*\.exe$')){return $true}
  return $false
}
function Get-UncannyFastLocalProcessSnapshot([string]$TargetDir){
  $base=[IO.Path]::GetFullPath($TargetDir)
  $items=[Collections.Generic.List[object]]::new()
  foreach($p in @(Get-Process -ErrorAction SilentlyContinue)){
    $path=''
    try{$path=[string]$p.Path}catch{}
    if(!$path){continue}
    try{$full=[IO.Path]::GetFullPath($path)}catch{continue}
    if(!(Test-UncannyPathWithin $full $base) -and (Split-Path -Parent $full) -ine $base){continue}
    $items.Add([pscustomobject]@{ProcessId=$p.Id;Name=$p.Name+'.exe';ExecutablePath=$full;Process=$p})
  }
  return @($items)
}
function Test-UncannyVisibleTopLevelWindow([int]$ProcessId){
  try{
    $p=Get-Process -Id $ProcessId -ErrorAction Stop
    $p.Refresh()
    return $p.MainWindowHandle -ne [IntPtr]::Zero
  }catch{return $false}
}
function Stop-UncannyVerifiedStuckLaunchTarget([string]$TargetDir,[string]$TargetExe){
  $base=[IO.Path]::GetFullPath($TargetDir);$target=[IO.Path]::GetFullPath($TargetExe)
  $record=Join-Path $base ('.uncanny/launch/'+[IO.Path]::GetFileName($target)+'.ini')
  $launcher=Join-Path $base 'UNCANNY.Launch.exe'
  if(!(Test-Path -LiteralPath $record -PathType Leaf) -or !(Test-Path -LiteralPath $launcher -PathType Leaf)){return $false}
  if((Get-UncannyIni $record 'Launch' 'Mode') -ine 'sidecar'){return $false}
  $expectedLauncher=Get-UncannyIni $record 'Launch' 'LauncherSHA256'
  if($expectedLauncher -notmatch '^[a-fA-F0-9]{64}\z' -or (Get-UncannySHA256 $launcher) -ine $expectedLauncher){return $false}
  $reclaimed=$false
  $local=@(Get-UncannyFastLocalProcessSnapshot $base)
  $targets=@($local|Where-Object{[string]::Equals([IO.Path]::GetFullPath([string]$_.ExecutablePath),$target,[StringComparison]::OrdinalIgnoreCase)})
  foreach($tp in $targets){
    if(Test-UncannyVisibleTopLevelWindow ([int]$tp.ProcessId)){continue}
    foreach($sidecar in @($local|Where-Object{[IO.Path]::GetFileName([string]$_.ExecutablePath) -ieq 'UNCANNY.Launch.exe'})){
      $sessionLog=Join-Path $base ('UNCANNY-LAUNCH-SESSION-'+[string]$sidecar.ProcessId+'.log')
      if(!(Test-Path -LiteralPath $sessionLog -PathType Leaf)){continue}
      try{$proof=(Get-Content -LiteralPath $sessionLog -Tail 160 -ErrorAction Stop) -join [Environment]::NewLine}catch{continue}
      if($proof -notmatch ('(?m)\bPROCESS_FOUND PID='+[regex]::Escape([string]$tp.ProcessId)+'\b')){continue}
      if($proof -notmatch [regex]::Escape($target)){continue}
      try{
        $event=[Threading.EventWaitHandle]::OpenExisting(('Local\UNCANNY.LaunchStop.'+[string]$sidecar.ProcessId))
        try{$event.Set()|Out-Null}finally{$event.Dispose()}
      }catch{}
      Start-Sleep -Milliseconds 500
      try{$live=Get-Process -Id $tp.ProcessId -ErrorAction Stop}catch{$live=$null}
      if($live -and !(Test-UncannyVisibleTopLevelWindow ([int]$tp.ProcessId))){
        try{Stop-Process -Id $tp.ProcessId -Force -ErrorAction Stop;$live.WaitForExit(3000)|Out-Null;$reclaimed=$true}catch{}
      }
      try{
        $s=Get-Process -Id $sidecar.ProcessId -ErrorAction Stop
        if(!$s.HasExited){Stop-Process -Id $sidecar.ProcessId -Force -ErrorAction SilentlyContinue}
      }catch{}
      break
    }
  }
  return $reclaimed
}
function Assert-UncannyClosed([string]$TargetDir,[string[]]$TargetNames){
  $deadline=(Get-Date).AddSeconds(5)
  $management=@('UNCANNY.exe','UNCANNY.AppLauncher.exe','UNCANNY.Launch.exe','UNCANNY.NativeLauncher.exe','UNCANNY.EngineLauncher.exe')
  $targets=@($TargetNames|Where-Object{$_ -and $_ -notin $management}|ForEach-Object{$_.ToLowerInvariant()})
  do{
    $local=Get-UncannyFastLocalProcessSnapshot $TargetDir
    $helpers=@($local|Where-Object{Test-UncannyOwnedHelperProcess $_ $TargetDir})
    foreach($h in $helpers){try{Stop-Process -Id $h.ProcessId -Force -ErrorAction SilentlyContinue}catch{}}
    if(!$helpers.Count){break};Start-Sleep -Milliseconds 100
  }while((Get-Date)-lt $deadline)
  $blocking=@(Get-UncannyFastLocalProcessSnapshot $TargetDir|Where-Object{
    !(Test-UncannyOwnedHelperProcess $_ $TargetDir) -and $_.Name -notin $management -and
    ($targets.Count -eq 0 -or $targets -contains $_.Name.ToLowerInvariant())
  })
  if($blocking.Count){throw ('Close the running game/emulator before installing UNCANNY: '+(($blocking|ForEach-Object{"$($_.Name) (PID $($_.ProcessId))"}) -join ', '))}
}
function Get-UncannyReparseTag([string]$Path){
  if(-not ('UncannyReparseTagReader' -as [type])){
    Add-Type -TypeDefinition @'
using System;
using System.Runtime.InteropServices;
using Microsoft.Win32.SafeHandles;
public static class UncannyReparseTagReader {
  [StructLayout(LayoutKind.Sequential, CharSet=CharSet.Unicode)]
  public struct WIN32_FIND_DATA {
    public uint dwFileAttributes;
    public System.Runtime.InteropServices.ComTypes.FILETIME ftCreationTime;
    public System.Runtime.InteropServices.ComTypes.FILETIME ftLastAccessTime;
    public System.Runtime.InteropServices.ComTypes.FILETIME ftLastWriteTime;
    public uint nFileSizeHigh;
    public uint nFileSizeLow;
    public uint dwReserved0;
    public uint dwReserved1;
    [MarshalAs(UnmanagedType.ByValTStr, SizeConst=260)] public string cFileName;
    [MarshalAs(UnmanagedType.ByValTStr, SizeConst=14)] public string cAlternateFileName;
  }
  [DllImport("kernel32.dll", CharSet=CharSet.Unicode, SetLastError=true)]
  static extern IntPtr FindFirstFileW(string lpFileName, out WIN32_FIND_DATA lpFindFileData);
  [DllImport("kernel32.dll", SetLastError=true)]
  static extern bool FindClose(IntPtr hFindFile);
  public static uint GetTag(string path) {
    WIN32_FIND_DATA data;
    IntPtr h=FindFirstFileW(path,out data);
    if(h==new IntPtr(-1)) return 0;
    try { return data.dwReserved0; } finally { FindClose(h); }
  }
}
'@
  }
  return [uint32][UncannyReparseTagReader]::GetTag([IO.Path]::GetFullPath($Path))
}
function Test-UncannyCloudReparseTag([uint32]$Tag){
  return (([uint64]$Tag -band [uint64]4294905855) -eq [uint64]2415919130)
}
function Assert-UncannyNoReparsePath([string]$Path){
  $current=[IO.Path]::GetFullPath($Path)
  while($current){
    if(Test-Path -LiteralPath $current){
      $item=Get-Item -LiteralPath $current -Force
      if($item.Attributes -band [IO.FileAttributes]::ReparsePoint){
        $tag=Get-UncannyReparseTag $current
        if(!(Test-UncannyCloudReparseTag $tag)){
          throw ("Linked paths cannot be modified: "+$current+" (reparse tag 0x"+$tag.ToString('X8')+")")
        }
      }
    }
    $parent=Split-Path -Parent $current;if(!$parent -or $parent -eq $current){break};$current=$parent
  }
}
function Resolve-UncannySetupTarget([string]$Path) {
  if([string]::IsNullOrWhiteSpace($Path)){throw 'UNCANNY target folder is empty.'}
  if($Path -match '[\x00-\x1f]'){throw 'UNCANNY target folder contains a control character.'}
  $candidate=$Path.Trim()
  if($candidate.Length -ge 2 -and $candidate[0] -eq [char]34 -and $candidate[$candidate.Length-1] -eq [char]34){
    $candidate=$candidate.Substring(1,$candidate.Length-2)
  }
  if([string]::IsNullOrWhiteSpace($candidate) -or $candidate -match '[\x00-\x1f"<>|*?]'){
    throw 'UNCANNY target folder contains an invalid quote, control character or wildcard. Run SETUP-DLSS5.cmd from this new package; do not append a quoted trailing backslash.'
  }
  if(![IO.Path]::IsPathRooted($candidate)){throw 'UNCANNY setup requires an absolute target folder.'}
  try{$full=[IO.Path]::GetFullPath($candidate)}catch{throw ('UNCANNY target folder could not be resolved: '+$_.Exception.Message)}
  if(!(Test-Path -LiteralPath $full -PathType Container)){throw 'UNCANNY target folder does not exist.'}
  Assert-UncannyNoReparsePath $full
  return $full
}
function Set-UncannyIni([string]$Path,[string]$Section,[string]$Key,[string]$Value){
  $lines=if(Test-Path -LiteralPath $Path){@(Get-Content -LiteralPath $Path)}else{@()}
  $out=[Collections.Generic.List[string]]::new();$inside=$false;$sectionSeen=$false;$done=$false
  foreach($line in $lines){
    if($line -match '^\s*\[([^\]]+)\]\s*$'){
      if($inside -and !$done){$out.Add("$Key=$Value");$done=$true};$inside=$Matches[1] -ieq $Section;$sectionSeen=$sectionSeen -or $inside;$out.Add($line);continue
    }
    if($inside -and $line -match ('^\s*'+[regex]::Escape($Key)+'\s*=')){if(!$done){$out.Add("$Key=$Value");$done=$true};continue};$out.Add($line)
  }
  if(!$sectionSeen){$out.Add("[$Section]");$out.Add("$Key=$Value")}elseif($inside -and !$done){$out.Add("$Key=$Value")}
  $parent=Split-Path -Parent $Path;New-Item -ItemType Directory -Path $parent -Force|Out-Null
  [IO.File]::WriteAllLines($Path,$out,[Text.UTF8Encoding]::new($false))
}
function Get-UncannyIni([string]$Path,[string]$Section,[string]$Key){
  if(!(Test-Path -LiteralPath $Path)){return ''};$inside=$false
  foreach($line in (Get-Content -LiteralPath $Path)){
    if($line -match '^\s*\[([^\]]+)\]\s*$'){$inside=$Matches[1] -ieq $Section;continue}
    if($inside -and $line -match ('^\s*'+[regex]::Escape($Key)+'\s*=\s*(.*?)\s*$')){return $Matches[1]}
  };return ''
}
function Get-UncannyFolder([string]$MainIni,[string]$DataDir,[string]$Key,[string]$Default){
  $value=Get-UncannyIni $MainIni 'Folders' $Key;if(!$value){$value=$Default}
  if(![IO.Path]::IsPathRooted($value)){$value=Join-Path $DataDir $value};[IO.Path]::GetFullPath($value)
}
function Set-UncannyPCSX2RuntimeConfig([string]$Path){
  foreach($pair in @(
    @('EmuCore/GS','DumpReplaceableTextures','true'),
    @('EmuCore/GS','LoadTextureReplacements','true'),
    @('EmuCore/GS','LoadTextureReplacementsAsync','true')
  )){Set-UncannyIni $Path $pair[0] $pair[1] $pair[2]}
  Set-UncannyIni $Path 'Hotkeys' 'ReloadTextureReplacements' 'Keyboard/Control & Keyboard/Shift & Keyboard/F10'
}
function Test-UncannyPCSX2ConfigReadable([string]$Path){
  return (Test-Path -LiteralPath $Path -PathType Leaf) -and
         -not [string]::IsNullOrWhiteSpace((Get-UncannyIni $Path 'EmuCore/GS' 'Renderer'))
}
function Set-UncannyBuildFailure([string]$Message){$script:UncannyBuildFailure=$Message;return $false}
function Test-UncannyBuild([string]$Root,[string]$Architecture){
  $script:UncannyBuildFailure=''
  $dist=Join-Path $Root 'dist';$public=Test-Path -LiteralPath (Join-Path $Root 'public-build.json');$provenance=if($public){Join-Path $Root 'public-build.json'}else{Join-Path $dist 'build-provenance.json'}
  if(!(Test-Path -LiteralPath $provenance)){return (Set-UncannyBuildFailure "Build provenance is missing: $provenance")}
  try{
    $p=Get-Content -LiteralPath $provenance -Raw|ConvertFrom-Json
    $versionPath=Join-Path $Root 'VERSION.json'
    if(!(Test-Path -LiteralPath $versionPath)){return (Set-UncannyBuildFailure 'VERSION.json is missing from the package.')}
    $v=Get-Content -LiteralPath $versionPath -Raw|ConvertFrom-Json
    if($p.build.version -ne $v.version -or $p.build.build -ne $v.build -or $p.build.abi -ne $v.abi -or $p.build.revision -ne $v.revision){return (Set-UncannyBuildFailure 'Build provenance does not match VERSION.json. The extracted package is mixed or incomplete.')}
    if($public){
      if($p.format -ne 'UNCANNY-PUBLIC-BUILD-1'){return (Set-UncannyBuildFailure 'public-build.json has an unsupported format.')}
      if(Test-Path -LiteralPath (Join-Path $Root 'src')){return (Set-UncannyBuildFailure 'Public package unexpectedly contains private source material.')}
    }else{
      $sourceRoot=Join-Path $Root 'src'
      if(!(Test-Path -LiteralPath $sourceRoot -PathType Container)){return (Set-UncannyBuildFailure 'Development source directory is missing.')}
      $actualSources=@(Get-ChildItem -LiteralPath $sourceRoot -File|ForEach-Object{'src/'+$_.Name}|Sort-Object)
      $recordedSources=@($p.sources.PSObject.Properties.Name|Sort-Object)
      if(($actualSources -join '|') -cne ($recordedSources -join '|')){return (Set-UncannyBuildFailure 'Development source set differs from build provenance.')}
      foreach($property in $p.sources.PSObject.Properties){
        $source=Join-Path $Root $property.Name
        if(!(Test-Path -LiteralPath $source)){return (Set-UncannyBuildFailure ("Source missing: "+$property.Name))}
        $actual=(Get-UncannySHA256 $source).ToLowerInvariant()
        if($actual -ne $property.Value){return (Set-UncannyBuildFailure ("Source hash mismatch: "+$property.Name))}
      }
    }
    $targets=@($p.targets|Where-Object{$_.architecture -eq $Architecture -and $_.compiled})
    if($targets.Count -ne 5 -or ((@($targets.target|Sort-Object) -join '|') -cne 'ControlDeck|DLSS5Bridge|NativeLauncher|NativeRuntime|Revenant')){return (Set-UncannyBuildFailure ("Build provenance does not contain the complete $Architecture-bit runtime target set."))}
    foreach($t in $targets){
      if($t.target -eq 'DLSS5Bridge'){
        $name="UNCANNY-nvngx.dll.bridge$Architecture.dll"
      }else{
        $extension=if($t.target -eq 'NativeRuntime'){'dll'}else{'exe'}
        $name="UNCANNY.$($t.target)$Architecture.$extension"
      }
      $file=Join-Path $dist $name
      if(!(Test-Path -LiteralPath $file -PathType Leaf)){return (Set-UncannyBuildFailure ("Required release binary is missing: dist\"+$name))}
      $actual=(Get-UncannySHA256 $file).ToLowerInvariant()
      if($actual -ne ([string]$t.sha256).ToLowerInvariant()){return (Set-UncannyBuildFailure ("Release binary hash mismatch: dist\"+$name+" expected "+$t.sha256+" got "+$actual))}
      $actualArch=(Get-UncannyTargetPeInfo $file).Architecture
      if($actualArch -ne $Architecture){return (Set-UncannyBuildFailure ("Release binary architecture mismatch: dist\"+$name+" is "+$actualArch+"-bit, expected "+$Architecture+"-bit."))}
    }
    return $true
  }catch{
    if(!$script:UncannyBuildFailure){$script:UncannyBuildFailure='Build verification error: '+$_.Exception.Message}
    return $false
  }
}
function Set-UncannyVerifiedFile([string]$Source,[string]$Destination,[string]$ExpectedSHA256,[string]$CurrentSHA256='',[switch]$SourceHashPrevalidated){
  Assert-UncannyNoReparsePath $Source;Assert-UncannyNoReparsePath $Destination
  if(!$SourceHashPrevalidated -and (Get-UncannySHA256 $Source) -ine $ExpectedSHA256){throw "Source changed before commit: $Source"}
  $parent=Split-Path -Parent $Destination;New-Item -ItemType Directory -Path $parent -Force|Out-Null
  $temp=Join-Path $parent ('.uncanny-write-'+[guid]::NewGuid().ToString('N')+'.tmp')
  try{
    Copy-Item -LiteralPath $Source -Destination $temp -ErrorAction Stop
    if((Get-UncannySHA256 $temp) -ine $ExpectedSHA256){throw 'Staged file failed verification.'}
    $stream=[IO.File]::Open($temp,[IO.FileMode]::Open,[IO.FileAccess]::ReadWrite,[IO.FileShare]::None);try{$stream.Flush($true)}finally{$stream.Dispose()}
    Assert-UncannyNoReparsePath $Destination
    if(Test-Path -LiteralPath $Destination){
      if(!$CurrentSHA256 -or (Get-UncannySHA256 $Destination) -ine $CurrentSHA256){throw "Destination changed before commit; retained: $Destination"}
      [IO.File]::Replace($temp,$Destination,[System.Management.Automation.Language.NullString]::Value)
    }else{
      if($CurrentSHA256){throw "Destination disappeared before commit: $Destination"}
      [IO.File]::Move($temp,$Destination)
    }
    if((Get-UncannySHA256 $Destination) -ine $ExpectedSHA256){throw "Committed file failed verification: $Destination"}
  }finally{if(Test-Path -LiteralPath $temp){Remove-Item -LiteralPath $temp -Force}}
}
function Stop-UncannyOrphanCompanions([string]$TargetDir){
  Assert-UncannyNoReparsePath $TargetDir
  foreach($entry in @(Get-UncannyFastLocalProcessSnapshot $TargetDir)){
    if(!(Test-UncannyOwnedHelperProcess $entry $TargetDir)){continue}
    try{Stop-Process -Id $entry.ProcessId -Force -ErrorAction SilentlyContinue}catch{}
  }
}
function Get-UncannyLaunchTarget([string]$Exe){
  $Exe=[IO.Path]::GetFullPath($Exe);$dir=Split-Path -Parent $Exe;$name=[IO.Path]::GetFileName($Exe)
  if($name -match '^UNCANNY[.-]' -or $name -match '\.uncanny-original\.exe$'){throw 'Select the real game/emulator EXE, not an UNCANNY launcher or recovery EXE.'}
  $legacyOriginal=Join-Path $dir ([IO.Path]::GetFileNameWithoutExtension($Exe)+'.uncanny-original.exe')
  $record=Join-Path $dir ('.uncanny/launch/'+$name+'.ini')
  $actual=$Exe;$actualSHA='';$legacyMigration=$false
  if(Test-Path -LiteralPath $record -PathType Leaf){
    $mode=Get-UncannyIni $record 'Launch' 'Mode'
    if($mode -ieq 'sidecar'){
      $recordTarget=Get-UncannyIni $record 'Launch' 'Target'
      if($recordTarget -and $recordTarget -cne $name){throw 'UNCANNY sidecar launch record belongs to a different target; no files changed.'}
      if(!(Test-Path -LiteralPath $Exe -PathType Leaf)){throw 'Installed target EXE is missing.'}
      $actualSHA=(Get-UncannySHA256 $Exe).ToLowerInvariant()
      if($name -ieq 'pcsx2-qt.exe' -and (Test-Path -LiteralPath $legacyOriginal -PathType Leaf)){
        $oldLauncher=Join-Path $dir 'UNCANNY.NativeLauncher.exe'
        if(Test-Path -LiteralPath $oldLauncher -PathType Leaf){
          $oldLauncherSHA=(Get-UncannySHA256 $oldLauncher).ToLowerInvariant()
          if($actualSHA -eq $oldLauncherSHA){
            $legacySHA=(Get-UncannySHA256 $legacyOriginal).ToLowerInvariant()
            if(!$legacySHA -or $legacySHA -eq $actualSHA){throw 'Legacy PCSX2 original recovery image is invalid; no files changed.'}
            $actual=$legacyOriginal;$actualSHA=$legacySHA;$legacyMigration=$true
          }
        }
      }
    }else{
      $saved=Get-UncannyIni $record 'Launch' 'Original'
      $expected=Get-UncannyIni $record 'Launch' 'SHA256'
      $wrapper=Get-UncannyIni $record 'Launch' 'WrapperSHA256'
      if($saved -cne [IO.Path]::GetFileName($legacyOriginal) -or $expected -notmatch '^[a-fA-F0-9]{64}$' -or $wrapper -notmatch '^[a-fA-F0-9]{64}$'){throw 'Legacy direct-launch record is invalid; originals retained.'}
      if(!(Test-Path -LiteralPath $legacyOriginal -PathType Leaf)){throw 'Legacy preserved original is missing. Restore/reinstall the application before updating UNCANNY.'}
      $legacySHA=(Get-UncannySHA256 $legacyOriginal).ToLowerInvariant()
      if($legacySHA -ine $expected){throw 'Legacy preserved original changed; no files were modified.'}
      $entrySHA=(Get-UncannySHA256 $Exe).ToLowerInvariant()
      if($entrySHA -ieq $wrapper){$actual=$legacyOriginal;$actualSHA=$legacySHA;$legacyMigration=$true}
      else{$actual=$Exe;$actualSHA=$entrySHA}
    }
  }elseif(Test-Path -LiteralPath $legacyOriginal -PathType Leaf){
    $oldLauncher=Join-Path $dir 'UNCANNY.NativeLauncher.exe'
    if($name -ieq 'pcsx2-qt.exe' -and (Test-Path -LiteralPath $oldLauncher -PathType Leaf)){
      $entrySHA=(Get-UncannySHA256 $Exe).ToLowerInvariant();$oldLauncherSHA=(Get-UncannySHA256 $oldLauncher).ToLowerInvariant()
      if($entrySHA -eq $oldLauncherSHA){$actual=$legacyOriginal;$actualSHA=(Get-UncannySHA256 $legacyOriginal).ToLowerInvariant();$legacyMigration=$true}
      else{throw 'An untracked recovery EXE already occupies the legacy backup name; files retained.'}
    }else{throw 'An untracked recovery EXE already occupies the legacy backup name; files retained.'}
  }else{
    if(!(Test-Path -LiteralPath $Exe -PathType Leaf)){throw 'Target executable does not exist.'}
    $actualSHA=(Get-UncannySHA256 $Exe).ToLowerInvariant()
  }
  [pscustomobject]@{
    Actual=$actual
    Target=$Exe
    Record=$record
    ActualSHA256=$actualSHA
    LegacyOriginal=$legacyOriginal
    LegacyMigration=$legacyMigration
    Mode=($(if($name -ieq 'pcsx2-qt.exe'){'sidecar'}else{'direct-wrapper'}))
    Launcher=(Join-Path $dir 'UNCANNY.Launch.exe')
  }
}
function Request-UncannyIdleLauncherStop([string]$TargetDir){
  $base=[IO.Path]::GetFullPath($TargetDir)
  foreach($entry in @(Get-UncannyFastLocalProcessSnapshot $TargetDir)){
    $path=[string]$entry.ExecutablePath
    if(!$path -or (Split-Path -Parent $path) -ine $base){continue}
    $verified=$false
    $record=Join-Path $base ('.uncanny/launch/'+[IO.Path]::GetFileName($path)+'.ini')
    if(Test-Path -LiteralPath $record -PathType Leaf){
      $sha=Get-UncannyIni $record 'Launch' 'WrapperSHA256'
      $verified=$sha -match '^[a-fA-F0-9]{64}$' -and (Get-UncannySHA256 $path) -ieq $sha
    }elseif([IO.Path]::GetFileName($path) -ieq 'UNCANNY.Launch.exe'){
      $launchSHA=(Get-UncannySHA256 $path).ToLowerInvariant()
      $records=Join-Path $base '.uncanny/launch'
      if(Test-Path -LiteralPath $records -PathType Container){
        foreach($candidate in @(Get-ChildItem -LiteralPath $records -Filter '*.ini' -File -ErrorAction SilentlyContinue)){
          $mode=Get-UncannyIni $candidate.FullName 'Launch' 'Mode'
          $sha=Get-UncannyIni $candidate.FullName 'Launch' 'LauncherSHA256'
          if($mode -ieq 'sidecar' -and $sha -match '^[a-fA-F0-9]{64}$' -and $launchSHA -ieq $sha){$verified=$true;break}
        }
      }
    }
    if(!$verified){continue}
    try{
      $event=[Threading.EventWaitHandle]::OpenExisting(('Local\UNCANNY.LaunchStop.'+[string]$entry.ProcessId))
      try{$event.Set()|Out-Null}finally{$event.Dispose()}
      try{$entry.Process.WaitForExit(2000)|Out-Null}catch{}
    }catch{}
  }
}
function Resolve-UncannyNeuralRepairTarget([string]$ExplicitExe,[string]$ScriptDirectory,[string]$LastTargetFile){
  $candidate=$ExplicitExe
  if([string]::IsNullOrWhiteSpace($candidate)){
    if(Test-Path -LiteralPath (Join-Path $ScriptDirectory 'UNCANNY.NativeRuntime.dll') -PathType Leaf){
      return (Resolve-UncannySetupTarget $ScriptDirectory)
    }
    if(!$LastTargetFile -or !(Test-Path -LiteralPath $LastTargetFile -PathType Leaf)){throw 'No installed target found. Drag the installed game EXE onto REPAIR-NEURAL-CORE.cmd.'}
    Assert-UncannyNoReparsePath $LastTargetFile
    if((Get-Item -LiteralPath $LastTargetFile).Length -gt 65536){throw 'Last-target record is too large.'}
    $candidate=[IO.File]::ReadAllText($LastTargetFile).TrimEnd([char]13,[char]10)
  }
  if([string]::IsNullOrWhiteSpace($candidate) -or $candidate -match '[\x00-\x1f"<>|*?]' -or ![IO.Path]::IsPathRooted($candidate)){throw 'Invalid installed target EXE path; no files changed.'}
  if(!(Test-Path -LiteralPath $candidate -PathType Leaf) -or [IO.Path]::GetExtension($candidate) -ine '.exe'){throw 'The installed target EXE does not exist.'}
  Assert-UncannyNoReparsePath $candidate
  $target=Resolve-UncannySetupTarget (Split-Path -Parent ((Resolve-Path -LiteralPath $candidate).Path))
  if(!(Test-Path -LiteralPath (Join-Path $target 'UNCANNY.NativeRuntime.dll') -PathType Leaf)){throw 'No installed UNCANNY runtime beside this EXE; use INSTALL-NATIVE.cmd first.'}
  return $target
}
