﻿param([switch]$Rescan)
Set-StrictMode -Version Latest
$ErrorActionPreference='Stop'
$root=[IO.Path]::GetFullPath($env:UNCANNY_PACKAGE_ROOT)
$script:launcherRuntimeRoot=Split-Path -Parent $MyInvocation.MyCommand.Path
$packageVersion=Get-Content -LiteralPath (Join-Path $root 'VERSION.json') -Raw|ConvertFrom-Json
$packageMetaPath=Join-Path $root 'PACKAGE-REVISION.json'
$packageMeta=if(Test-Path -LiteralPath $packageMetaPath){Get-Content -LiteralPath $packageMetaPath -Raw|ConvertFrom-Json}else{$null}
$packageRevision=if($packageMeta -and $packageMeta.revision){[string]$packageMeta.revision}else{[string]$packageVersion.revision}
$packageBuildId=if($packageMeta -and $packageMeta.PSObject.Properties['buildId'] -and $packageMeta.buildId){[string]$packageMeta.buildId}else{$packageRevision}
. (Join-Path (Split-Path -Parent $MyInvocation.MyCommand.Path) 'UNCANNY-Library.ps1')
Add-Type -AssemblyName PresentationFramework,PresentationCore,WindowsBase,System.Drawing
[xml]$x=@'
<Window xmlns="http://schemas.microsoft.com/winfx/2006/xaml/presentation"
        xmlns:x="http://schemas.microsoft.com/winfx/2006/xaml"
        Title="UNCANNY" Width="1180" Height="760" MinWidth="960" MinHeight="620"
        Background="#0A0C0F" Foreground="#F7F8FA" WindowStartupLocation="CenterScreen"
        FontFamily="Segoe UI" SnapsToDevicePixels="True" UseLayoutRounding="True">
  <Window.Resources>
    <Style x:Key="GhostButton" TargetType="Button">
      <Setter Property="Background" Value="#15191F"/><Setter Property="Foreground" Value="#EDEFF2"/>
      <Setter Property="BorderBrush" Value="#292F38"/><Setter Property="BorderThickness" Value="1"/>
      <Setter Property="Padding" Value="14,8"/><Setter Property="FontWeight" Value="SemiBold"/><Setter Property="Cursor" Value="Hand"/>
      <Setter Property="Template"><Setter.Value><ControlTemplate TargetType="Button"><Border x:Name="B" Background="{TemplateBinding Background}" BorderBrush="{TemplateBinding BorderBrush}" BorderThickness="{TemplateBinding BorderThickness}" CornerRadius="9"><ContentPresenter HorizontalAlignment="Center" VerticalAlignment="Center"/></Border><ControlTemplate.Triggers><Trigger Property="IsMouseOver" Value="True"><Setter TargetName="B" Property="Background" Value="#1D222A"/></Trigger><Trigger Property="IsEnabled" Value="False"><Setter TargetName="B" Property="Opacity" Value="0.42"/></Trigger></ControlTemplate.Triggers></ControlTemplate></Setter.Value></Setter>
    </Style>
    <Style x:Key="PrimaryButton" TargetType="Button" BasedOn="{StaticResource GhostButton}">
      <Setter Property="Background" Value="#F5F6F8"/><Setter Property="Foreground" Value="#0A0C0F"/><Setter Property="BorderBrush" Value="#F5F6F8"/>
      <Setter Property="FontSize" Value="14"/><Setter Property="Height" Value="46"/>
      <Style.Triggers><Trigger Property="IsMouseOver" Value="True"><Setter Property="Background" Value="#FFFFFF"/></Trigger></Style.Triggers>
    </Style>
    <Style TargetType="ListBoxItem">
      <Setter Property="HorizontalContentAlignment" Value="Stretch"/><Setter Property="Background" Value="Transparent"/><Setter Property="BorderThickness" Value="0"/><Setter Property="Padding" Value="0"/><Setter Property="Margin" Value="0"/><Setter Property="FocusVisualStyle" Value="{x:Null}"/>
      <Setter Property="Template"><Setter.Value><ControlTemplate TargetType="ListBoxItem"><ContentPresenter/></ControlTemplate></Setter.Value></Setter>
    </Style>
  </Window.Resources>
  <Grid Margin="28,24,28,22">
    <Grid.RowDefinitions><RowDefinition Height="Auto"/><RowDefinition Height="Auto"/><RowDefinition Height="*"/><RowDefinition Height="Auto"/></Grid.RowDefinitions>
    <Grid Grid.Row="0">
      <Grid.ColumnDefinitions><ColumnDefinition/><ColumnDefinition Width="Auto"/></Grid.ColumnDefinitions>
      <StackPanel Orientation="Horizontal" VerticalAlignment="Center">
        <Border Width="54" Height="54" Background="#0B0E12" BorderBrush="#2B313A" BorderThickness="1" CornerRadius="14" Margin="0,0,15,0" ClipToBounds="True" Padding="3">
          <Image Name="BrandLogo" Stretch="Uniform" RenderOptions.BitmapScalingMode="HighQuality"/>
        </Border>
        <StackPanel VerticalAlignment="Center">
          <StackPanel Orientation="Horizontal"><TextBlock Text="UNCANNY" FontSize="28" FontWeight="SemiBold"/><Border Background="#171B21" BorderBrush="#2A3038" BorderThickness="1" CornerRadius="7" Padding="8,3" Margin="12,4,0,0"><TextBlock Text="0.20 · ELYSIUM 4.5" Foreground="#AEB5C0" FontSize="11" FontWeight="SemiBold"/></Border></StackPanel>
          <TextBlock Text="Your games. ELYSIUM 4.5. Adaptive Realism. Install once. Launch normally." Foreground="#8E96A2" FontSize="13" Margin="0,3,0,0"/>
        </StackPanel>
      </StackPanel>
      <StackPanel Grid.Column="1" Orientation="Horizontal" VerticalAlignment="Center">
        <Button Name="PackageUpdate" Content="Updates" Width="118" Height="38" Padding="10,8" FontSize="11" Style="{StaticResource GhostButton}" Margin="0,0,8,0"/><Button Name="Logs" Content="Logs" Width="76" Height="38" Style="{StaticResource GhostButton}" Margin="0,0,8,0"/>
        <Button Name="Add" Content="Add game" Width="98" Height="38" Style="{StaticResource GhostButton}" Margin="0,0,10,0"/>
        <CheckBox Name="ScanOnStartup" Content="Scan on startup" IsChecked="True" Foreground="#AEB5C0" VerticalAlignment="Center" Margin="0,0,12,0" ToolTip="When off, UNCANNY opens from its cached/manual library and scans only when you press Scan PC."/>
        <Button Name="Rescan" Content="Scan PC" Width="96" Height="38" Style="{StaticResource GhostButton}"/>
      </StackPanel>
    </Grid>
    <Grid Grid.Row="1" Margin="0,22,0,16">
      <Grid.RowDefinitions><RowDefinition Height="Auto"/><RowDefinition Height="Auto"/></Grid.RowDefinitions>
      <Border Background="#12161B" BorderBrush="#292F38" BorderThickness="1" CornerRadius="11" Height="44">
        <Grid><Grid.ColumnDefinitions><ColumnDefinition Width="56"/><ColumnDefinition/></Grid.ColumnDefinitions><TextBlock Text="FIND" FontSize="10" FontWeight="SemiBold" Foreground="#77808D" HorizontalAlignment="Center" VerticalAlignment="Center"/><Grid Grid.Column="1"><TextBlock Name="SearchHint" Text="Search games and emulators" Foreground="#6F7884" FontSize="13" VerticalAlignment="Center" IsHitTestVisible="False"/><TextBox Name="Search" Background="Transparent" BorderThickness="0" Foreground="#F5F7FA" CaretBrush="White" FontSize="14" Padding="0,10,12,8" ToolTip="Search games and emulators"/></Grid></Grid>
      </Border>
      <Border Name="WorkPanel" Grid.Row="1" Margin="0,10,0,0" Background="#101319" BorderBrush="#232933" BorderThickness="1" CornerRadius="8" Padding="12,8" Visibility="Collapsed">
        <Grid><Grid.ColumnDefinitions><ColumnDefinition/><ColumnDefinition Width="180"/></Grid.ColumnDefinitions><TextBlock Name="WorkText" Text="Working..." Foreground="#BCC3CD" FontSize="12"/><Border Grid.Column="1" Name="WorkTrack" Height="6" Background="#1C222A" CornerRadius="3" VerticalAlignment="Center" ClipToBounds="True"><Border Name="WorkFill" Height="6" Width="0" HorizontalAlignment="Left" Background="#F5F7FA" CornerRadius="3"/></Border></Grid>
      </Border>
    </Grid>
    <Grid Grid.Row="2">
      <Grid.ColumnDefinitions><ColumnDefinition Width="1.7*"/><ColumnDefinition Width="18"/><ColumnDefinition Width="0.9*"/></Grid.ColumnDefinitions>
      <Border Background="#0E1116" BorderBrush="#222832" BorderThickness="1" CornerRadius="14" Padding="8">
        <Grid>
          <ListBox Name="Games" Background="Transparent" BorderThickness="0" ScrollViewer.HorizontalScrollBarVisibility="Disabled" ScrollViewer.VerticalScrollBarVisibility="Auto">
            <ListBox.ItemTemplate>
              <DataTemplate>
                <Border x:Name="Card" Background="#12161B" BorderBrush="#202630" BorderThickness="1" CornerRadius="12" Margin="4,4,4,7" Padding="12">
                  <Grid>
                    <Grid.ColumnDefinitions><ColumnDefinition Width="92"/><ColumnDefinition Width="*"/><ColumnDefinition Width="Auto"/></Grid.ColumnDefinitions>
                    <Border Width="78" Height="78" CornerRadius="12" Background="#191E25" BorderBrush="#2A313B" BorderThickness="1" VerticalAlignment="Center">
                      <Grid ClipToBounds="True"><TextBlock Text="{Binding Initial}" FontSize="27" FontWeight="SemiBold" Foreground="#69727E" HorizontalAlignment="Center" VerticalAlignment="Center"/><Image Source="{Binding Cover}" Stretch="Uniform" Margin="5" RenderOptions.BitmapScalingMode="HighQuality"/></Grid>
                    </Border>
                    <StackPanel Grid.Column="1" VerticalAlignment="Center" Margin="0,0,12,0">
                      <TextBlock Text="{Binding Name}" Foreground="#F4F6F8" FontSize="17" FontWeight="SemiBold" TextTrimming="CharacterEllipsis"/>
                      <StackPanel Orientation="Horizontal" Margin="0,6,0,0"><Border Background="#1A1F26" CornerRadius="6" Padding="7,3" Margin="0,0,8,0"><StackPanel Orientation="Horizontal"><TextBlock Text="{Binding Source}" Foreground="#A6AEB9" FontSize="10" FontWeight="SemiBold"/><TextBlock Text="  /  " Foreground="#59626E" FontSize="10"/><TextBlock Text="{Binding Kind}" Foreground="#89929E" FontSize="10" FontWeight="SemiBold"/></StackPanel></Border><TextBlock Text="{Binding FileName}" Foreground="#777F8C" FontSize="11" VerticalAlignment="Center" TextTrimming="CharacterEllipsis"/></StackPanel>
                    </StackPanel>
                    <Border Grid.Column="2" Background="{Binding StateBackground}" CornerRadius="8" Padding="9,4" VerticalAlignment="Center"><TextBlock Text="{Binding State}" Foreground="{Binding StateBrush}" FontSize="10" FontWeight="SemiBold"/></Border>
                  </Grid>
                </Border>
                <DataTemplate.Triggers><DataTrigger Binding="{Binding RelativeSource={RelativeSource AncestorType=ListBoxItem},Path=IsSelected}" Value="True"><Setter TargetName="Card" Property="Background" Value="#191E24"/><Setter TargetName="Card" Property="BorderBrush" Value="#E9EDF2"/></DataTrigger></DataTemplate.Triggers>
              </DataTemplate>
            </ListBox.ItemTemplate>
          </ListBox>
          <StackPanel Name="EmptyState" HorizontalAlignment="Center" VerticalAlignment="Center" Visibility="Collapsed"><TextBlock Text="No games found yet" FontSize="19" FontWeight="SemiBold" HorizontalAlignment="Center"/><TextBlock Text="Scans Steam, Epic, GOG, registered games, known emulators and real game folders - not every EXE." Foreground="#7E8793" Margin="0,7,0,0" HorizontalAlignment="Center"/></StackPanel>
        </Grid>
      </Border>
      <Border Grid.Column="2" Background="#101319" BorderBrush="#242A33" BorderThickness="1" CornerRadius="14" Padding="20">
        <Grid><Grid.RowDefinitions><RowDefinition Height="Auto"/><RowDefinition Height="Auto"/><RowDefinition Height="*"/><RowDefinition Height="Auto"/></Grid.RowDefinitions>
          <Border Width="126" Height="126" CornerRadius="20" Background="#171C22" BorderBrush="#2A313B" BorderThickness="1" HorizontalAlignment="Left"><Grid ClipToBounds="True"><TextBlock Text="{Binding SelectedItem.Initial,ElementName=Games}" FontSize="42" Foreground="#59636F" FontWeight="SemiBold" HorizontalAlignment="Center" VerticalAlignment="Center"/><Image Source="{Binding SelectedItem.Cover,ElementName=Games}" Stretch="Uniform" Margin="9" RenderOptions.BitmapScalingMode="HighQuality"/></Grid></Border>
          <StackPanel Grid.Row="1" Margin="0,18,0,0"><TextBlock Text="{Binding SelectedItem.Name,ElementName=Games}" Foreground="#F7F8FA" FontSize="22" FontWeight="SemiBold" TextWrapping="Wrap"/><StackPanel Orientation="Horizontal" Margin="0,5,0,0"><TextBlock Text="{Binding SelectedItem.Source,ElementName=Games}" Foreground="#9AA2AE" FontSize="12"/><TextBlock Text="  /  " Foreground="#59626E" FontSize="12"/><TextBlock Text="{Binding SelectedItem.Kind,ElementName=Games}" Foreground="#9AA2AE" FontSize="12"/></StackPanel><TextBlock Text="{Binding SelectedItem.Exe,ElementName=Games}" Foreground="#656E7A" FontSize="10" Margin="0,9,0,0" TextWrapping="Wrap"/></StackPanel>
          <StackPanel Grid.Row="2" Margin="0,20,0,0">
            <Border Background="#151A20" CornerRadius="10" Padding="12"><Grid><Grid.ColumnDefinitions><ColumnDefinition/><ColumnDefinition Width="Auto"/></Grid.ColumnDefinitions><TextBlock Text="UNCANNY" Foreground="#A8B0BB"/><TextBlock Grid.Column="1" Name="DetailState" Text="Select a game" Foreground="#F4F6F8" FontWeight="SemiBold"/></Grid></Border>
            <Border Name="RevenantPanel" Background="#151A20" CornerRadius="10" Padding="12" Margin="0,9,0,0" Visibility="Collapsed"><StackPanel><Grid><Grid.ColumnDefinitions><ColumnDefinition/><ColumnDefinition Width="Auto"/></Grid.ColumnDefinitions><TextBlock Text="REVENANT / PCSX2" Foreground="#A8B0BB"/><TextBlock Grid.Column="1" Name="RevenantState" Text="Needs live proof" Foreground="#F4F6F8" FontWeight="SemiBold"/></Grid><TextBlock Text="Live proof tracks capture > neural rebuild > replacement > reload > visible sampling > restore. File creation alone never counts as proof." Foreground="#6F7885" FontSize="10" TextWrapping="Wrap" Margin="0,8,0,0"/></StackPanel></Border>
          </StackPanel>
          <StackPanel Grid.Row="3" Margin="0,18,0,0">
            <Button Name="Primary" Content="Select a game" Style="{StaticResource PrimaryButton}" IsEnabled="False"/>
            <Button Name="Proof" Content="Verify REVENANT" Style="{StaticResource GhostButton}" Height="40" Margin="0,8,0,0" Visibility="Collapsed"/>
            <Grid Margin="0,8,0,0"><Grid.ColumnDefinitions><ColumnDefinition/><ColumnDefinition Width="8"/><ColumnDefinition/></Grid.ColumnDefinitions><Button Name="Repair" Content="Repair" Style="{StaticResource GhostButton}" Height="38" Visibility="Collapsed"/><Button Grid.Column="2" Name="Remove" Content="Remove" Style="{StaticResource GhostButton}" Height="38" Visibility="Collapsed"/></Grid>
          </StackPanel>
        </Grid>
      </Border>
    </Grid>
    <Border Grid.Row="3" BorderBrush="#202630" BorderThickness="0,1,0,0" Padding="0,14,0,0" Margin="0,14,0,0">
      <Grid><Grid.ColumnDefinitions><ColumnDefinition/><ColumnDefinition Width="Auto"/></Grid.ColumnDefinitions><StackPanel><TextBlock Name="StatusText" Text="Opening UNCANNY..." FontSize="12" Foreground="#C3C9D1"/><TextBlock Name="CountText" Text="" FontSize="10" Foreground="#707987" Margin="0,3,0,0"/></StackPanel><TextBlock Grid.Column="1" Text="Game-only library / verified installs / live logs" Foreground="#626B77" FontSize="10" VerticalAlignment="Center"/></Grid>
    </Border>
  </Grid>
</Window>
'@
$r=New-Object Xml.XmlNodeReader $x;$w=[Windows.Markup.XamlReader]::Load($r)
$g=$w.FindName('Games');$search=$w.FindName('Search');$searchHint=$w.FindName('SearchHint');$packageUpdate=$w.FindName('PackageUpdate');$primary=$w.FindName('Primary');$remove=$w.FindName('Remove');$repair=$w.FindName('Repair');$proof=$w.FindName('Proof');$status=$w.FindName('StatusText');$count=$w.FindName('CountText');$empty=$w.FindName('EmptyState');$add=$w.FindName('Add');$logs=$w.FindName('Logs');$rescanButton=$w.FindName('Rescan');$scanOnStartupCheck=$w.FindName('ScanOnStartup');$workPanel=$w.FindName('WorkPanel');$workText=$w.FindName('WorkText');$workTrack=$w.FindName('WorkTrack');$workFill=$w.FindName('WorkFill');$detailState=$w.FindName('DetailState');$revenantPanel=$w.FindName('RevenantPanel');$revenantState=$w.FindName('RevenantState');$brandLogo=$w.FindName('BrandLogo')
$script:all=@();$script:busy=$false;$script:initialScanDone=$false;$script:updateInfo=$null;$script:updateCheckProcess=$null;$script:updateResultFile='';$script:operationProgressFloor=0;$script:lastProgress=0;$script:scanProcess=$null;$script:scanTimer=$null;$script:scanResult='';$script:scanProgress='';$script:scanSelect=''
$logDir=Join-Path $env:LOCALAPPDATA 'UNCANNY\logs';New-Item -ItemType Directory -Force -Path $logDir|Out-Null
$sessionLog=Join-Path $logDir ('launcher-'+(Get-Date -Format 'yyyyMMdd')+'.log')
$launcherSettingsPath=Join-Path $env:LOCALAPPDATA 'UNCANNY\launcher-settings.json'
function Get-LauncherScanOnStartup{
  try{if(Test-Path -LiteralPath $launcherSettingsPath -PathType Leaf){$j=Get-Content -LiteralPath $launcherSettingsPath -Raw|ConvertFrom-Json;if($j.PSObject.Properties['scanOnStartup']){return [bool]$j.scanOnStartup}}}catch{}
  return $true
}
function Save-LauncherSettings{
  try{$payload=[ordered]@{format='UNCANNY-LAUNCHER-SETTINGS-1';scanOnStartup=[bool]$script:scanOnStartup};Write-UncannyJsonAtomic $launcherSettingsPath ($payload|ConvertTo-Json -Depth 3)}catch{Write-LauncherLog ('SETTINGS SAVE ERROR '+$_.Exception.Message)}
}
$script:scanOnStartup=Get-LauncherScanOnStartup
$scanOnStartupCheck.IsChecked=$script:scanOnStartup
function Write-LauncherLog([string]$Message){try{Add-Content -LiteralPath $sessionLog -Encoding UTF8 -Value ('['+(Get-Date -Format 'HH:mm:ss.fff')+'] '+$Message)}catch{}}
function Get-LauncherErrorDetail($Record){if($null -eq $Record){return ''};$parts=@();try{$parts+=$Record.Exception.ToString()}catch{};try{if($Record.ScriptStackTrace){$parts+=('STACK '+$Record.ScriptStackTrace)}}catch{};try{if($Record.InvocationInfo -and $Record.InvocationInfo.PositionMessage){$parts+=('AT '+$Record.InvocationInfo.PositionMessage)}}catch{};return ($parts -join "`n")}
function Set-LauncherBrandLogo{
  if($null -eq $brandLogo){return}
  $logoPath=Join-Path $root 'assets\UNCANNY-ELYSIUM-logo-launcher.png'
  if(!(Test-Path -LiteralPath $logoPath -PathType Leaf)){Write-LauncherLog ('BRAND LOGO MISSING '+$logoPath);return}
  $stream=$null
  try{
    $stream=[IO.File]::Open($logoPath,[IO.FileMode]::Open,[IO.FileAccess]::Read,[IO.FileShare]::Read)
    $bmp=New-Object Windows.Media.Imaging.BitmapImage
    $bmp.BeginInit()
    $bmp.CacheOption=[Windows.Media.Imaging.BitmapCacheOption]::OnLoad
    $bmp.StreamSource=$stream
    $bmp.EndInit()
    $bmp.Freeze()
    $brandLogo.Source=$bmp
    Write-LauncherLog ('BRAND LOGO OK '+$bmp.PixelWidth+'x'+$bmp.PixelHeight+' direct')
    return
  }catch{
    Write-LauncherLog ('BRAND LOGO DIRECT FALLBACK '+(Get-LauncherErrorDetail $_))
  }finally{if($stream){$stream.Dispose()}}
  $sourceImage=$null;$rgba=$null;$graphics=$null;$encoded=$null
  try{
    $sourceImage=[Drawing.Image]::FromFile($logoPath)
    $rgba=New-Object Drawing.Bitmap($sourceImage.Width,$sourceImage.Height,[Drawing.Imaging.PixelFormat]::Format32bppArgb)
    $graphics=[Drawing.Graphics]::FromImage($rgba)
    $graphics.CompositingMode=[Drawing.Drawing2D.CompositingMode]::SourceCopy
    $graphics.DrawImage($sourceImage,0,0,$sourceImage.Width,$sourceImage.Height)
    $encoded=New-Object IO.MemoryStream
    $rgba.Save($encoded,[Drawing.Imaging.ImageFormat]::Png)
    $encoded.Position=0
    $bmp=New-Object Windows.Media.Imaging.BitmapImage
    $bmp.BeginInit();$bmp.CacheOption=[Windows.Media.Imaging.BitmapCacheOption]::OnLoad;$bmp.StreamSource=$encoded;$bmp.EndInit();$bmp.Freeze()
    $brandLogo.Source=$bmp
    Write-LauncherLog ('BRAND LOGO OK '+$bmp.PixelWidth+'x'+$bmp.PixelHeight+' rgba32-fallback')
  }catch{Write-LauncherLog ('BRAND LOGO LOAD ERROR '+(Get-LauncherErrorDetail $_))}
  finally{
    if($graphics){$graphics.Dispose()}
    if($rgba){$rgba.Dispose()}
    if($sourceImage){$sourceImage.Dispose()}
    if($encoded){$encoded.Dispose()}
  }
}
Set-LauncherBrandLogo
function Pump-UI{try{$w.Dispatcher.Invoke([Action]{},[Windows.Threading.DispatcherPriority]::Background)}catch{}}
function Set-LauncherBusy([bool]$isBusy,[string]$message='',[bool]$indeterminate=$true){
  $script:busy=$isBusy;$add.IsEnabled=!$isBusy;$rescanButton.IsEnabled=!$isBusy;$remove.IsEnabled=!$isBusy;$repair.IsEnabled=!$isBusy;$proof.IsEnabled=!$isBusy
  if($message){$status.Text=$message;$workText.Text=$message};$workPanel.Visibility=if($isBusy){'Visible'}else{'Collapsed'};if(!$isBusy){$script:lastProgress=0;$script:operationProgressFloor=0;if($workFill){$workFill.Width=0}};if($isBusy){$w.Cursor=[Windows.Input.Cursors]::Wait}else{$w.Cursor=[Windows.Input.Cursors]::Arrow};Pump-UI
}
function Set-WorkProgress([string]$Stage,[int]$Percent){
  $p=[Math]::Max(0,[Math]::Min(100,$Percent));if($p -lt $script:operationProgressFloor){$p=$script:operationProgressFloor}else{$script:operationProgressFloor=$p}
  $script:lastProgress=$p;$workPanel.Visibility='Visible';$workText.Text=($Stage+'  '+$p.ToString()+'%');$status.Text=$Stage;if($workTrack -and $workFill){$track=[Math]::Max(0.0,[double]$workTrack.ActualWidth);if($track -le 1){$track=180};$workFill.Width=$track*($p/100.0)};Pump-UI
}
function Quote-ProcessArgument([string]$value){if($null -eq $value){return '""'};return '"'+($value -replace '"','\"')+'"'}
function Invoke-UncannyScript([string]$scriptName,[string[]]$argumentList){
  $scriptPath=Join-Path $script:launcherRuntimeRoot $scriptName;if(!(Test-Path -LiteralPath $scriptPath)){$scriptPath=Join-Path $root $scriptName};if(!(Test-Path -LiteralPath $scriptPath)){throw "Missing required file: $scriptName"};Write-LauncherLog ("RUN $scriptName "+($argumentList -join ' '))
  $psi=New-Object Diagnostics.ProcessStartInfo;$psi.FileName='powershell.exe';$psi.WorkingDirectory=$root;$psi.UseShellExecute=$false;$psi.CreateNoWindow=$true;$psi.RedirectStandardOutput=$true;$psi.RedirectStandardError=$true;$psi.Arguments='-NoLogo -NoProfile -NonInteractive -ExecutionPolicy Bypass -File '+(Quote-ProcessArgument $scriptPath)+' '+($argumentList -join ' ')
  $p=New-Object Diagnostics.Process;$p.StartInfo=$psi;[void]$p.Start();$stdout=$p.StandardOutput.ReadToEnd();$stderr=$p.StandardError.ReadToEnd();$p.WaitForExit();Write-LauncherLog ("EXIT $($p.ExitCode) $scriptName`n$stdout`n$stderr")
  return [pscustomobject]@{ExitCode=$p.ExitCode;StdOut=$stdout;StdErr=$stderr}
}
function Get-LauncherObjectValue($Object,[string]$Name,$Default=$null){
  if($null -eq $Object){return $Default}
  try{
    $p=$Object.PSObject.Properties[$Name]
    if($null -ne $p){return $p.Value}
  }catch{}
  return $Default
}
function Set-LauncherObjectValue($Object,[string]$Name,$Value){
  if($null -eq $Object){return}
  $property=$Object.PSObject.Properties[$Name]
  if($null -eq $property){$Object|Add-Member -NotePropertyName $Name -NotePropertyValue $Value -Force}
  else{$property.Value=$Value}
}
function Resolve-LauncherExistingFilePath([string]$Path){
  if(!$Path){return ''}
  try{
    $full=[IO.Path]::GetFullPath($Path)
    if(!(Test-Path -LiteralPath $full -PathType Leaf)){return ''}
    $item=Get-Item -LiteralPath $full -Force -ErrorAction Stop
    $resolved=[string](Get-LauncherObjectValue $item 'FullName' $full)
    if(!$resolved){return ''}
    return [IO.Path]::GetFullPath($resolved)
  }catch{return ''}
}
function Normalize-LauncherGameRecord($Object){
  if($null -eq $Object){return $Object}
  foreach($pair in @(
    @('Name',''),@('Exe',''),@('Directory',''),@('Cover',''),@('Installed',$false),
    @('InstalledRevision',''),@('InstalledBuildId',''),@('NeedsUpdate',$false),
    @('Source','Added'),@('Kind','Game'),@('EmulatorFamily',''),@('FileName',''),
    @('State','NOT INSTALLED'),@('StateBrush','#A7AFBA'),@('StateBackground','#20252D'),
    @('Initial','U'),@('IsPCSX2',$false),@('DuplicateInstallCount',1)
  )){if($null -eq $Object.PSObject.Properties[[string]$pair[0]]){$Object|Add-Member -NotePropertyName ([string]$pair[0]) -NotePropertyValue $pair[1] -Force}}
  return $Object
}
function Get-SelectedGame{return $g.SelectedItem}
function Get-LatestRevenantProofState([string]$dir){
  try{
    $f=Get-ChildItem -LiteralPath $dir -Filter 'UNCANNY-REVENANT-STATUS-*.txt' -File -ErrorAction SilentlyContinue|Sort-Object LastWriteTime -Descending|Select-Object -First 1
    if(!$f){return 'Waiting for live session'};$raw=Get-Content -LiteralPath $f.FullName -Raw
    if($raw -match '(?m)^RenderedUse=(USER_CONFIRMED|VERIFIED|CERTIFIED)' -or $raw -match '(?m)^VisibleRenderedUse=(USER_CONFIRMED|VERIFIED|CERTIFIED)' -or $raw -match '(?m)^AssetUserConfirmed=1$'){return 'VISIBLE USE VERIFIED'}
    $neural=0;$ready=0;$queue=0;$processed=0;$total=0
    if($raw -match '(?m)^NeuralSuccess=([0-9]+)$'){$neural=[int64]$Matches[1]}
    if($raw -match '(?m)^ReplacementReady=([0-9]+)$'){$ready=[int64]$Matches[1]}
    if($raw -match '(?m)^QueueDepth=([0-9]+)$'){$queue=[int64]$Matches[1]}
    if($raw -match '(?m)^RebuildProcessed=([0-9]+)$'){$processed=[int64]$Matches[1]}
    if($raw -match '(?m)^RebuildTotal=([0-9]+)$'){$total=[int64]$Matches[1]}
    if($total -gt 0 -and $processed -lt $total){return "Rebuilding $processed / $total"}
    if($neural -gt 0 -or $ready -gt 0){return "$ready ready / $neural neural / $queue queued"}
    if($raw -match '(?m)^RevenantWorkerStatus=Connected'){return 'Worker connected / waiting for captures'}
  }catch{}
  return 'Waiting for live proof'
}
function Update-Actions{
  $s=Get-SelectedGame
  if($null -eq $s){$primary.Content='Select a game';$primary.IsEnabled=$false;$remove.Visibility='Collapsed';$repair.Visibility='Collapsed';$proof.Visibility='Collapsed';$revenantPanel.Visibility='Collapsed';$detailState.Text='Select a game';if(!$script:busy){$status.Text='Choose a game to continue.'};return}
  $detailState.Text=if($s.NeedsUpdate){'Update available'}elseif($s.Installed){'Installed'}else{'Not installed'}
  if($s.IsPCSX2){$revenantPanel.Visibility='Visible';$revenantState.Text=Get-LatestRevenantProofState $s.Directory}else{$revenantPanel.Visibility='Collapsed'}
  if($s.NeedsUpdate){$primary.Content='Update UNCANNY';$remove.Visibility='Visible';$repair.Visibility='Visible';$proof.Visibility=if($s.IsPCSX2){'Visible'}else{'Collapsed'};if(!$script:busy){$status.Text='New UNCANNY runtime/profile available for '+$s.Name+'.'}}
  elseif($s.Installed){$primary.Content='Launch Game';$remove.Visibility='Visible';$repair.Visibility='Visible';$proof.Visibility=if($s.IsPCSX2){'Visible'}else{'Collapsed'};if(!$script:busy){$status.Text='Ready to launch '+$s.Name+'.'}}
  else{$primary.Content='Install UNCANNY';$remove.Visibility='Collapsed';$repair.Visibility='Collapsed';$proof.Visibility='Collapsed';if(!$script:busy){$status.Text='Ready to install UNCANNY for '+$s.Name+'.'}}
  $primary.IsEnabled=!$script:busy
}
function Filter-List{
  $q=$search.Text.Trim();if($q){$items=@($script:all|Where-Object{$_.Name -like "*$q*" -or $_.Source -like "*$q*" -or $_.Kind -like "*$q*" -or $_.FileName -like "*$q*" -or $_.EmulatorFamily -like "*$q*"})}else{$items=@($script:all)};$g.ItemsSource=$items;$empty.Visibility=if($items.Count -eq 0){'Visible'}else{'Collapsed'};$gameCount=@($script:all|Where-Object{$_.Kind -eq 'Game'}).Count;$emuCount=@($script:all|Where-Object{$_.Kind -eq 'Emulator'}).Count;$count.Text="$gameCount games / $emuCount emulators";if($items.Count -gt 0 -and $null -eq $g.SelectedItem){$g.SelectedIndex=0};Update-Actions
}
function Load-CachedLibraryFast{
  $cache=Join-Path $env:LOCALAPPDATA 'UNCANNY\library-cache.json'
  $custom=Join-Path $env:LOCALAPPDATA 'UNCANNY\library.json'
  try{
    $raw=@()
    if(Test-Path -LiteralPath $cache -PathType Leaf){$raw=@(Get-Content -LiteralPath $cache -Raw|ConvertFrom-Json)}
    if(Test-Path -LiteralPath $custom -PathType Leaf){
      foreach($m in @(Get-Content -LiteralPath $custom -Raw|ConvertFrom-Json)){
        $manualExe=Get-UncannyLibraryEntryExe $m
        if(!$manualExe -or !(Test-Path -LiteralPath $manualExe -PathType Leaf)){continue}
        $full=Resolve-LauncherExistingFilePath $manualExe;if(!$full){continue}
        if(@($raw|Where-Object{(Get-UncannyLibraryEntryExe $_) -and ((Get-UncannyLibraryEntryExe $_) -ieq $full)}).Count){continue}
        $fam=Get-UncannyEmulatorIdentity $full;$manualName=Get-UncannyLibraryEntryName $m;$fallback=if($manualName){$manualName}else{[IO.Path]::GetFileNameWithoutExtension($full)}
        $raw+= [pscustomobject]@{Name=(Get-UncannyFriendlyName $full $fallback);Exe=$full;Cover=(Get-UncannyExeCover $full);Source='Added';Kind=$(if($fam){'Emulator'}else{'Game'});EmulatorFamily=$fam}
      }
    }
    $valid=@($raw|ForEach-Object{
      $entryExe=Get-UncannyLibraryEntryExe $_
      if(!$entryExe -or !(Test-Path -LiteralPath $entryExe -PathType Leaf)){return}
      try{
        $resolved=Resolve-LauncherExistingFilePath $entryExe;if(!$resolved){return}
        $entryName=Get-UncannyLibraryEntryName $_ ([IO.Path]::GetFileNameWithoutExtension($resolved))
        [pscustomobject]@{
          Name=$entryName
          Exe=$resolved
          Cover=[string](Get-LauncherObjectValue $_ 'Cover' '')
          Source=[string](Get-LauncherObjectValue $_ 'Source' 'Added')
          Kind=[string](Get-LauncherObjectValue $_ 'Kind' '')
          EmulatorFamily=[string](Get-LauncherObjectValue $_ 'EmulatorFamily' '')
        }
      }catch{}
    })
    if(!$valid.Count){$script:all=@();Filter-List;return $false}
    $canonical=[Collections.Generic.List[object]]::new()
    foreach($record in @($valid)){
      $exe=[string](Get-LauncherObjectValue $record 'Exe' '')
      if(!$exe){continue}
      $name=[string](Get-LauncherObjectValue $record 'Name' ([IO.Path]::GetFileNameWithoutExtension($exe)))
      $cover=[string](Get-LauncherObjectValue $record 'Cover' '')
      $source=[string](Get-LauncherObjectValue $record 'Source' 'Added')
      $kind=[string](Get-LauncherObjectValue $record 'Kind' '')
      $fam=[string](Get-LauncherObjectValue $record 'EmulatorFamily' '')
      if(!$fam){$fam=Get-UncannyEmulatorIdentity $exe}
      if(!$kind){$kind=if($fam){'Emulator'}else{'Game'}}
      $installed=Test-UncannyInstalled $exe;$rev=Get-UncannyInstallRevision $exe;$needs=Test-UncannyInstallNeedsUpdate $exe $packageRevision $packageBuildId;$isPCSX2=Test-UncannyPCSX2Exe $exe
      $canonical.Add((Normalize-LauncherGameRecord ([pscustomobject]@{Name=$name;Exe=$exe;Directory=(Split-Path $exe -Parent);Cover=$cover;Installed=$installed;InstalledRevision=$rev;InstalledBuildId=(Get-UncannyInstallBuildId $exe);NeedsUpdate=$needs;Source=$source;Kind=$kind;EmulatorFamily=$fam;FileName=[IO.Path]::GetFileName($exe);State=$(if($needs){'UPDATE'}elseif($installed){'INSTALLED'}else{'NOT INSTALLED'});StateBrush=$(if($needs){'#FFE29A'}elseif($installed){'#C9F7B1'}else{'#A7AFBA'});StateBackground=$(if($needs){'#302716'}elseif($installed){'#1A2D1C'}else{'#20252D'});Initial=$(if($name){$name.Substring(0,1).ToUpperInvariant()}else{'U'});IsPCSX2=$isPCSX2})))
    }
    $script:all=@($canonical)
    Filter-List
    Write-LauncherLog ('CACHE LOAD COMPLETE count='+$script:all.Count)
    $status.Text=if($script:scanOnStartup){'Library loaded. Startup scan is enabled.'}else{'Library loaded from cache/manual entries. Startup scan is off.'}
    $count.Text=($script:all.Count.ToString()+' cached/manual titles')
    return $true
  }catch{Write-LauncherLog ('CACHE LOAD ERROR '+(Get-LauncherErrorDetail $_));return $false}
}
function Refresh-OneGameState([string]$exe){
  $item=@($script:all|Where-Object{$_.Exe -ieq $exe}|Select-Object -First 1)
  if(!$item.Count){return $false}
  $selectedExe=if($g.SelectedItem){$g.SelectedItem.Exe}else{$exe}
  $installed=Test-UncannyInstalled $exe;$rev=Get-UncannyInstallRevision $exe;$needs=Test-UncannyInstallNeedsUpdate $exe $packageRevision $packageBuildId
  $record=Normalize-LauncherGameRecord $item[0]
  Set-LauncherObjectValue $record 'Installed' $installed
  Set-LauncherObjectValue $record 'InstalledRevision' $rev
  Set-LauncherObjectValue $record 'InstalledBuildId' (Get-UncannyInstallBuildId $exe)
  Set-LauncherObjectValue $record 'NeedsUpdate' $needs
  Set-LauncherObjectValue $record 'State' $(if($needs){'UPDATE'}elseif($installed){'INSTALLED'}else{'NOT INSTALLED'})
  Set-LauncherObjectValue $record 'StateBrush' $(if($needs){'#FFE29A'}elseif($installed){'#C9F7B1'}else{'#A7AFBA'})
  Set-LauncherObjectValue $record 'StateBackground' $(if($needs){'#302716'}elseif($installed){'#1A2D1C'}else{'#20252D'})
  Filter-List;$match=@($g.ItemsSource|Where-Object{$_.Exe -ieq $selectedExe}|Select-Object -First 1);if($match.Count){$g.SelectedItem=$match[0];$g.ScrollIntoView($match[0])}
  return $true
}
function Read-ProgressFile([string]$path,[string]$fallback){
  try{if(Test-Path -LiteralPath $path){$raw=(Get-Content -LiteralPath $path -Raw).Trim();if($raw -match '^([0-9]{1,3})\|(.*)$'){Set-WorkProgress $Matches[2] ([int]$Matches[1]);return}}}catch{}
  if($fallback){Set-WorkProgress $fallback ([int]$script:lastProgress)}
}
function Invoke-UncannyInstall($s,[string]$verb='Installing'){
  $scriptPath=Join-Path $script:launcherRuntimeRoot 'INSTALL-NATIVE.ps1';$progressFile=Join-Path $env:TEMP ('uncanny-install-'+[guid]::NewGuid().ToString('N')+'.progress');Remove-Item -LiteralPath $progressFile -Force -ErrorAction SilentlyContinue
  $args=@('-Target',(Quote-ProcessArgument $s.Exe),'-ProgressFile',(Quote-ProcessArgument $progressFile));if(Test-Path -LiteralPath (Join-Path $root 'public-build.json')){$args+=@('-SkipBuild')}
  Write-LauncherLog ("RUN INSTALL-NATIVE.ps1 "+($args -join ' '));$psi=New-Object Diagnostics.ProcessStartInfo;$psi.FileName='powershell.exe';$psi.WorkingDirectory=$root;$psi.UseShellExecute=$false;$psi.CreateNoWindow=$true;$psi.RedirectStandardOutput=$true;$psi.RedirectStandardError=$true;$psi.Arguments='-NoLogo -NoProfile -NonInteractive -ExecutionPolicy Bypass -File '+(Quote-ProcessArgument $scriptPath)+' '+($args -join ' ')
  $p=New-Object Diagnostics.Process;$p.StartInfo=$psi;[void]$p.Start();$outTask=$p.StandardOutput.ReadToEndAsync();$errTask=$p.StandardError.ReadToEndAsync()
  while(!$p.WaitForExit(80)){Read-ProgressFile $progressFile ($verb+' UNCANNY for '+$s.Name);Pump-UI}
  $p.WaitForExit();Read-ProgressFile $progressFile 'Finalizing installation';$stdout=$outTask.Result;$stderr=$errTask.Result;Remove-Item -LiteralPath $progressFile -Force -ErrorAction SilentlyContinue;Write-LauncherLog ("EXIT $($p.ExitCode) INSTALL-NATIVE.ps1`n$stdout`n$stderr");return [pscustomobject]@{ExitCode=$p.ExitCode;StdOut=$stdout;StdErr=$stderr}
}
function Start-PackageUpdateCheck{
  if($script:updateCheckProcess -and !$script:updateCheckProcess.HasExited){return}
  $script:updateResultFile=Join-Path $env:TEMP ('uncanny-update-'+[guid]::NewGuid().ToString('N')+'.json');$updater=Join-Path $script:launcherRuntimeRoot 'UNCANNY-UPDATER.ps1';if(!(Test-Path -LiteralPath $updater)){return}
  try{$psi=New-Object Diagnostics.ProcessStartInfo;$psi.FileName='powershell.exe';$psi.WorkingDirectory=$root;$psi.UseShellExecute=$false;$psi.CreateNoWindow=$true;$psi.Arguments='-NoLogo -NoProfile -NonInteractive -ExecutionPolicy Bypass -File '+(Quote-ProcessArgument $updater)+' -Mode Check -ResultFile '+(Quote-ProcessArgument $script:updateResultFile);$p=New-Object Diagnostics.Process;$p.StartInfo=$psi;[void]$p.Start();$script:updateCheckProcess=$p;$packageUpdate.Content='Checking…';$packageUpdate.IsEnabled=$false}catch{Write-LauncherLog ('UPDATE CHECK START ERROR '+$_.Exception.Message)}
}
function Finish-PackageUpdateCheck{
  if(!$script:updateCheckProcess -or !$script:updateCheckProcess.HasExited){return}
  try{if(Test-Path -LiteralPath $script:updateResultFile){$info=Get-Content -LiteralPath $script:updateResultFile -Raw|ConvertFrom-Json;$script:updateInfo=$info;if($info.available){$packageUpdate.Content='Update ready';$packageUpdate.ToolTip=([string]$info.tag+' - click to install')}else{$packageUpdate.Content='Up to date';$packageUpdate.ToolTip='No newer verified public release exists. Tester/development builds may be ahead of the published channel.'}}else{$packageUpdate.Content='Updates';$packageUpdate.ToolTip='Update check did not return a result.'}}catch{$packageUpdate.Content='Updates';Write-LauncherLog ('UPDATE CHECK ERROR '+$_.Exception.Message)}finally{$packageUpdate.IsEnabled=$true;$script:updateCheckProcess=$null}
}
function Install-PackageUpdate{
  if(!$script:updateInfo){Start-PackageUpdateCheck;return}
  if(!$script:updateInfo.available){
    [Windows.MessageBox]::Show("No newer verified public UNCANNY release is available right now.`n`nTester/development builds can be ahead of the newest published release; in that case there is nothing safe for the updater to install yet.",'UNCANNY Updates','OK','Information')|Out-Null
    Start-PackageUpdateCheck
    return
  }
  if([Windows.MessageBox]::Show(('Install official UNCANNY update '+[string]$script:updateInfo.tag+'?`n`nThe current package will stay untouched. The verified new package is installed side-by-side and launched.'),'UNCANNY','YesNo','Question') -ne 'Yes'){return}
  $updater=Join-Path $script:launcherRuntimeRoot 'UNCANNY-UPDATER.ps1';$result=Join-Path $env:TEMP ('uncanny-update-install-'+[guid]::NewGuid().ToString('N')+'.json');$progress=Join-Path $env:TEMP ('uncanny-update-install-'+[guid]::NewGuid().ToString('N')+'.progress')
  Set-LauncherBusy $true 'Installing official UNCANNY update...' $false;$script:operationProgressFloor=0
  try{$psi=New-Object Diagnostics.ProcessStartInfo;$psi.FileName='powershell.exe';$psi.WorkingDirectory=$root;$psi.UseShellExecute=$false;$psi.CreateNoWindow=$true;$psi.RedirectStandardError=$true;$psi.RedirectStandardOutput=$true;$psi.Arguments='-NoLogo -NoProfile -NonInteractive -ExecutionPolicy Bypass -File '+(Quote-ProcessArgument $updater)+' -Mode Install -ResultFile '+(Quote-ProcessArgument $result)+' -ProgressFile '+(Quote-ProcessArgument $progress);$p=New-Object Diagnostics.Process;$p.StartInfo=$psi;[void]$p.Start();$ot=$p.StandardOutput.ReadToEndAsync();$et=$p.StandardError.ReadToEndAsync();while(!$p.WaitForExit(100)){Read-ProgressFile $progress 'Installing update';Pump-UI};$p.WaitForExit();$out=$ot.Result;$err=$et.Result;Write-LauncherLog ("PACKAGE UPDATE EXIT $($p.ExitCode)`n$out`n$err");if($p.ExitCode -eq 0){Set-WorkProgress 'Updated UNCANNY launched' 100;Start-Sleep -Milliseconds 450;$w.Close()}else{Show-OperationFailure 'Package update' ([pscustomobject]@{StdOut=$out;StdErr=$err;ExitCode=$p.ExitCode})}}finally{Remove-Item $progress,$result -Force -ErrorAction SilentlyContinue;if($w.IsVisible){Set-LauncherBusy $false}}
}
function Add-ManualGameInPlace([string]$exe){
  if(!$exe -or !(Test-Path -LiteralPath $exe -PathType Leaf)){throw 'Selected executable no longer exists.'}
  Add-UncannyLibraryTarget $exe
  $full=Resolve-LauncherExistingFilePath $exe;if(!$full){throw 'Selected executable could not be resolved safely.'}
  $existing=@($script:all|Where-Object{$_.Exe -ieq $full}|Select-Object -First 1)
  if(!$existing.Count){
    $installed=Test-UncannyInstalled $full;$rev=Get-UncannyInstallRevision $full;$needs=Test-UncannyInstallNeedsUpdate $full $packageRevision $packageBuildId;$nm=Get-UncannyFriendlyName $full ([IO.Path]::GetFileNameWithoutExtension($full));$isEmulator=Test-UncannyEmulatorExe $full;$isPCSX2=Test-UncannyPCSX2Exe $full;$emuFamily=Get-UncannyEmulatorIdentity $full
    $item=[pscustomobject]@{Name=$nm;Exe=$full;Directory=(Split-Path $full -Parent);Cover='';Installed=$installed;InstalledRevision=$rev;InstalledBuildId=(Get-UncannyInstallBuildId $full);NeedsUpdate=$needs;Source='Added';Kind=$(if($isEmulator){'Emulator'}else{'Game'});EmulatorFamily=$emuFamily;FileName=[IO.Path]::GetFileName($full);State=$(if($needs){'UPDATE'}elseif($installed){'INSTALLED'}else{'NOT INSTALLED'});StateBrush=$(if($needs){'#FFE29A'}elseif($installed){'#C9F7B1'}else{'#A7AFBA'});StateBackground=$(if($needs){'#302716'}elseif($installed){'#1A2D1C'}else{'#20252D'});Initial=$(if($nm){$nm.Substring(0,1).ToUpperInvariant()}else{'U'});IsPCSX2=$isPCSX2}
    $script:all=@($script:all)+@($item)
  }
  Filter-List;$match=@($g.ItemsSource|Where-Object{$_.Exe -ieq $full}|Select-Object -First 1);if($match.Count){$g.SelectedItem=$match[0];$g.ScrollIntoView($match[0])};$status.Text='Added '+[IO.Path]::GetFileNameWithoutExtension($full)+'.'
}
function Convert-ScanItems($items,[string]$selectExe=''){
  $records=[Collections.Generic.List[object]]::new()
  foreach($scan in @($items)){
    $rawExe=[string](Get-LauncherObjectValue $scan 'Exe' '')
    $exe=Resolve-LauncherExistingFilePath $rawExe
    if(!$exe){Write-LauncherLog ('SCAN ITEM SKIP invalid exe='+$rawExe);continue}
    $name=[string](Get-LauncherObjectValue $scan 'Name' ([IO.Path]::GetFileNameWithoutExtension($exe)))
    $cover=[string](Get-LauncherObjectValue $scan 'Cover' '')
    $source=[string](Get-LauncherObjectValue $scan 'Source' 'Discovered')
    $kind=[string](Get-LauncherObjectValue $scan 'Kind' '')
    $fam=[string](Get-LauncherObjectValue $scan 'EmulatorFamily' '')
    if(!$fam){$fam=Get-UncannyEmulatorIdentity $exe}
    $dup=[Math]::Max(1,[int](Get-LauncherObjectValue $scan 'DuplicateInstallCount' 1))
    $isPCSX2=Test-UncannyPCSX2Exe $exe
    $installed=Test-UncannyInstalled $exe;$rev=Get-UncannyInstallRevision $exe;$needs=Test-UncannyInstallNeedsUpdate $exe $packageRevision $packageBuildId
    if($isPCSX2 -and $dup -gt 1){$kind='Emulator · '+$dup+' PCSX2 installs'}elseif(!$kind){$kind=if($fam){'Emulator'}else{'Game'}}
    $initial=if($name){$name.Substring(0,1).ToUpperInvariant()}else{'U'}
    $records.Add((Normalize-LauncherGameRecord ([pscustomobject]@{Name=$name;Exe=$exe;Directory=(Split-Path $exe -Parent);Cover=$cover;Installed=$installed;InstalledRevision=$rev;InstalledBuildId=(Get-UncannyInstallBuildId $exe);NeedsUpdate=$needs;Source=$source;Kind=$kind;EmulatorFamily=$fam;DuplicateInstallCount=$dup;FileName=[IO.Path]::GetFileName($exe);State=$(if($needs){'UPDATE'}elseif($installed){'INSTALLED'}else{'NOT INSTALLED'});StateBrush=$(if($needs){'#FFE29A'}elseif($installed){'#C9F7B1'}else{'#A7AFBA'});StateBackground=$(if($needs){'#302716'}elseif($installed){'#1A2D1C'}else{'#20252D'});Initial=$initial;IsPCSX2=$isPCSX2})))
  }
  $script:all=@($records);Filter-List
  Write-LauncherLog ('SCAN RENDER COMPLETE count='+$script:all.Count)
  if($selectExe){$match=@($g.ItemsSource|Where-Object{$_.Exe -ieq $selectExe}|Select-Object -First 1);if($match.Count){$g.SelectedItem=$match[0];$g.ScrollIntoView($match[0])}}
}
function Reload-Library([string]$selectExe=''){
  if($script:scanProcess -and !$script:scanProcess.HasExited){return}
  $worker=Join-Path $script:launcherRuntimeRoot 'UNCANNY-SCAN.ps1';if(!(Test-Path -LiteralPath $worker)){throw 'UNCANNY-SCAN.ps1 is missing from this package.'}
  $script:scanResult=Join-Path $env:TEMP ('uncanny-scan-'+[guid]::NewGuid().ToString('N')+'.json');$script:scanProgress=Join-Path $env:TEMP ('uncanny-scan-'+[guid]::NewGuid().ToString('N')+'.progress');$script:scanSelect=$selectExe
  Set-LauncherBusy $true 'Scanning your PC...' $false;$script:operationProgressFloor=0;$script:lastProgress=0;if($workFill){$workFill.Width=0};Write-LauncherLog 'ASYNC SCAN START'
  try{
    $psi=New-Object Diagnostics.ProcessStartInfo;$psi.FileName='powershell.exe';$psi.WorkingDirectory=$root;$psi.UseShellExecute=$false;$psi.CreateNoWindow=$true;$psi.Arguments='-NoLogo -NoProfile -NonInteractive -ExecutionPolicy Bypass -File '+(Quote-ProcessArgument $worker)+' -Root '+(Quote-ProcessArgument $script:launcherRuntimeRoot)+' -ResultFile '+(Quote-ProcessArgument $script:scanResult)+' -ProgressFile '+(Quote-ProcessArgument $script:scanProgress)
    $p=New-Object Diagnostics.Process;$p.StartInfo=$psi;[void]$p.Start();$script:scanProcess=$p
    $timer=New-Object Windows.Threading.DispatcherTimer;$timer.Interval=[TimeSpan]::FromMilliseconds(100);$script:scanTimer=$timer
    $timer.add_Tick({
      if(!$script:scanProcess){return};Read-ProgressFile $script:scanProgress 'Scanning known libraries'
      if(!$script:scanProcess.HasExited){return};$code=$script:scanProcess.ExitCode;$script:scanTimer.Stop();$script:scanProcess=$null
      try{if($code -ne 0 -or !(Test-Path -LiteralPath $script:scanResult)){throw "Scan worker exited $code"};$raw=Get-Content -LiteralPath $script:scanResult -Raw|ConvertFrom-Json;Convert-ScanItems $raw $script:scanSelect;$dups=@($script:all|Where-Object{$_.IsPCSX2 -and $_.DuplicateInstallCount -gt 1});$status.Text=if($dups.Count){'Library ready - multiple PCSX2 installs detected. Operations stay bound to the selected path.'}elseif($script:all.Count){'Library ready - game and emulator scan complete.'}else{'No supported games or emulators found. Add one manually.'};Write-LauncherLog ("ASYNC SCAN COMPLETE count="+$script:all.Count+" pcsx2Duplicates="+$dups.Count)}catch{$status.Text='Scan failed.';Write-LauncherLog ('ASYNC SCAN ERROR '+(Get-LauncherErrorDetail $_));[Windows.MessageBox]::Show("UNCANNY could not finish the scan.`n`n$($_.Exception.Message)`n`nLog: $sessionLog",'UNCANNY')|Out-Null}finally{Remove-Item $script:scanResult,$script:scanProgress -Force -ErrorAction SilentlyContinue;Set-LauncherBusy $false;Update-Actions}
    });$timer.Start()
  }catch{$script:scanProcess=$null;Set-LauncherBusy $false;throw}
}
function Show-OperationFailure([string]$verb,$result){$detail=$result.StdErr.Trim();if(!$detail){$detail=$result.StdOut.Trim()};if($detail.Length -gt 1200){$detail=$detail.Substring([Math]::Max(0,$detail.Length-1200))};$message="$verb failed. UNCANNY kept or restored the original files.";if($detail){$message+="`n`n$detail"};$message+="`n`nFull log: $sessionLog";[Windows.MessageBox]::Show($message,'UNCANNY')|Out-Null}
function Wait-UncannyInstalled([string]$exe,[int]$seconds=5){$until=(Get-Date).AddSeconds($seconds);do{if(Test-UncannyInstalled $exe){return $true};Start-Sleep -Milliseconds 150;Pump-UI}while((Get-Date) -lt $until);return $false}
function Clear-StaleUncannyLaunchMonitor([string]$directory,[string]$targetExe){
  try{
    $targetFull=[IO.Path]::GetFullPath($targetExe);$base=[IO.Path]::GetFullPath($directory)
    $all=@(Get-Process -ErrorAction SilentlyContinue)
    $targets=@($all|Where-Object{
      try{$_.Path -and [IO.Path]::GetFullPath([string]$_.Path) -ieq $targetFull -and !$_.HasExited}catch{$false}
    })
    if($targets.Count){
      foreach($tp in $targets){try{$tp.Refresh();if($tp.MainWindowHandle -ne [IntPtr]::Zero){return $false}}catch{return $false}}
      $record=Get-UncannyInstallRecordPath $targetFull
      if(!$record -or !(Test-Path -LiteralPath $record -PathType Leaf)){return $false}
      $raw=Get-Content -LiteralPath $record -Raw
      $mode=[regex]::Match($raw,'(?im)^Mode=(.+)$')
      $launcherName=[regex]::Match($raw,'(?im)^Launcher=(.+)$')
      $launcherSha=[regex]::Match($raw,'(?im)^LauncherSHA256=([a-fA-F0-9]{64})\r?$')
      if(!$mode.Success -or $mode.Groups[1].Value.Trim() -ine 'sidecar' -or !$launcherSha.Success){return $false}
      $launcherPath=Join-Path $base $(if($launcherName.Success -and $launcherName.Groups[1].Value.Trim()){$launcherName.Groups[1].Value.Trim()}else{'UNCANNY.Launch.exe'})
      if(!(Test-Path -LiteralPath $launcherPath -PathType Leaf) -or (Get-UncannyLibrarySHA256 $launcherPath) -ine $launcherSha.Groups[1].Value){return $false}
      foreach($sidecar in $all){
        try{
          $path=[string]$sidecar.Path
          if(!$path -or [IO.Path]::GetFullPath($path) -ine [IO.Path]::GetFullPath($launcherPath) -or $sidecar.HasExited){continue}
          $session=Join-Path $base ('UNCANNY-LAUNCH-SESSION-'+[string]$sidecar.Id+'.log')
          if(!(Test-Path -LiteralPath $session -PathType Leaf)){continue}
          $proof=(Get-Content -LiteralPath $session -Tail 160 -ErrorAction Stop) -join [Environment]::NewLine
          $owned=@()
          foreach($tp in $targets){if($proof -match ('(?m)\bPROCESS_FOUND PID='+[regex]::Escape([string]$tp.Id)+'\b') -and $proof -match [regex]::Escape($targetFull)){$owned+=$tp}}
          if(!$owned.Count){continue}
          try{$event=[Threading.EventWaitHandle]::OpenExisting(('Local\UNCANNY.LaunchStop.'+[string]$sidecar.Id));try{$event.Set()|Out-Null}finally{$event.Dispose()}}catch{}
          Start-Sleep -Milliseconds 250
          foreach($tp in $owned){
            try{$tp.Refresh();if(!$tp.HasExited -and $tp.MainWindowHandle -eq [IntPtr]::Zero){Stop-Process -Id $tp.Id -Force -ErrorAction Stop;$tp.WaitForExit(2500)|Out-Null}}catch{}
          }
          try{$sidecar.Refresh();if(!$sidecar.HasExited){Stop-Process -Id $sidecar.Id -Force -ErrorAction SilentlyContinue}}catch{}
          Write-LauncherLog ('RECOVERED VERIFIED HEADLESS SESSION target='+$targetFull+' sidecarPid='+$sidecar.Id)
          return $true
        }catch{}
      }
      return $false
    }
    $signaled=$false
    foreach($proc in $all){
      try{
        $path=[string]$proc.Path
        if(!$path -or (Split-Path -Parent ([IO.Path]::GetFullPath($path))) -ine $base){continue}
        if([IO.Path]::GetFileName($path) -notmatch '^(?i)UNCANNY\.(Launch|NativeLauncher|EngineLauncher)\.exe$'){continue}
        $event=[Threading.EventWaitHandle]::OpenExisting(('Local\UNCANNY.LaunchStop.'+[string]$proc.Id))
        try{$event.Set()|Out-Null;$signaled=$true}finally{$event.Dispose()}
        try{$proc.WaitForExit(750)|Out-Null}catch{}
      }catch{}
    }
    return $signaled
  }catch{return $false}
}
function Start-UncannyGame($s){
  try{
    $launchExe=$s.Exe
    $launchArgs=$null
    $record=Get-UncannyInstallRecordPath $s.Exe
    if($record -and (Test-Path -LiteralPath $record -PathType Leaf)){
      $mode=''
      $launcherName='UNCANNY.Launch.exe'
      try{
        $raw=Get-Content -LiteralPath $record -Raw
        $m=[regex]::Match($raw,'(?im)^Mode=(.+)$')
        if($m.Success){$mode=$m.Groups[1].Value.Trim()}
        $l=[regex]::Match($raw,'(?im)^Launcher=(.+)$')
        if($l.Success -and $l.Groups[1].Value.Trim()){$launcherName=$l.Groups[1].Value.Trim()}
      }catch{}
      if($mode -ieq 'sidecar'){
        $launchExe=Join-Path $s.Directory $launcherName
        if(!(Test-Path -LiteralPath $launchExe -PathType Leaf)){throw 'UNCANNY sidecar launcher is missing. Use Repair.'}
        $launchArgs=(Quote-ProcessArgument $s.Exe)
      }
    }
    if(Clear-StaleUncannyLaunchMonitor $s.Directory $s.Exe){Write-LauncherLog 'STALE/HEADLESS SIDECAR SESSION CLEARED BEFORE LAUNCH';Start-Sleep -Milliseconds 200}
    Write-LauncherLog ('LAUNCH '+$launchExe+' TARGET='+$s.Exe)
    if($launchArgs){$p=Start-Process -FilePath $launchExe -ArgumentList $launchArgs -WorkingDirectory $s.Directory -PassThru}
    else{$p=Start-Process -FilePath $launchExe -WorkingDirectory $s.Directory -PassThru}
    $status.Text='Launching '+$s.Name+'...'
    Start-Sleep -Milliseconds 750
    if($p.HasExited -and $p.ExitCode -eq 23){
      if(Clear-StaleUncannyLaunchMonitor $s.Directory $s.Exe){
        Write-LauncherLog 'STALE SIDECAR SESSION CLEARED - RETRYING ONCE'
        Start-Sleep -Milliseconds 200
        if($launchArgs){$p=Start-Process -FilePath $launchExe -ArgumentList $launchArgs -WorkingDirectory $s.Directory -PassThru}
        else{$p=Start-Process -FilePath $launchExe -WorkingDirectory $s.Directory -PassThru}
        Start-Sleep -Milliseconds 750
      }
    }
    if($p.HasExited -and $p.ExitCode -ne 0){
      $latest=Get-ChildItem -LiteralPath $s.Directory -Filter 'UNCANNY-LAUNCH-SESSION-*.log' -File -ErrorAction SilentlyContinue|Sort-Object LastWriteTime -Descending|Select-Object -First 1
      $detail=if($latest){(Get-Content -LiteralPath $latest.FullName -Tail 24 -ErrorAction SilentlyContinue)-join "`n"}else{"UNCANNY launch process exited with code $($p.ExitCode)."}
      Write-LauncherLog ('LAUNCH QUICK EXIT '+$detail)
      [Windows.MessageBox]::Show("$($s.Name) did not stay running.`n`n$detail`n`nLog: $sessionLog",'UNCANNY')|Out-Null
    }
  }catch{
    Write-LauncherLog ('LAUNCH ERROR '+(Get-LauncherErrorDetail $_))
    [Windows.MessageBox]::Show("Could not launch $($s.Name).`n`n$($_.Exception.Message)`n`nLog: $sessionLog",'UNCANNY')|Out-Null
  }
}
function Invoke-PrimaryAction{
  if($script:busy){return};$s=Get-SelectedGame;if($null -eq $s){return};if($s.Installed -and !$s.NeedsUpdate){Start-UncannyGame $s;return}
  Set-LauncherBusy $true ('Installing UNCANNY for '+$s.Name+'...') $false;$script:operationProgressFloor=0;Set-WorkProgress 'Preparing installation' 1;$primary.Content='Installing...'
  try{
    $result=Invoke-UncannyInstall $s $(if($s.NeedsUpdate){'Updating'}else{'Installing'})
    if($result.ExitCode -ne 0){Show-OperationFailure 'Install' $result;return}
    if(!(Wait-UncannyInstalled $s.Exe 5)){Write-LauncherLog 'INSTALL EXITED 0 BUT INSTALL RECORD WAS NOT FOUND';[Windows.MessageBox]::Show("The installer returned success, but UNCANNY could not verify the installed launch record. Nothing will be called installed until that record exists.`n`nLog: $sessionLog",'UNCANNY')|Out-Null;return}
    try{
      if(!(Refresh-OneGameState $s.Exe)){Load-CachedLibraryFast|Out-Null}
      $status.Text='UNCANNY is current. Launch when ready.'
    }catch{
      Write-LauncherLog ('POST-INSTALL REFRESH RECOVERED '+$_.Exception.ToString())
      try{Load-CachedLibraryFast|Out-Null}catch{Write-LauncherLog ('POST-INSTALL CACHE RECOVERY FAILED '+$_.Exception.ToString())}
      $status.Text='UNCANNY installed successfully. Library refresh recovered safely.'
    }
  }finally{
    Set-LauncherBusy $false
    try{Update-Actions}catch{Write-LauncherLog ('POST-INSTALL ACTION REFRESH RECOVERED '+$_.Exception.ToString())}
  }
}
$g.Add_SelectionChanged({try{Update-Actions}catch{Write-LauncherLog ('SELECTION REFRESH RECOVERED '+$_.Exception.ToString())}});$g.Add_MouseDoubleClick({try{Invoke-PrimaryAction}catch{Write-LauncherLog ('PRIMARY DOUBLECLICK RECOVERED '+$_.Exception.ToString())}});$primary.Add_Click({try{Invoke-PrimaryAction}catch{Write-LauncherLog ('PRIMARY CLICK RECOVERED '+$_.Exception.ToString());[Windows.MessageBox]::Show("UNCANNY could not complete that action.`n`n$($_.Exception.Message)`n`nLog: $sessionLog",'UNCANNY')|Out-Null}})
$remove.Add_Click({if($script:busy){return};$s=Get-SelectedGame;if($null -eq $s){return};if([Windows.MessageBox]::Show('Remove every recorded UNCANNY install layer from '+$s.Name+' and restore the verified original files?','UNCANNY','YesNo','Question') -ne 'Yes'){return};Set-LauncherBusy $true ('Removing UNCANNY from '+$s.Name+'...') $true;try{$result=Invoke-UncannyScript 'ROLLBACK-NATIVE.ps1' @('-TargetDir',(Quote-ProcessArgument $s.Directory),'-TargetExe',(Quote-ProcessArgument $s.Exe),'-AllLayers');if($result.ExitCode -eq 0){Refresh-OneGameState $s.Exe|Out-Null;$status.Text='UNCANNY fully removed. All recorded install layers were restored.'}else{Show-OperationFailure 'Remove' $result}}finally{Set-LauncherBusy $false;Update-Actions}})
$repair.Add_Click({if($script:busy){return};$s=Get-SelectedGame;if($null -eq $s){return};Set-LauncherBusy $true ('Repairing '+$s.Name+'...') $true;try{$rollback=Invoke-UncannyScript 'ROLLBACK-NATIVE.ps1' @('-TargetDir',(Quote-ProcessArgument $s.Directory),'-TargetExe',(Quote-ProcessArgument $s.Exe));if($rollback.ExitCode -ne 0){Show-OperationFailure 'Repair rollback' $rollback;return};$install=Invoke-UncannyInstall $s 'Repairing';if($install.ExitCode -eq 0 -and (Wait-UncannyInstalled $s.Exe 5)){try{if(!(Refresh-OneGameState $s.Exe)){Load-CachedLibraryFast|Out-Null}}catch{Write-LauncherLog ('POST-REPAIR REFRESH RECOVERED '+$_.Exception.ToString());try{Load-CachedLibraryFast|Out-Null}catch{}};$status.Text='Repair complete.'}else{Show-OperationFailure 'Repair install' $install}}finally{Set-LauncherBusy $false;Update-Actions}})
$proof.Add_Click({
  if($script:busy){return};$s=Get-SelectedGame;if($null -eq $s -or !$s.IsPCSX2 -or !$s.Installed){return}
  $result=Invoke-UncannyScript 'VERIFY-REVENANT-PCSX2.ps1' @('-TargetDir',(Quote-ProcessArgument $s.Directory));$text=($result.StdOut.Trim()+"`n"+$result.StdErr.Trim()).Trim();if($text.Length -gt 1600){$text=$text.Substring([Math]::Max(0,$text.Length-1600))}
  if($result.ExitCode -eq 0){$revenantState.Text='VERIFIED';[Windows.MessageBox]::Show("REVENANT live proof PASSED for this PCSX2 session.`n`n$text",'UNCANNY')|Out-Null}else{[Windows.MessageBox]::Show("REVENANT is not fully proven yet.`n`n$text`n`nTo create real rendered-use proof: launch a game, press HOME, open REVENANT, run the cyan/magenta loading test, return focus to gameplay, then confirm only if you actually saw the pulse. After originals restore, run Verify REVENANT again.",'UNCANNY')|Out-Null}
})
$rescanButton.Add_Click({Reload-Library});$scanOnStartupCheck.Add_Click({$script:scanOnStartup=[bool]$scanOnStartupCheck.IsChecked;Save-LauncherSettings;$status.Text=if($script:scanOnStartup){'Automatic startup scanning enabled.'}else{'Automatic startup scanning disabled. Use Scan PC whenever you want a refresh.'};Write-LauncherLog ('SCAN ON STARTUP '+$(if($script:scanOnStartup){'ON'}else{'OFF'}))});$search.Add_TextChanged({$searchHint.Visibility=if($search.Text.Length){'Collapsed'}else{'Visible'};Filter-List});$packageUpdate.Add_Click({Install-PackageUpdate});$logs.Add_Click({try{Start-Process explorer.exe $logDir}catch{}})
$revenantTimer=New-Object Windows.Threading.DispatcherTimer
$revenantTimer.Interval=[TimeSpan]::FromSeconds(1)
$revenantTimer.Add_Tick({
  try{
    if($script:busy){return}
    $s=Get-SelectedGame
    if($null -ne $s -and $s.IsPCSX2 -and $s.Installed -and $revenantPanel.Visibility -eq 'Visible'){
      $revenantState.Text=Get-LatestRevenantProofState $s.Directory
    }
  }catch{}
})
$revenantTimer.Start()
$updateTimer=New-Object Windows.Threading.DispatcherTimer;$updateTimer.Interval=[TimeSpan]::FromMilliseconds(500);$updateTimer.Add_Tick({Finish-PackageUpdateCheck});$updateTimer.Start()
$add.Add_Click({if($script:busy){return};try{$d=New-Object Microsoft.Win32.OpenFileDialog;$d.Title='Add a game or emulator';$d.Filter='Game or emulator (*.exe)|*.exe';$d.CheckFileExists=$true;$d.Multiselect=$false;if($d.ShowDialog() -eq $true){Write-LauncherLog ('ADD GAME '+$d.FileName);Add-ManualGameInPlace $d.FileName}}catch{Write-LauncherLog ('ADD GAME ERROR '+$_.Exception.ToString());[Windows.MessageBox]::Show("Could not add that executable.`n`n$($_.Exception.Message)`n`nLog: $sessionLog",'UNCANNY')|Out-Null}})
function Start-LauncherInitialLoad{
  if($script:initialScanDone){return}
  $script:initialScanDone=$true
  Write-LauncherLog 'INITIAL LOAD START'
  $cached=Load-CachedLibraryFast
  Start-PackageUpdateCheck
  if($Rescan -or $script:scanOnStartup){
    $w.Dispatcher.BeginInvoke([Action]{
      try{Reload-Library}
      catch{
        Write-LauncherLog ('ASYNC STARTUP SCAN START RECOVERED '+(Get-LauncherErrorDetail $_))
        $status.Text='Ready. Scan could not start; use Scan PC to retry.'
      }
    },[Windows.Threading.DispatcherPriority]::Background)|Out-Null
  }elseif(!$cached){
    $status.Text='Startup scan is off. Add a game manually or press Scan PC when you want discovery.'
    $count.Text='0 cached/manual titles'
  }else{
    $status.Text='Ready. Startup scan is off; cached and manually added titles are available immediately.'
  }
  Write-LauncherLog ('INITIAL LOAD COMPLETE count='+$script:all.Count+' cached='+[bool]$cached)
}
$w.Add_Loaded({
  try{Start-LauncherInitialLoad}
  catch{
    Write-LauncherLog ('LOADED STARTUP RECOVERED '+(Get-LauncherErrorDetail $_))
    $status.Text='UNCANNY opened. Some cached discovery data was skipped safely.'
  }
})
$w.Add_ContentRendered({
  try{
    if(!$script:initialScanDone){
      Write-LauncherLog 'CONTENT RENDERED FALLBACK'
      Start-LauncherInitialLoad
    }
  }catch{
    Write-LauncherLog ('CONTENT RENDERED RECOVERED '+(Get-LauncherErrorDetail $_))
    $status.Text='UNCANNY opened. Some cached discovery data was skipped safely.'
  }
})
Write-LauncherLog 'LAUNCHER OPEN';[void]$w.ShowDialog();try{$revenantTimer.Stop();$updateTimer.Stop()}catch{};Write-LauncherLog 'LAUNCHER CLOSED'
