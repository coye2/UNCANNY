﻿Set-StrictMode -Version Latest
function Get-UncannyObjectValue($Object,[string]$Name,$Default=$null){
  if($null -eq $Object){return $Default}
  try{
    $p=$Object.PSObject.Properties[$Name]
    if($null -ne $p){return $p.Value}
  }catch{}
  return $Default
}
function Resolve-UncannyExistingFilePath([string]$Value){
  if(!$Value){return ''}
  try{
    $full=[IO.Path]::GetFullPath($Value)
    if(!(Test-Path -LiteralPath $full -PathType Leaf)){return ''}
    $item=Get-Item -LiteralPath $full -Force -ErrorAction Stop
    $resolved=[string](Get-UncannyObjectValue $item 'FullName' $full)
    if(!$resolved){return ''}
    return [IO.Path]::GetFullPath($resolved)
  }catch{return ''}
}
function Invoke-UncannyProgress([scriptblock]$Progress,[string]$Stage,[int]$Percent){
  if($Progress){try{& $Progress $Stage ([Math]::Max(0,[Math]::Min(100,$Percent)))}catch{}}
}
function Write-UncannyJsonAtomic([string]$Path,[string]$Json){
  if(!$Path){throw 'Atomic JSON path is empty.'}
  $folder=Split-Path -Parent $Path
  if($folder){New-Item -ItemType Directory -Force -Path $folder|Out-Null}
  $tmp=$Path+'.tmp-'+[guid]::NewGuid().ToString('N')
  $backup=$Path+'.bak-'+[guid]::NewGuid().ToString('N')
  [IO.File]::WriteAllText($tmp,$Json,[Text.UTF8Encoding]::new($true))
  try{
    if(Test-Path -LiteralPath $Path -PathType Leaf){
      [IO.File]::Replace($tmp,$Path,$backup)
      Remove-Item -LiteralPath $backup -Force -ErrorAction SilentlyContinue
    }else{
      [IO.File]::Move($tmp,$Path)
    }
  }finally{
    if(Test-Path -LiteralPath $tmp){Remove-Item -LiteralPath $tmp -Force -ErrorAction SilentlyContinue}
    if(Test-Path -LiteralPath $backup){Remove-Item -LiteralPath $backup -Force -ErrorAction SilentlyContinue}
  }
}
function Get-UncannyInstallRecordPath([string]$Exe){
  if(!$Exe){return ''}
  try{$full=[IO.Path]::GetFullPath($Exe);$dir=Split-Path -Parent $full;$name=[IO.Path]::GetFileName($full);return (Join-Path $dir ('.uncanny\launch\'+$name+'.ini'))}catch{return ''}
}
function Get-UncannyInstallRevision([string]$Exe){
  $record=Get-UncannyInstallRecordPath $Exe;if(!$record -or !(Test-Path -LiteralPath $record -PathType Leaf)){return ''}
  try{$m=[regex]::Match((Get-Content -LiteralPath $record -Raw),'(?im)^Revision=(.+)$');if($m.Success){return $m.Groups[1].Value.Trim()}}catch{}
  return ''
}
function Get-UncannyInstallBuildId([string]$Exe){
  $record=Get-UncannyInstallRecordPath $Exe;if(!$record -or !(Test-Path -LiteralPath $record -PathType Leaf)){return ''}
  try{$m=[regex]::Match((Get-Content -LiteralPath $record -Raw),'(?im)^BuildId=(.+)$');if($m.Success){return $m.Groups[1].Value.Trim()}}catch{}
  return ''
}
function Get-UncannyLibrarySHA256([string]$Path){
  if(!$Path -or !(Test-Path -LiteralPath $Path -PathType Leaf)){return ''}
  try{
    $sha=[Security.Cryptography.SHA256]::Create()
    try{
      $stream=[IO.File]::Open($Path,[IO.FileMode]::Open,[IO.FileAccess]::Read,[IO.FileShare]::ReadWrite)
      try{return ([BitConverter]::ToString($sha.ComputeHash($stream))).Replace('-','').ToLowerInvariant()}
      finally{$stream.Dispose()}
    }finally{$sha.Dispose()}
  }catch{return ''}
}
function Test-UncannyLegacyPCSX2WrapperEntry([string]$Exe){
  if(!$Exe){return $false}
  try{
    $full=[IO.Path]::GetFullPath($Exe)
    if([IO.Path]::GetFileName($full) -ine 'pcsx2-qt.exe'){return $false}
    $dir=Split-Path -Parent $full
    $legacyOriginal=Join-Path $dir 'pcsx2-qt.uncanny-original.exe'
    $legacyLauncher=Join-Path $dir 'UNCANNY.NativeLauncher.exe'
    if(!(Test-Path -LiteralPath $legacyOriginal -PathType Leaf) -or !(Test-Path -LiteralPath $legacyLauncher -PathType Leaf)){return $false}
    $entrySha=Get-UncannyLibrarySHA256 $full
    $launcherSha=Get-UncannyLibrarySHA256 $legacyLauncher
    return [bool]($entrySha -and $launcherSha -and $entrySha -ieq $launcherSha)
  }catch{return $false}
}
function Test-UncannyInstallNeedsUpdate([string]$Exe,[string]$CurrentRevision,[string]$CurrentBuildId){
  if(!(Test-UncannyInstalled $Exe)){return $false}
  if(Test-UncannyLegacyPCSX2WrapperEntry $Exe){return $true}
  $revision=Get-UncannyInstallRevision $Exe;$buildId=Get-UncannyInstallBuildId $Exe
  if(!$revision -or $revision -ne $CurrentRevision){return $true}
  if($CurrentBuildId -and (!$buildId -or $buildId -ne $CurrentBuildId)){return $true}
  try{
    $full=[IO.Path]::GetFullPath($Exe);$dir=Split-Path -Parent $full
    $record=Get-UncannyInstallRecordPath $full
    if($record -and (Test-Path -LiteralPath $record -PathType Leaf)){
      $raw=Get-Content -LiteralPath $record -Raw
      $mode=[regex]::Match($raw,'(?im)^Mode=(.+)$')
      if($mode.Success -and $mode.Groups[1].Value.Trim() -ieq 'sidecar'){
        $targetSha=[regex]::Match($raw,'(?im)^TargetSHA256=([a-fA-F0-9]{64})\r?$')
        $launcherSha=[regex]::Match($raw,'(?im)^LauncherSHA256=([a-fA-F0-9]{64})\r?$')
        $launcherName=[regex]::Match($raw,'(?im)^Launcher=(.+)$')
        if(!$targetSha.Success -or (Get-UncannyLibrarySHA256 $full) -ine $targetSha.Groups[1].Value){return $true}
        $sidecar=Join-Path $dir $(if($launcherName.Success -and $launcherName.Groups[1].Value.Trim()){$launcherName.Groups[1].Value.Trim()}else{'UNCANNY.Launch.exe'})
        if(!$launcherSha.Success -or !(Test-Path -LiteralPath $sidecar -PathType Leaf) -or (Get-UncannyLibrarySHA256 $sidecar) -ine $launcherSha.Groups[1].Value){return $true}
      }
    }
  }catch{return $true}
  return $false
}
function Test-UncannyInstalled([string]$Exe){
  if(!$Exe){return $false}
  try{
    $full=[IO.Path]::GetFullPath($Exe);$dir=Split-Path -Parent $full;$name=[IO.Path]::GetFileName($full)
    $record=Get-UncannyInstallRecordPath $full
    if(Test-Path -LiteralPath $record -PathType Leaf){
      $raw=Get-Content -LiteralPath $record -Raw
      $mode=[regex]::Match($raw,'(?im)^Mode=(.+)$')
      if($mode.Success -and $mode.Groups[1].Value.Trim() -ieq 'sidecar'){
        $target=[regex]::Match($raw,'(?im)^Target=(.+)$')
        $launcher=[regex]::Match($raw,'(?im)^Launcher=(.+)$')
        if(!$target.Success -or $target.Groups[1].Value.Trim() -ine $name){return $false}
        $sidecar=Join-Path $dir $(if($launcher.Success -and $launcher.Groups[1].Value.Trim()){$launcher.Groups[1].Value.Trim()}else{'UNCANNY.Launch.exe'})
        return (Test-Path -LiteralPath $full -PathType Leaf) -and (Test-Path -LiteralPath $sidecar -PathType Leaf)
      }
      $original=Join-Path $dir ([IO.Path]::GetFileNameWithoutExtension($full)+'.uncanny-original.exe')
      return (Test-Path -LiteralPath $original -PathType Leaf)
    }
    return (Test-Path -LiteralPath (Join-Path $dir '.uncanny\direct-launch.ini') -PathType Leaf)
  }catch{return $false}
}
function Initialize-UncannyShellIcon{
  if(('UncannyShellImage' -as [type])){return}
  Add-Type -AssemblyName System.Drawing -ErrorAction SilentlyContinue
  $src=@'
using System;
using System.Drawing;
using System.Drawing.Imaging;
using System.Runtime.InteropServices;
public static class UncannyShellImage {
  [StructLayout(LayoutKind.Sequential)] public struct SIZE { public int cx; public int cy; public SIZE(int x,int y){cx=x;cy=y;} }
  [Flags] public enum SIIGBF : uint { RESIZETOFIT=0x0, BIGGERSIZEOK=0x1, MEMORYONLY=0x2, ICONONLY=0x4, THUMBNAILONLY=0x8, INCACHEONLY=0x10, CROPTOSQUARE=0x20, WIDETHUMBNAILS=0x40, ICONBACKGROUND=0x80, SCALEUP=0x100 }
  [ComImport, Guid("BCC18B79-BA16-442F-80C4-8A59C30C463B"), InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
  interface IShellItemImageFactory { [PreserveSig] int GetImage(SIZE size, SIIGBF flags, out IntPtr phbm); }
  [DllImport("shell32.dll", CharSet=CharSet.Unicode, PreserveSig=false)]
  static extern void SHCreateItemFromParsingName([MarshalAs(UnmanagedType.LPWStr)] string path, IntPtr pbc, [In] ref Guid riid, [MarshalAs(UnmanagedType.Interface)] out IShellItemImageFactory factory);
  [DllImport("gdi32.dll")] static extern bool DeleteObject(IntPtr obj);
  public static bool SaveIcon(string path,string destination,int size){
    try{
      Guid iid=new Guid("BCC18B79-BA16-442F-80C4-8A59C30C463B"); IShellItemImageFactory factory;
      SHCreateItemFromParsingName(path,IntPtr.Zero,ref iid,out factory); IntPtr hbmp=IntPtr.Zero;
      int hr=factory.GetImage(new SIZE(size,size),SIIGBF.ICONONLY|SIIGBF.BIGGERSIZEOK|SIIGBF.SCALEUP,out hbmp);
      if(hr!=0||hbmp==IntPtr.Zero)return false;
      try { using(var bmp=Image.FromHbitmap(hbmp)){ bmp.Save(destination,ImageFormat.Png); } return true; }
      finally { DeleteObject(hbmp); }
    } catch { return false; }
  }
}
'@
  Add-Type -TypeDefinition $src -ReferencedAssemblies System.Drawing -ErrorAction SilentlyContinue
}
function Get-UncannyExeCover([string]$Exe){
  try{
    $cache=Join-Path $env:LOCALAPPDATA 'UNCANNY\covers-v2';New-Item -ItemType Directory -Force -Path $cache|Out-Null
    $sha=[Security.Cryptography.SHA256]::Create();try{$bytes=[Text.Encoding]::UTF8.GetBytes($Exe.ToLowerInvariant());$hash=([BitConverter]::ToString($sha.ComputeHash($bytes))).Replace('-','').Substring(0,24)}finally{$sha.Dispose()}
    $out=Join-Path $cache ($hash+'.png');if(Test-Path -LiteralPath $out){return $out}
    Initialize-UncannyShellIcon
    if(('UncannyShellImage' -as [type]) -and [UncannyShellImage]::SaveIcon($Exe,$out,256) -and (Test-Path -LiteralPath $out)){return $out}
    Add-Type -AssemblyName System.Drawing -ErrorAction SilentlyContinue
    $icon=[Drawing.Icon]::ExtractAssociatedIcon($Exe);if($null -eq $icon){return ''}
    try{$bmp=$icon.ToBitmap();try{$bmp.Save($out,[Drawing.Imaging.ImageFormat]::Png)}finally{$bmp.Dispose()}}finally{$icon.Dispose()}
    if(Test-Path -LiteralPath $out){return $out}
  }catch{}
  return ''
}
function Get-UncannyFriendlyName([string]$Exe,[string]$Fallback){
  try{
    $inspect=$Exe
    if(Test-UncannyInstalled $Exe){$candidate=Join-Path (Split-Path -Parent $Exe) ([IO.Path]::GetFileNameWithoutExtension($Exe)+'.uncanny-original.exe');if(Test-Path -LiteralPath $candidate -PathType Leaf){$inspect=$candidate}}
    $info=[Diagnostics.FileVersionInfo]::GetVersionInfo($inspect)
    foreach($v in @($info.ProductName,$info.FileDescription)){
      if($v -and $v.Trim().Length -gt 2 -and $v -notmatch '(?i)(launcher|bootstrap|helper|crash|updater|installer)'){return $v.Trim()}
    }
  }catch{}
  return $Fallback
}
function ConvertTo-UncannyKey([string]$Text){
  if(!$Text){return ''}
  return (($Text -replace '(?i)\.(exe|x64|win64|shipping)$','') -replace '[^a-zA-Z0-9]','').ToLowerInvariant()
}
function Get-UncannyEmulatorIdentity([string]$ExeOrName){
  if(!$ExeOrName){return ''}
  $leaf=[IO.Path]::GetFileName($ExeOrName)
  $probe=$leaf
  $folder=''
  try{
    if(Test-Path -LiteralPath $ExeOrName -PathType Leaf){
      $full=Resolve-UncannyExistingFilePath $ExeOrName;if(!$full){return ''};$folder=Split-Path -Leaf (Split-Path -Parent $full);$inspect=$full
      if(Test-UncannyInstalled $full){$original=Join-Path (Split-Path -Parent $full) ([IO.Path]::GetFileNameWithoutExtension($full)+'.uncanny-original.exe');if(Test-Path -LiteralPath $original -PathType Leaf){$inspect=$original}}
      $v=[Diagnostics.FileVersionInfo]::GetVersionInfo($inspect)
      $probe=(@($leaf,$folder,$v.ProductName,$v.FileDescription,$v.OriginalFilename,$v.InternalName)|Where-Object{$_}) -join ' | '
    }
  }catch{}
  switch -Regex ($probe){
    '(?i)\bPCSX2\b|pcsx2[-_ ]?(qt|avx2|sse4)?' { return 'PCSX2' }
    '(?i)\bDolphin\b|dolphinQt2' { return 'Dolphin' }
    '(?i)\bRPCS3\b' { return 'RPCS3' }
    '(?i)\bPPSSPP\b|ppssppwindows' { return 'PPSSPP' }
    '(?i)\bCemu\b' { return 'Cemu' }
    '(?i)\bXenia\b|xenia_canary' { return 'Xenia' }
    '(?i)\bRetroArch\b' { return 'RetroArch' }
    '(?i)\bDuckStation\b|duckstation-qt' { return 'DuckStation' }
    '(?i)\bRyujinx\b' { return 'Ryujinx' }
    '(?i)\b(yuzu|citron|suyu)\b' { return 'Switch' }
    '(?i)\b(Azahar|Lime3DS|Citra)\b|citra-qt' { return '3DS' }
    '(?i)\bmelonDS\b' { return 'melonDS' }
    '(?i)\bDeSmuME\b' { return 'DeSmuME' }
    '(?i)\b(Project64|simple64|RMG)\b|mupen64plus' { return 'N64' }
    '(?i)\b(BizHawk|EmuHawk)\b' { return 'BizHawk' }
    '(?i)\b(redream|Flycast)\b' { return 'Dreamcast' }
    '(?i)\bshadPS4\b' { return 'shadPS4' }
    '(?i)\bVita3K\b' { return 'Vita3K' }
    '(?i)\bxemu\b' { return 'xemu' }
    '(?i)\b(Cxbx|Cxbx-Reloaded)\b' { return 'Cxbx' }
    '(?i)\bMAME\b|mame64' { return 'MAME' }
    '(?i)\bares\b' { return 'ares' }
    '(?i)\bmGBA\b' { return 'mGBA' }
    '(?i)\b(VisualBoyAdvance|VBA-M)\b' { return 'VBA' }
    '(?i)\bSnes9x\b' { return 'Snes9x' }
    '(?i)\bFCEUX\b' { return 'FCEUX' }
    '(?i)\bMesen2?\b' { return 'Mesen' }
    '(?i)\bMednafen\b' { return 'Mednafen' }
    '(?i)\b(Kronos|Yabause|YabaSanshiro)\b' { return 'Saturn' }
    '(?i)\b(DOSBox|DOSBox-X|DOSBox Staging)\b' { return 'DOSBox' }
    '(?i)\bScummVM\b' { return 'ScummVM' }
  }
  return ''
}
function Test-UncannyEmulatorExeName([string]$Name){
  if(!$Name){return $false}
  return !!(Get-UncannyEmulatorIdentity ([IO.Path]::GetFileName($Name)))
}
function Test-UncannyEmulatorExe([string]$Exe){return !!(Get-UncannyEmulatorIdentity $Exe)}
function Test-UncannyPCSX2Exe([string]$Exe){return (Get-UncannyEmulatorIdentity $Exe) -eq 'PCSX2'}
function Get-UncannyEmulatorDisplayName([string]$Exe,[string]$Fallback){$family=Get-UncannyEmulatorIdentity $Exe;if($family){return $family};return $Fallback}
function Test-UncannyInternalExe([IO.FileInfo]$File){
  if($null -eq $File){return $true}
  $name=$File.Name;$path=$File.FullName
  if($name -match '(?i)\.uncanny-original\.exe$'){return $true}
  if(Test-UncannyInstalled $path){return $false}
  if($name -match '^(?i)UNCANNY[._-].*\.exe$'){return $true}
  if($path -match '(?i)\\\.uncanny\\|\\UNCANNY-v[0-9]|\\runtime\\dist\\|\\PRIVATE-WORKSPACE\\|\\hotfix[0-9]+_'){return $true}
  return $false
}
function Test-UncannyHelperExe([IO.FileInfo]$File){
  if($null -eq $File){return $true}
  $name=$File.Name;$path=$File.FullName
  if(Test-UncannyInternalExe $File){return $true}
  if(Test-UncannyEmulatorExe $path){return $false}
  $hardNames='^(?i)(7z|7za|7zr|unins.*|uninstall.*|setup.*|install.*|update.*|updater.*|crash.*|report.*|cef.*|webview.*|dxsetup|vc_redist.*|vcredist.*|dotnet.*|easyanticheat.*|eac.*|battleye.*|beservice.*|launcher.*|bootstrap.*|helper.*|service.*|redistributable.*|unitycrashhandler.*|crashpad.*|config.*|benchmark.*|unrealcefsubprocess|crashreportclient|shadercompileworker|epicwebhelper|gamingservices.*|steamservice|steamwebhelper|steamerrorreporter|belauncher|eosbootstrapper|eosoverlayrenderer.*|nvngx.*|vc_redist.*)\.exe$'
  if($name -match $hardNames){return $true}
  if($name -match '(?i)(crashhandler|crashreport|errorreport|error reporter|reporter|reportclient|bootstrap|anticheat|prereq|redistribut|helper|updater|uninstall|dedicatedserver|servertool|cefprocess|webhelper|overlayrenderer|sdk|diagnostic|profiler|telemetry|benchmark|editor|studio|server|compiler|service)'){return $true}
  if($name -match '^(?i)(aida64.*|amd_ryzenmaster.*|ryzenmaster.*|android-studio.*|studio64|adb|fastboot|java|javaw|node|python|pythonw|git|cmd|powershell|pwsh|explorer|msiexec|regedit|taskmgr|obs.*|discord|chrome|firefox|opera|steam|epicgameslauncher|eadesktop|upc|ubisoftconnect)\.exe$'){return $true}
  if($path -match '(?i)\\(CrashReporter|CrashReport|CrashReportClient|Crashpad|Redist|_CommonRedist|Redistributables|Prereq|Prerequisites|EasyAntiCheat|BattlEye|Installer|Installers|Support|Engine\\Binaries\\ThirdParty|Engine\\Extras|CEF|WebView|SDK|Tools|Tool|DotNet|DirectX|VC_redist|node_modules)\\'){return $true}
  if($path -match '(?i)\\(Windows|WinSxS|System32|SysWOW64|ProgramData|AppData\\Local\\Microsoft|Common Files|WindowsApps|Recovery|System Volume Information|\$Recycle\.Bin)\\'){return $true}
  return $false
}
function Get-UncannyExeScore([IO.FileInfo]$File,[string]$DisplayName,[string]$InstallDir,[bool]$Authoritative=$false){
  if($null -eq $File -or !$File.Exists){return -100000}
  if(Test-UncannyInstalled $File.FullName){return 200000}
  if(Test-UncannyHelperExe $File){return -100000}
  if(Test-UncannyEmulatorExe $File.FullName){return 100000}
  $score=0
  try{
    $base=ConvertTo-UncannyKey $File.BaseName;$display=ConvertTo-UncannyKey $DisplayName;$folder=ConvertTo-UncannyKey (Split-Path -Leaf $InstallDir)
    $relative=$File.FullName
    if($InstallDir -and $File.FullName.StartsWith($InstallDir,[StringComparison]::OrdinalIgnoreCase)){$relative=$File.FullName.Substring($InstallDir.Length).TrimStart('\\')}
    $depth=([regex]::Matches($relative,'\\')).Count
    if($depth -eq 0){$score+=300}elseif($depth -le 2){$score+=170}elseif($depth -le 4){$score+=60}else{$score-=100}
    if($Authoritative){$score+=220}
    if($display -and $base.Length -ge 4 -and ($base -eq $display -or $base.Contains($display) -or $display.Contains($base))){$score+=900}
    if($folder -and $base.Length -ge 4 -and ($base -eq $folder -or $base.Contains($folder) -or $folder.Contains($base))){$score+=650}
    if($File.Name -match '(?i)(win64[-_]?shipping|shipping|game|client64|client)\.exe$'){$score+=260}
    if($File.FullName -match '(?i)\\Binaries\\Win64\\'){$score+=180}
    if($File.FullName -match '(?i)\\(bin|bin64|x64|Win64)\\'){$score+=70}
    if($File.Length -ge 80MB){$score+=260}elseif($File.Length -ge 25MB){$score+=190}elseif($File.Length -ge 5MB){$score+=110}elseif($File.Length -ge 1MB){$score+=30}else{$score-=180}
    $v=[Diagnostics.FileVersionInfo]::GetVersionInfo($File.FullName)
    $meta=(($v.ProductName+' '+$v.FileDescription).Trim())
    $metaKey=ConvertTo-UncannyKey $meta
    if($display -and $metaKey -and ($metaKey.Contains($display) -or $display.Contains($metaKey))){$score+=450}
    if($meta -match '(?i)(game|remaster|edition|emulator)'){$score+=90}
    if($meta -match '(?i)(installer|launcher|updater|crash|reporter|sdk|development kit|server|editor|utility|benchmark|runtime)'){$score-=700}
  }catch{}
  return $score
}
function Select-UncannyPrimaryExe([string]$InstallDir,[string]$DisplayName,[bool]$Authoritative=$false,[int]$Depth=4){
  if(!$InstallDir -or !(Test-Path -LiteralPath $InstallDir -PathType Container)){return $null}
  try{
    $files=@(Get-ChildItem -LiteralPath $InstallDir -Filter '*.exe' -File -Recurse -Depth $Depth -Force -ErrorAction SilentlyContinue | Where-Object{!(Test-UncannyHelperExe $_)})
    if(!$files.Count){return $null}
    $ranked=@($files|ForEach-Object{[pscustomobject]@{File=$_;Score=(Get-UncannyExeScore $_ $DisplayName $InstallDir $Authoritative)}}|Where-Object{$_.Score -ge 120}|Sort-Object @{Expression={$_.Score};Descending=$true},@{Expression={$_.File.Length};Descending=$true})
    if($ranked.Count){return $ranked[0].File}
  }catch{}
  return $null
}
function Test-UncannyGameSignature([string]$Dir){
  if(!$Dir -or !(Test-Path -LiteralPath $Dir -PathType Container)){return $false}
  try{
    if(Test-Path -LiteralPath (Join-Path $Dir 'steam_appid.txt')){return $true}
    if(Test-Path -LiteralPath (Join-Path $Dir 'UnityPlayer.dll')){return $true}
    if(Test-Path -LiteralPath (Join-Path $Dir 'GameAssembly.dll')){return $true}
    if(Test-Path -LiteralPath (Join-Path $Dir 'Engine\Binaries\Win64')){return $true}
    if(Test-Path -LiteralPath (Join-Path $Dir 'Binaries\Win64')){return $true}
    if(@(Get-ChildItem -LiteralPath $Dir -Directory -Filter '*_Data' -ErrorAction SilentlyContinue).Count){return $true}
    if(@(Get-ChildItem -LiteralPath $Dir -File -Filter '*.pak' -ErrorAction SilentlyContinue).Count){return $true}
  }catch{}
  return $false
}
function Get-UncannyDiscoveryContainers{
  $roots=[Collections.Generic.List[object]]::new()
  foreach($drive in [IO.DriveInfo]::GetDrives()){
    if(!$drive.IsReady -or $drive.DriveType -ne [IO.DriveType]::Fixed){continue}
    foreach($rel in @('Games','Game','PC Games','Installed Games','SteamRip','SteamRIP','Steam Games','Emulators','Emulator','Emulation','GOG Games','Epic Games','XboxGames','EA Games','Origin Games','SteamLibrary\steamapps\common','Ubisoft\Ubisoft Game Launcher\games','DODI Repacks','FitGirl Repacks')){
      $p=Join-Path $drive.RootDirectory.FullName $rel;if(Test-Path -LiteralPath $p){$roots.Add([pscustomobject]@{Path=$p;Trusted=$true;Depth=1})}
    }
    $roots.Add([pscustomobject]@{Path=$drive.RootDirectory.FullName;Trusted=$false;Depth=1})
  }
  foreach($p in @((Join-Path $env:USERPROFILE 'Desktop'),(Join-Path $env:USERPROFILE 'Downloads'))){if($p -and (Test-Path -LiteralPath $p)){$roots.Add([pscustomobject]@{Path=$p;Trusted=$false;Depth=1})}}
  return @($roots|Sort-Object Path -Unique)
}
function Get-UncannyPortableCandidates([scriptblock]$Progress){
  $out=[Collections.Generic.List[object]]::new();$seen=@{};$roots=@(Get-UncannyDiscoveryContainers);$i=0
  foreach($root in $roots){
    $rootPath=[string](Get-UncannyObjectValue $root 'Path' '')
    $rootTrusted=[bool](Get-UncannyObjectValue $root 'Trusted' $false)
    if(!$rootPath){continue}
    $i++;Invoke-UncannyProgress $Progress ('Checking game folders: '+$rootPath) (50+[int](36*$i/[Math]::Max(1,$roots.Count)))
    try{
      foreach($dir in Get-ChildItem -LiteralPath $rootPath -Directory -Force -ErrorAction SilentlyContinue){
        if($dir.Name -match '^(?i)(Windows|Program Files|Program Files \(x86\)|ProgramData|Users|PerfLogs|Recovery|System Volume Information|\$Recycle\.Bin|AMD|NVIDIA|Drivers|Tools|Tool|SDK|Source|Sources|Projects|Development|Dev|Build|Builds|Downloads|Documents|OneDrive|GitHub|Repos|Repositories|ProgramData)$'){continue}
        if(!$rootTrusted -and !(Test-UncannyGameSignature $dir.FullName)){continue}
        $key=$dir.FullName.ToLowerInvariant();if($seen.ContainsKey($key)){continue};$seen[$key]=$true
        $exe=Select-UncannyPrimaryExe $dir.FullName $dir.Name $rootTrusted 5
        if($exe){$out.Add([pscustomobject]@{Name=(Get-UncannyFriendlyName $exe.FullName $dir.Name);File=$exe;Source='Discovered'})}
      }
    }catch{}
  }
  return @($out)
}
function Get-UncannyRegisteredGameInstalls([scriptblock]$Progress){
  $out=[Collections.Generic.List[object]]::new();$seen=@{}
  $roots=@('HKLM:\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Uninstall','HKLM:\\SOFTWARE\\WOW6432Node\\Microsoft\\Windows\\CurrentVersion\\Uninstall','HKCU:\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Uninstall')
  $publishers='(?i)(Electronic Arts|EA Games|Ubisoft|Rockstar Games|CD PROJEKT|Bethesda|2K|SEGA|CAPCOM|BANDAI NAMCO|Square Enix|Konami|Activision|Blizzard|THQ|Deep Silver|Gearbox|505 Games|Paradox|Take-Two|Warner Bros|WB Games|Koei Tecmo|Nacon|Focus Entertainment)'
  foreach($reg in $roots){
    if(!(Test-Path $reg)){continue}
    foreach($key in Get-ChildItem $reg -ErrorAction SilentlyContinue){
      try{
        $p=Get-ItemProperty $key.PSPath -ErrorAction Stop;$name=[string]$p.DisplayName;$dir=[string]$p.InstallLocation;$publisher=[string]$p.Publisher
        if(!$name -or !$dir -or !(Test-Path -LiteralPath $dir -PathType Container)){continue}
        if($name -match '(?i)(launcher|connect|desktop|sdk|tool|benchmark|editor|runtime|redistributable|anti.?cheat|social club|rockstar games launcher|ubisoft connect|ea app)'){continue}
        $gameishPath=$dir -match '(?i)\\(Games|PC Games|Installed Games|SteamRip|SteamLibrary\\steamapps\\common|steamapps\\common|Epic Games|GOG Games|XboxGames|EA Games|Origin Games|Ubisoft Game Launcher\\games)\\'
        $hasSignature=Test-UncannyGameSignature $dir
        if($publisher -notmatch $publishers -and !$gameishPath -and !$hasSignature){continue}
        $dk=$dir.ToLowerInvariant();if($seen.ContainsKey($dk)){continue}
        $exe=Select-UncannyPrimaryExe $dir $name $true 5;if(!$exe){continue};$seen[$dk]=$true
        $out.Add([pscustomobject]@{Name=$name;File=$exe;Source='Registered'})
      }catch{}
    }
  }
  return @($out)
}
function Get-UncannyRegisteredEmulatorCandidates{
  $out=[Collections.Generic.List[object]]::new();$seen=@{}
  function Add-Candidate([string]$Path,[string]$Source='Registered Emulator'){
    if(!$Path){return};$clean=$Path.Trim().Trim('"')
    if($clean -match '^"([^"]+\.exe)"'){$clean=$Matches[1]}elseif($clean -match '^([^,]+\.exe)\s*,'){$clean=$Matches[1]}
    if(!(Test-Path -LiteralPath $clean -PathType Leaf)){return}
    $full=Resolve-UncannyExistingFilePath $clean;if(!$full){return}
    $family=Get-UncannyEmulatorIdentity $full;if(!$family){return};$k=$full.ToLowerInvariant();if($seen.ContainsKey($k)){return};$seen[$k]=$true
    $out.Add([pscustomobject]@{Name=(Get-UncannyFriendlyName $full $family);File=(Get-Item -LiteralPath $full);Source=$Source;Family=$family})
  }
  foreach($reg in @('HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\App Paths','HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\App Paths','HKLM:\SOFTWARE\WOW6432Node\Microsoft\Windows\CurrentVersion\App Paths')){
    if(!(Test-Path $reg)){continue}
    foreach($key in Get-ChildItem $reg -ErrorAction SilentlyContinue){try{$item=Get-Item $key.PSPath -ErrorAction Stop;$v=[string]$item.GetValue('');if($v){Add-Candidate $v 'App Paths'}}catch{}}
  }
  $emuName='(?i)(PCSX2|Dolphin|RPCS3|PPSSPP|Cemu|Xenia|RetroArch|DuckStation|Ryujinx|Yuzu|Citron|Suyu|Azahar|Lime3DS|Citra|melonDS|DeSmuME|Project64|BizHawk|redream|Flycast|shadPS4|Vita3K|xemu|Cxbx|MAME|ares|mGBA|VisualBoyAdvance|Snes9x|FCEUX|Mesen|Mednafen|Kronos|Yabause|DOSBox|ScummVM)'
  foreach($reg in @('HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall','HKLM:\SOFTWARE\WOW6432Node\Microsoft\Windows\CurrentVersion\Uninstall','HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall')){
    if(!(Test-Path $reg)){continue}
    foreach($key in Get-ChildItem $reg -ErrorAction SilentlyContinue){
      try{
        $x=Get-ItemProperty $key.PSPath -ErrorAction Stop;$display=[string]$x.DisplayName;if(!$display -or $display -notmatch $emuName){continue}
        if($x.DisplayIcon){Add-Candidate ([string]$x.DisplayIcon) 'Installed Emulator'}
        $dir=[string]$x.InstallLocation;if($dir -and (Test-Path -LiteralPath $dir -PathType Container)){
          Get-ChildItem -LiteralPath $dir -Filter '*.exe' -File -Recurse -Depth 2 -ErrorAction SilentlyContinue|ForEach-Object{if(Test-UncannyEmulatorExe $_.FullName){Add-Candidate $_.FullName 'Installed Emulator'}}
        }
      }catch{}
    }
  }
  return @($out)
}
function Get-UncannyShortcutCandidates([scriptblock]$Progress){
  $out=[Collections.Generic.List[object]]::new();$seen=@{}
  $roots=@(
    (Join-Path $env:APPDATA 'Microsoft\Windows\Start Menu\Programs'),
    (Join-Path $env:ProgramData 'Microsoft\Windows\Start Menu\Programs'),
    (Join-Path $env:USERPROFILE 'Desktop'),
    (Join-Path $env:PUBLIC 'Desktop')
  )|Where-Object{$_ -and (Test-Path -LiteralPath $_ -PathType Container)}|Select-Object -Unique
  $shell=$null;try{$shell=New-Object -ComObject WScript.Shell}catch{return @()}
  foreach($root in $roots){
    try{
      Get-ChildItem -LiteralPath $root -Filter '*.lnk' -File -Recurse -Depth 5 -ErrorAction SilentlyContinue|ForEach-Object{
        try{
          $sc=$shell.CreateShortcut($_.FullName);$target=[string]$sc.TargetPath
          if(!$target -or [IO.Path]::GetExtension($target) -ine '.exe' -or !(Test-Path -LiteralPath $target -PathType Leaf)){return}
          $fi=Get-Item -LiteralPath $target -Force;if(Test-UncannyHelperExe $fi){return}
          $dir=Split-Path -Parent $target
          $isEmu=Test-UncannyEmulatorExe $fi.FullName
          $gameish=$target -match '(?i)\\(steamapps\\common|SteamLibrary|Epic Games|GOG Games|XboxGames|EA Games|Origin Games|Ubisoft Game Launcher\\games|Games|PC Games|Installed Games|SteamRip)\\'
          if(!$isEmu -and !$gameish -and !(Test-UncannyGameSignature $dir)){return}
          $k=$target.ToLowerInvariant();if($seen.ContainsKey($k)){return};$seen[$k]=$true
          $fallback=[IO.Path]::GetFileNameWithoutExtension($_.Name)
          $out.Add([pscustomobject]@{Name=(Get-UncannyFriendlyName $target $fallback);File=$fi;Source='Shortcut';Kind=$(if($isEmu){'Emulator'}else{'Game'})})
        }catch{}
      }
    }catch{}
  }
  try{[Runtime.InteropServices.Marshal]::FinalReleaseComObject($shell)|Out-Null}catch{}
  return @($out)
}
function Get-UncannyGameLibrary([scriptblock]$Progress){
  $games=[Collections.Generic.List[object]]::new();$seen=@{}
  function Add-Game([string]$Name,[string]$Exe,[string]$Source,[string]$Cover='',[string]$Kind='Game',[bool]$AuthoritativeManual=$false){
    if(!$Exe -or !(Test-Path -LiteralPath $Exe -PathType Leaf)){return}
    $full=Resolve-UncannyExistingFilePath $Exe;if(!$full){return};try{$fi=Get-Item -LiteralPath $full -Force -ErrorAction Stop}catch{return}
    $installed=Test-UncannyInstalled $full
    if(!$installed -and (Test-UncannyInternalExe $fi)){return}
    if(!$installed -and !$AuthoritativeManual -and (Test-UncannyHelperExe $fi)){return}
    $key=$full.ToLowerInvariant();if($seen.ContainsKey($key)){return};$seen[$key]=$true
    $family=Get-UncannyEmulatorIdentity $full;if($family){$Kind='Emulator'}
    if(!$Name){$Name=if($family){$family}else{[IO.Path]::GetFileNameWithoutExtension($full)}}
    if($family -eq 'PCSX2' -and ($Name -match '(?i)^(pcsx2[-_ ]?(qt|avx2|sse4)?|uncanny.*)$')){$Name='PCSX2'}
    if(!$Cover){$Cover=Get-UncannyExeCover $full}
    $games.Add([pscustomobject]@{Name=$Name;Exe=$full;Source=$Source;Kind=$Kind;EmulatorFamily=$family;Cover=$Cover;Installed=$installed;InstalledRevision=(Get-UncannyInstallRevision $full);InstalledBuildId=(Get-UncannyInstallBuildId $full);Directory=(Split-Path $full -Parent)})
  }
  Invoke-UncannyProgress $Progress 'Reading Steam...' 5
  $steamRoots=[Collections.Generic.List[string]]::new();foreach($r in @("${env:ProgramFiles(x86)}\Steam","$env:ProgramFiles\Steam")){if($r -and (Test-Path -LiteralPath $r)){$steamRoots.Add($r)}}
  foreach($steamRoot in @($steamRoots)){
    $vdf=Join-Path $steamRoot 'steamapps\libraryfolders.vdf';$libs=@($steamRoot)
    if(Test-Path -LiteralPath $vdf){$raw=Get-Content -LiteralPath $vdf -Raw -ErrorAction SilentlyContinue;[regex]::Matches($raw,'"path"\s+"([^"]+)"')|ForEach-Object{$libs+=($_.Groups[1].Value -replace '\\\\','\')}}
    foreach($lib in ($libs|Select-Object -Unique)){
      $steamapps=Join-Path $lib 'steamapps';if(!(Test-Path -LiteralPath $steamapps)){continue}
      Get-ChildItem -LiteralPath $steamapps -Filter 'appmanifest_*.acf' -File -ErrorAction SilentlyContinue|ForEach-Object{
        try{
          $raw=Get-Content -LiteralPath $_.FullName -Raw;$n=[regex]::Match($raw,'"name"\s+"([^"]+)"').Groups[1].Value;$d=[regex]::Match($raw,'"installdir"\s+"([^"]+)"').Groups[1].Value;$id=[regex]::Match($raw,'"appid"\s+"([^"]+)"').Groups[1].Value
          if(!$n -or $n -match '(?i)(dedicated server|sdk|soundtrack|test server|benchmark|editor|tool)'){return}
          $dir=Join-Path $lib "steamapps\common\$d";$exe=Select-UncannyPrimaryExe $dir $n $true 5;if(!$exe){return}
          $cover='';$grid=Join-Path $steamRoot "appcache\librarycache\$id";if(Test-Path -LiteralPath $grid){$imgs=@(Get-ChildItem -LiteralPath $grid -File -ErrorAction SilentlyContinue|Where-Object{$_.Extension -match '(?i)\.(jpg|jpeg|png)$'});if($imgs.Count){$cover=($imgs|Sort-Object @{Expression={if($_.Name -match '(?i)(600x900|library|portrait)'){0}elseif($_.Name -match '(?i)(header|hero)'){1}else{2}}},Length|Select-Object -First 1).FullName}}
          Add-Game $n $exe.FullName 'Steam' $cover 'Game'
        }catch{}
      }
    }
  }
  Invoke-UncannyProgress $Progress 'Reading Epic Games...' 15
  $epic="$env:ProgramData\Epic\EpicGamesLauncher\Data\Manifests";if(Test-Path -LiteralPath $epic){Get-ChildItem -LiteralPath $epic -Filter '*.item' -File -ErrorAction SilentlyContinue|ForEach-Object{try{$j=Get-Content -LiteralPath $_.FullName -Raw|ConvertFrom-Json;if($j.InstallLocation -and $j.LaunchExecutable -and $j.DisplayName -and $j.DisplayName -notmatch '(?i)(\bcontent\b|dedicated server|editor|tools|prerequisite)'){$exe=Join-Path $j.InstallLocation $j.LaunchExecutable;if(Test-Path -LiteralPath $exe){$fi=Get-Item -LiteralPath $exe;if(!(Test-UncannyHelperExe $fi)){Add-Game $j.DisplayName $exe 'Epic' '' 'Game'}else{$best=Select-UncannyPrimaryExe $j.InstallLocation $j.DisplayName $true 5;if($best){Add-Game $j.DisplayName $best.FullName 'Epic' '' 'Game'}}}}}catch{}}}
  Invoke-UncannyProgress $Progress 'Reading GOG...' 23
  foreach($regRoot in @('HKLM:\SOFTWARE\WOW6432Node\GOG.com\Games','HKLM:\SOFTWARE\GOG.com\Games','HKCU:\SOFTWARE\GOG.com\Games')){
    if(!(Test-Path $regRoot)){continue};Get-ChildItem $regRoot -ErrorAction SilentlyContinue|ForEach-Object{try{$p=Get-ItemProperty $_.PSPath;$base=$p.path;$exe=$p.exe;if($base -and $exe){$candidate=if([IO.Path]::IsPathRooted($exe)){$exe}else{Join-Path $base $exe};if(Test-Path -LiteralPath $candidate){$fi=Get-Item -LiteralPath $candidate;if(!(Test-UncannyHelperExe $fi)){Add-Game $p.gameName $candidate 'GOG' '' 'Game'}else{$best=Select-UncannyPrimaryExe $base $p.gameName $true 5;if($best){Add-Game $p.gameName $best.FullName 'GOG' '' 'Game'}}}}}catch{}}
  }
  Invoke-UncannyProgress $Progress 'Reading registered game installs...' 28
  foreach($c in @(Get-UncannyRegisteredGameInstalls $Progress)){Add-Game $c.Name $c.File.FullName $c.Source '' 'Game'}
  Invoke-UncannyProgress $Progress 'Reading game shortcuts...' 32
  foreach($c in @(Get-UncannyShortcutCandidates $Progress)){Add-Game $c.Name $c.File.FullName $c.Source '' $c.Kind}
  Invoke-UncannyProgress $Progress 'Finding emulators...' 36
  try{Get-CimInstance Win32_Process -ErrorAction SilentlyContinue|Where-Object{$_.ExecutablePath -and (Test-UncannyEmulatorExe $_.ExecutablePath)}|ForEach-Object{if(Test-Path -LiteralPath $_.ExecutablePath){$fam=Get-UncannyEmulatorIdentity $_.ExecutablePath;Add-Game (Get-UncannyFriendlyName $_.ExecutablePath $fam) $_.ExecutablePath 'Running Emulator' '' 'Emulator'}}}catch{}
  foreach($c in @(Get-UncannyRegisteredEmulatorCandidates)){Add-Game $c.Name $c.File.FullName $c.Source '' 'Emulator'}
  foreach($drive in [IO.DriveInfo]::GetDrives()){
    if(!$drive.IsReady -or $drive.DriveType -ne [IO.DriveType]::Fixed){continue}
    foreach($rel in @('PCSX2\pcsx2-qt.exe','PCSX2RM\pcsx2-qt.exe','PCSX2-Remaster\pcsx2-qt.exe','Emulators\PCSX2\pcsx2-qt.exe','Emulation\PCSX2\pcsx2-qt.exe')){
      $candidate=Join-Path $drive.RootDirectory.FullName $rel;if(Test-Path -LiteralPath $candidate -PathType Leaf){Add-Game (Get-UncannyFriendlyName $candidate 'PCSX2') $candidate 'PCSX2 Fast Path' '' 'Emulator'}
    }
  }
  $emuRoots=[Collections.Generic.List[object]]::new()
  function Add-EmuRoot([string]$Path,[int]$Depth=3,[bool]$Broad=$false){if($Path -and (Test-Path -LiteralPath $Path -PathType Container)){$emuRoots.Add([pscustomobject]@{Path=$Path;Depth=$Depth;Broad=$Broad})}}
  foreach($remember in @((Join-Path $env:LOCALAPPDATA 'UNCANNY\library-cache.json'),(Join-Path $env:LOCALAPPDATA 'UNCANNY\library.json'))){
    if(Test-Path -LiteralPath $remember -PathType Leaf){try{@(Get-Content -LiteralPath $remember -Raw|ConvertFrom-Json)|ForEach-Object{$rememberExe=[string](Get-UncannyObjectValue $_ 'Exe' '');$rememberKind=[string](Get-UncannyObjectValue $_ 'Kind' '');if($rememberExe -and (Test-Path -LiteralPath $rememberExe -PathType Leaf) -and (($rememberKind -eq 'Emulator') -or (Test-UncannyEmulatorExe $rememberExe))){Add-EmuRoot (Split-Path -Parent $rememberExe) 2 $true}}}catch{}}
  }
  foreach($base in @((Join-Path $env:USERPROFILE 'Desktop'),(Join-Path $env:USERPROFILE 'Downloads'),(Join-Path $env:USERPROFILE 'Documents'),"$env:LOCALAPPDATA\Programs")){Add-EmuRoot $base 2 $true}
  foreach($quick in @(
    (Join-Path $env:USERPROFILE 'PCSX2'),(Join-Path $env:USERPROFILE 'PCSX2RM'),(Join-Path $env:USERPROFILE 'PCSX2-Remaster'),
    (Join-Path $env:USERPROFILE 'Documents\PCSX2'),(Join-Path $env:USERPROFILE 'Downloads\PCSX2'),(Join-Path $env:USERPROFILE 'Desktop\PCSX2'),
    (Join-Path $env:LOCALAPPDATA 'PCSX2'),(Join-Path $env:APPDATA 'PCSX2'),
    (Join-Path $env:USERPROFILE 'Emulators'),(Join-Path $env:USERPROFILE 'Emulation'),(Join-Path $env:USERPROFILE 'Documents\Emulators'),(Join-Path $env:USERPROFILE 'Documents\Emulation')
  )){Add-EmuRoot $quick 4 $true}
  foreach($container in @(Get-UncannyDiscoveryContainers)){
    $containerPath=[string](Get-UncannyObjectValue $container 'Path' '')
    $containerTrusted=[bool](Get-UncannyObjectValue $container 'Trusted' $false)
    if($containerPath -and ($containerTrusted -or $containerPath -match '(?i)emulat|retroarch|launchbox|retrobat')){Add-EmuRoot $containerPath 3 $false}
  }
  foreach($drive in [IO.DriveInfo]::GetDrives()){
    if(!$drive.IsReady -or $drive.DriveType -ne [IO.DriveType]::Fixed){continue}
    foreach($rel in @('PCSX2','PCSX2RM','PCSX2-Remaster','Emulators','Emulator','Emulation','EMU','LaunchBox\Emulators','RetroBat\emulators','Games\Emulators','Games\Emulation')){Add-EmuRoot (Join-Path $drive.RootDirectory.FullName $rel) 4 $true}
    try{Get-ChildItem -LiteralPath $drive.RootDirectory.FullName -Directory -Force -ErrorAction SilentlyContinue|Where-Object{$_.Name -match '(?i)(PCSX2|PCSX2RM|PCSX2[-_ ]?Remaster|Dolphin|RPCS3|PPSSPP|Cemu|Xenia|RetroArch|DuckStation|Ryujinx|Citra|Azahar|melonDS|Project64|MAME|Vita3K|xemu|shadPS4|Emulators?|Emulation)'}|ForEach-Object{Add-EmuRoot $_.FullName 4 $true}}catch{}
  }
  foreach($pf in @("$env:ProgramFiles","${env:ProgramFiles(x86)}")){if($pf -and (Test-Path -LiteralPath $pf)){try{Get-ChildItem -LiteralPath $pf -Directory -ErrorAction SilentlyContinue|Where-Object{$_.Name -match '(?i)(PCSX2|Dolphin|RPCS3|PPSSPP|Cemu|Xenia|RetroArch|DuckStation|Ryujinx|Citra|Azahar|melonDS|Project64|MAME|Vita3K|xemu|shadPS4)'}|ForEach-Object{Add-EmuRoot $_.FullName 3 $true}}catch{}}}
  $emuRootSeen=@{}
  foreach($entry in @($emuRoots|Sort-Object Path,Depth -Unique)){
    $entryPath=[string](Get-UncannyObjectValue $entry 'Path' '')
    $entryDepth=[int](Get-UncannyObjectValue $entry 'Depth' 3)
    if(!$entryPath){continue}
    $rk=$entryPath.TrimEnd('\').ToLowerInvariant();if($emuRootSeen.ContainsKey($rk)){continue};$emuRootSeen[$rk]=$true
    try{
      Get-ChildItem -LiteralPath $entryPath -Filter '*.exe' -File -Recurse -Depth $entryDepth -ErrorAction SilentlyContinue|ForEach-Object{
        if($_.Name -match '(?i)^(setup|install|unins|update|updater|crash|report|helper|launcher|bootstrap).*\.exe$' -and $_.DirectoryName -notmatch '(?i)(pcsx2|emulat|dolphin|rpcs3|ppsspp|cemu|xenia|retroarch|duckstation)'){return}
        $fam=Get-UncannyEmulatorIdentity $_.FullName;if(!$fam){return}
        Add-Game (Get-UncannyFriendlyName $_.FullName $fam) $_.FullName 'Emulator' '' 'Emulator'
      }
    }catch{}
  }
  Invoke-UncannyProgress $Progress 'Loading added games...' 44
  $custom=Join-Path $env:LOCALAPPDATA 'UNCANNY\library.json';if(Test-Path -LiteralPath $custom){try{@(Get-Content -LiteralPath $custom -Raw|ConvertFrom-Json)|ForEach-Object{
    $manualExe=[string](Get-UncannyObjectValue $_ 'Exe' '')
    if($manualExe -and (Test-Path -LiteralPath $manualExe)){
      $manualName=[string](Get-UncannyObjectValue $_ 'Name' '')
      $fallback=if($manualName){$manualName}else{[IO.Path]::GetFileNameWithoutExtension($manualExe)}
      Add-Game (Get-UncannyFriendlyName $manualExe $fallback) $manualExe 'Added' '' $(if(Test-UncannyEmulatorExe $manualExe){'Emulator'}else{'Game'}) $true
    }
  }}catch{}}
  Invoke-UncannyProgress $Progress 'Finding portable games...' 52
  foreach($c in @(Get-UncannyPortableCandidates $Progress)){Add-Game $c.Name $c.File.FullName $c.Source '' $(if(Test-UncannyEmulatorExe $c.File.FullName){'Emulator'}else{'Game'})}
  Invoke-UncannyProgress $Progress 'Cleaning library...' 91
  $sourceRank=@{Steam=0;Epic=1;GOG=2;Registered=3;'PCSX2 Fast Path'=4;'Running Emulator'=4;'App Paths'=4;'Installed Emulator'=4;Shortcut=5;Emulator=6;Added=7;Discovered=8}
  $result=@($games|Sort-Object @{Expression={if($_.Installed){0}else{1}}},@{Expression={if($_.Kind -eq 'Emulator' -and $_.EmulatorFamily -eq 'PCSX2' -and [IO.Path]::GetFileName($_.Exe) -ieq 'pcsx2-qt.exe'){0}else{1}}},@{Expression={if($sourceRank.ContainsKey($_.Source)){$sourceRank[$_.Source]}else{9}}},Name,Exe)
  $dedup=[Collections.Generic.List[object]]::new();$dirKeys=@{}
  foreach($g in $result){
    if($g.Kind -eq 'Emulator' -and $g.EmulatorFamily){$dk=('emu|'+$g.EmulatorFamily.ToLowerInvariant()+'|'+$g.Directory.TrimEnd('\').ToLowerInvariant())}
    else{$dk=($g.Directory.TrimEnd('\').ToLowerInvariant()+'|'+(ConvertTo-UncannyKey $g.Name))}
    if($dirKeys.ContainsKey($dk)){continue};$dirKeys[$dk]=$true;$dedup.Add($g)
  }
  $result=@($dedup|Sort-Object Name,Exe)
  $pcsx2=@($result|Where-Object{$_.Kind -eq 'Emulator' -and $_.EmulatorFamily -eq 'PCSX2'})
  if($pcsx2.Count -gt 1){foreach($item in $pcsx2){$item|Add-Member -NotePropertyName DuplicateInstallCount -NotePropertyValue $pcsx2.Count -Force}}
  else{foreach($item in $pcsx2){$item|Add-Member -NotePropertyName DuplicateInstallCount -NotePropertyValue 1 -Force}}
  try{$cacheDir=Join-Path $env:LOCALAPPDATA 'UNCANNY';New-Item -ItemType Directory -Force -Path $cacheDir|Out-Null;$result|Select-Object Name,Exe,Source,Kind,EmulatorFamily,Cover,Installed,Directory,DuplicateInstallCount|ConvertTo-Json -Depth 4|Set-Content -LiteralPath (Join-Path $cacheDir 'library-cache.json') -Encoding UTF8}catch{}
  Invoke-UncannyProgress $Progress ("Library ready - "+$result.Count+" games and emulators.") 100
  return $result
}
function Get-UncannyLibraryEntryExe($Entry){
  if($null -eq $Entry){return ''}
  if($Entry -is [string]){return ([string]$Entry).Trim()}
  try{
    foreach($key in @('Exe','Path','File','Executable','Target')){
      $prop=$Entry.PSObject.Properties[$key]
      if($null -ne $prop -and $null -ne $prop.Value){
        $value=([string]$prop.Value).Trim()
        if($value){return $value}
      }
    }
  }catch{}
  return ''
}
function Get-UncannyLibraryEntryName($Entry,[string]$Fallback=''){
  if($null -eq $Entry){return $Fallback}
  try{
    $prop=$Entry.PSObject.Properties['Name']
    if($null -ne $prop -and $null -ne $prop.Value){
      $value=([string]$prop.Value).Trim()
      if($value){return $value}
    }
  }catch{}
  return $Fallback
}
function Resolve-UncannyManualLibraryPath([string]$Value){
  $full=[IO.Path]::GetFullPath($Value)
  if(Test-Path -LiteralPath $full -PathType Leaf){
    $resolved=Resolve-UncannyExistingFilePath $full
    if(!$resolved){throw 'Executable path could not be resolved.'}
    $full=$resolved
  }
  return [IO.Path]::GetFullPath($full)
}
function Add-UncannyLibraryTarget([string]$Exe){
  $path=Resolve-UncannyManualLibraryPath $Exe
  if([IO.Path]::GetExtension($path) -ine '.exe'){throw 'Choose a Windows game or emulator executable.'}
  $f=Join-Path $env:LOCALAPPDATA 'UNCANNY\library.json';$folder=Split-Path $f -Parent;New-Item -ItemType Directory -Force -Path $folder|Out-Null
  $existing=@()
  if(Test-Path -LiteralPath $f -PathType Leaf){
    try{$parsed=Get-Content -LiteralPath $f -Raw|ConvertFrom-Json;$existing=@($parsed)}catch{$existing=@()}
  }
  $clean=[Collections.Generic.List[object]]::new()
  foreach($entry in @($existing)){
    $entryExe=Get-UncannyLibraryEntryExe $entry
    if(!$entryExe){continue}
    try{
      $candidate=Resolve-UncannyManualLibraryPath $entryExe
      $duplicate=$false
      foreach($kept in @($clean)){
        if([string]::Equals([string]$kept.Exe,$candidate,[StringComparison]::OrdinalIgnoreCase)){$duplicate=$true;break}
      }
      if($duplicate){continue}
      $name=Get-UncannyLibraryEntryName $entry
      if(!$name){$name=Get-UncannyFriendlyName $candidate ([IO.Path]::GetFileNameWithoutExtension($candidate))}
      $clean.Add([pscustomobject]@{Name=$name;Exe=$candidate})
    }catch{}
  }
  $targetExists=$false
  foreach($kept in @($clean)){
    if([string]::Equals([string]$kept.Exe,$path,[StringComparison]::OrdinalIgnoreCase)){$targetExists=$true;break}
  }
  if(!$targetExists){$clean.Add([pscustomobject]@{Name=(Get-UncannyFriendlyName $path ([IO.Path]::GetFileNameWithoutExtension($path)));Exe=$path})}
  $json=ConvertTo-Json -InputObject @($clean) -Depth 4
  Write-UncannyJsonAtomic $f $json
}
