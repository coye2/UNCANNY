﻿Set-StrictMode -Version Latest
function Get-UncannyProviderInfo([string]$Path) {
  Assert-UncannyNoReparsePath $Path
  $f=Get-Item -LiteralPath $Path -ErrorAction Stop
  if($f.Length -lt 256 -or $f.Length -gt 536870912){throw 'Provider size outside safety bounds.'}
  $b=[IO.File]::ReadAllBytes($f.FullName)
  function U16([long]$o){if($o -lt 0 -or $o+2 -gt $b.LongLength){throw 'Truncated PE.'};[BitConverter]::ToUInt16($b,[int]$o)}
  function U32([long]$o){if($o -lt 0 -or $o+4 -gt $b.LongLength){throw 'Truncated PE.'};[BitConverter]::ToUInt32($b,[int]$o)}
  $pe=[long](U32 60)
  if((U16 0) -ne 23117 -or $pe -lt 64 -or (U32 $pe) -ne 17744){throw 'Not a Windows PE DLL.'}
  $machine=U16 ($pe+4);$count=U16 ($pe+6);$opt=$pe+24;$optSize=U16 ($pe+20);$magic=U16 $opt
  if($count -lt 1 -or $count -gt 96 -or !((U16 ($pe+22)) -band 8192)){throw 'Invalid DLL header.'}
  $arch=if($machine -eq 34404 -and $magic -eq 523){'64'}elseif($machine -eq 332 -and $magic -eq 267){'32'}else{throw 'Unsupported PE architecture.'}
  $dir=if($arch -eq '64'){112}else{96};$sections=$opt+$optSize
  if($optSize -lt $dir+8 -or $sections+$count*40 -gt $b.LongLength){throw 'Invalid section table.'}
  function Rva([long]$address,[long]$length){
    for($i=0;$i -lt $count;$i++){$s=$sections+$i*40;$start=[long](U32 ($s+12));$raw=[long](U32 ($s+20));$size=[long](U32 ($s+16))
      if($address -ge $start -and $address-$start+$length -le $size -and $raw+$address-$start+$length -le $b.LongLength){return ($raw+$address-$start)}
    };throw 'Invalid export address.'
  }
  $ep=Rva (U32 ($opt+$dir)) 40;$n=[long](U32 ($ep+24));if($n -lt 1 -or $n -gt 65536){throw 'Invalid export count.'}
  $table=Rva (U32 ($ep+32)) ($n*4);$exports=[Collections.Generic.HashSet[string]]::new([StringComparer]::Ordinal)
  for($i=0;$i -lt $n;$i++){$at=Rva (U32 ($table+$i*4)) 1;$end=$at
    while($end -lt $b.LongLength -and $end-$at -lt 256 -and $b[$end] -ne 0){$end++}
    if($end -ge $b.LongLength -or $end-$at -ge 256){throw 'Unterminated PE export.'}
    $null=$exports.Add([Text.Encoding]::ASCII.GetString($b,[int]$at,[int]($end-$at)))
  }
  $nr=@('NVSDK_NGX_D3D12_Init_Ext','NVSDK_NGX_D3D12_CreateFeature','NVSDK_NGX_D3D12_EvaluateFeature','NVSDK_NGX_D3D12_ReleaseFeature')
  $core=@('NVSDK_NGX_D3D12_AllocateParameters','NVSDK_NGX_D3D12_DestroyParameters','NVSDK_NGX_D3D12_CreateFeature','NVSDK_NGX_D3D12_EvaluateFeature','NVSDK_NGX_D3D12_ReleaseFeature')
  $isNr=@($nr|Where-Object{!$exports.Contains($_)}).Count -eq 0
  $isCore=@($core|Where-Object{!$exports.Contains($_)}).Count -eq 0
  $role=if($isCore){'Core'}elseif($isNr -and $f.Name -match 'dlssnr'){'Rendering'}else{'Other'}
  $hasher=[Security.Cryptography.SHA256]::Create()
  try{$digest=$hasher.ComputeHash($b);$sha=([BitConverter]::ToString($digest)).Replace('-','').ToLowerInvariant()}finally{$hasher.Dispose()}
  [pscustomobject]@{Path=$f.FullName;Architecture=$arch;Role=$role;SHA256=$sha;Version=$f.VersionInfo.FileVersion;Bytes=$f.Length}
}
function Get-UncannyProviderRoots([string]$TargetDir,[string]$Explicit='') {
  $roots=[Collections.Generic.List[string]]::new()
  foreach($p in @($Explicit,$TargetDir,(Join-Path $TargetDir '.uncanny/host64'))){if($p){$roots.Add($p)}}
  if($env:LOCALAPPDATA){
    $remember=Join-Path $env:LOCALAPPDATA 'UNCANNY/last-native-target.txt'
    try{
      if(Test-Path -LiteralPath $remember -PathType Leaf){
        $last=[IO.File]::ReadAllText($remember).Trim()
        if($last -and [IO.Path]::IsPathRooted($last)){
          $lastDir=if(Test-Path -LiteralPath $last -PathType Container){$last}else{Split-Path -Parent $last}
          if($lastDir){$roots.Add($lastDir);$roots.Add((Join-Path $lastDir '.uncanny/host64'))}
        }
      }
    }catch{}
  }
  foreach($base in @($env:LOCALAPPDATA,$env:APPDATA)) {if($base){foreach($p in @('UNCANNY','RHI','DLSS Swapper','DLSS5-Swapper','DLSS5Swapper')){$roots.Add((Join-Path $base $p))}}}
  if($env:WINDIR){$system=if([Environment]::Is64BitOperatingSystem -and ![Environment]::Is64BitProcess){'Sysnative'}else{'System32'}
    $roots.Add((Join-Path $env:WINDIR $system));$store=Join-Path $env:WINDIR "$system/DriverStore/FileRepository"
    if(Test-Path -LiteralPath $store){Get-ChildItem -LiteralPath $store -Directory -Filter 'nv*' -ErrorAction SilentlyContinue|ForEach-Object{$roots.Add($_.FullName)}}
  }
  if($env:OS -eq 'Windows_NT'){
    foreach($view in @([Microsoft.Win32.RegistryView]::Registry64,[Microsoft.Win32.RegistryView]::Registry32)){
      $hive=$null;$key=$null
      try{$hive=[Microsoft.Win32.RegistryKey]::OpenBaseKey([Microsoft.Win32.RegistryHive]::LocalMachine,$view);$key=$hive.OpenSubKey('SOFTWARE\NVIDIA Corporation\Global\NGXCore');if($key){foreach($name in $key.GetValueNames()){$v=$key.GetValue($name);if($v -is [string] -and [IO.Path]::IsPathRooted($v)){if([IO.Path]::GetExtension($v) -eq '.dll'){$v=Split-Path -Parent $v};$roots.Add($v)}}}}catch{}finally{if($key){$key.Dispose()};if($hive){$hive.Dispose()}}
    }
    foreach($reg in @('HKCU:\Software\Valve\Steam','HKLM:\SOFTWARE\WOW6432Node\Valve\Steam')){
      try{$k=Get-ItemProperty -LiteralPath $reg -ErrorAction Stop;$base=if($k.PSObject.Properties['SteamPath']){$k.SteamPath}else{$k.InstallPath}
        $roots.Add((Join-Path $base 'steamapps/common'));$vdf=Join-Path $base 'steamapps/libraryfolders.vdf'
        if(Test-Path -LiteralPath $vdf){$text=[IO.File]::ReadAllText($vdf);foreach($m in [regex]::Matches($text,'"path"\s+"([^"]+)"')){$roots.Add((Join-Path ($m.Groups[1].Value.Replace('\\','\')) 'steamapps/common'))}}
      }catch{}
    }
  }
  @($roots|Where-Object{$_ -and (Test-Path -LiteralPath $_ -PathType Container)}|Select-Object -Unique)
}
function Find-UncannyProviders([string[]]$Roots,[string]$Architecture='64',[int]$Seconds=10) {
  $watch=[Diagnostics.Stopwatch]::StartNew();$q=[Collections.Generic.Queue[object]]::new();$seen=[Collections.Generic.HashSet[string]]::new([StringComparer]::OrdinalIgnoreCase)
  $found=[Collections.Generic.List[object]]::new();$rejected=[Collections.Generic.List[object]]::new();$visited=0
  foreach($r in $Roots){$q.Enqueue([pscustomobject]@{Path=$r;Depth=0})}
  while($q.Count -and $watch.Elapsed.TotalSeconds -lt $Seconds -and $visited -lt 6000){$node=$q.Dequeue()
    try{Assert-UncannyNoReparsePath $node.Path;$full=[IO.Path]::GetFullPath($node.Path);if(!$seen.Add($full)){continue};$visited++
      foreach($f in Get-ChildItem -LiteralPath $full -File -Filter '*nvngx*.dll' -ErrorAction SilentlyContinue){
        if($watch.Elapsed.TotalSeconds -ge $Seconds){break}
        try{
          $v=Get-UncannyProviderInfo $f.FullName
          if($v.Architecture -eq $Architecture -and $v.Role -ne 'Other'){
            $found.Add($v)
            $hasRendering=@($found|Where-Object Role -eq 'Rendering').Count -gt 0
            $hasCore=@($found|Where-Object Role -eq 'Core').Count -gt 0
            if($hasRendering -and $hasCore){
              return [pscustomobject]@{Found=@($found.ToArray());Rejected=@($rejected.ToArray());Folders=$visited;Truncated=$true;ElapsedSeconds=$watch.Elapsed.TotalSeconds}
            }
          }else{
            if($rejected.Count -lt 128){$rejected.Add([pscustomobject]@{Path=$f.FullName;Reason="Role=$($v.Role), architecture=$($v.Architecture); need $Architecture-bit DLSS5 rendering/core, not Super Resolution/Ray Reconstruction."})}
          }
        }catch{if($rejected.Count -lt 128){$rejected.Add([pscustomobject]@{Path=$f.FullName;Reason=$_.Exception.Message})}}
      }
      $depthLimit=if($full -match '[\\/]Windows[\\/](System32|Sysnative)$'){0}else{5}
      if($node.Depth -lt $depthLimit){foreach($d in Get-ChildItem -LiteralPath $full -Directory -ErrorAction SilentlyContinue){if(!($d.Attributes -band [IO.FileAttributes]::ReparsePoint)){$q.Enqueue([pscustomobject]@{Path=$d.FullName;Depth=$node.Depth+1})}}}
    }catch{}
  }
  [pscustomobject]@{Found=@($found.ToArray());Rejected=@($rejected.ToArray());Folders=$visited;Truncated=($q.Count -gt 0);ElapsedSeconds=$watch.Elapsed.TotalSeconds}
}
function Receive-UncannyPinnedProvider([string]$Stage,[string]$Catalog) {
  $c=Get-Content -LiteralPath $Catalog -Raw|ConvertFrom-Json
  if($c.schema -ne 1 -or $c.sha256 -notmatch '^[a-f0-9]{64}$'){throw 'Invalid pinned provider catalog.'}
  $uri=[uri]$c.url
  if($uri.Scheme -ne 'https' -or $uri.Host -ne 'github.com' -or $uri.AbsolutePath -notlike '/RankFTW/rhi-repo/releases/download/*'){throw 'Untrusted provider download location.'}
  Write-Host "No local compatible rendering provider found. Downloading pinned $($c.version) from community RHI releases. NVIDIA driver core is never downloaded from a DLL mirror." -ForegroundColor Yellow
  Add-Type -AssemblyName System.Net.Http
  $handler=[Net.Http.HttpClientHandler]::new();$handler.AllowAutoRedirect=$false
  $client=[Net.Http.HttpClient]::new($handler);$client.Timeout=[TimeSpan]::FromSeconds(180);$client.DefaultRequestHeaders.UserAgent.ParseAdd('UNCANNY-Installer/0.20-ELYSIUM')
  $archive=Join-Path $Stage 'provider.download.zip';$response=$null
  try{
    for($redirect=0;$redirect -lt 5;$redirect++){
      $response=$client.GetAsync($uri,[Net.Http.HttpCompletionOption]::ResponseHeadersRead).GetAwaiter().GetResult()
      if([int]$response.StatusCode -ge 300 -and [int]$response.StatusCode -lt 400){$next=[uri]::new($uri,$response.Headers.Location);$response.Dispose();$response=$null
        if($next.Scheme -ne 'https' -or $next.Host -notin @('github.com','release-assets.githubusercontent.com','objects.githubusercontent.com')){throw 'Provider redirect left the permitted release hosts.'};$uri=$next;continue};break
    }
    if(!$response){throw 'Too many redirects.'};$null=$response.EnsureSuccessStatusCode()
    if($response.Content.Headers.ContentLength -gt 268435456){throw 'Provider archive exceeds size bound.'}
    $input=$response.Content.ReadAsStreamAsync().GetAwaiter().GetResult();$output=[IO.File]::Open($archive,[IO.FileMode]::CreateNew,[IO.FileAccess]::Write,[IO.FileShare]::None)
    $deadline=[Threading.CancellationTokenSource]::new(180000)
    try{$buf=New-Object byte[] 1048576;$total=0L
      while(($n=$input.ReadAsync($buf,0,$buf.Length,$deadline.Token).GetAwaiter().GetResult()) -gt 0){$total+=$n;if($total -gt 268435456){throw 'Download exceeded size bound.'};$output.Write($buf,0,$n)};$output.Flush($true)
    }finally{$output.Dispose();$input.Dispose();$deadline.Dispose()}
    if((Get-UncannySHA256 $archive) -ine $c.sha256){throw 'Provider archive hash mismatch: rejected without execution.'}
    Add-Type -AssemblyName System.IO.Compression.FileSystem;$zip=[IO.Compression.ZipFile]::OpenRead($archive)
    try{
      if($zip.Entries.Count -gt 256){throw 'Provider archive member limit exceeded.'}
      $matches=@($zip.Entries|Where-Object{[IO.Path]::GetFileName($_.FullName) -ieq 'nvngx_dlssnr.dll'})
      if($matches.Count -ne 1){throw 'Provider archive must contain exactly one DLSS5 rendering DLL.'}
      $entry=$matches[0];if($entry.Length -gt 536870912 -or $entry.Length -lt 256){throw 'Invalid uncompressed provider size.'}
      $dest=Join-Path $Stage 'nvngx_dlssnr.dll';[IO.Compression.ZipFileExtensions]::ExtractToFile($entry,$dest,$false)
    }finally{$zip.Dispose()}
    $info=Get-UncannyProviderInfo $dest
    if($info.Architecture -ne '64' -or $info.Role -ne 'Rendering'){throw 'Downloaded DLL does not match required x64 rendering exports.'}
    return $info
  }finally{if($response){$response.Dispose()};$client.Dispose();$handler.Dispose();Remove-Item -LiteralPath $archive -Force -ErrorAction SilentlyContinue}
}
function New-UncannyProviderPlan([string]$TargetDir,[string]$Stage,[string]$PackageRoot,[string]$Architecture,[string]$Explicit='', [bool]$AllowDownload=$true) {
  $providerArch='64';$destination=if($Architecture -eq '32'){Join-Path $TargetDir '.uncanny/host64'}else{$TargetDir}
  $priorState=$null;$reusePriorNegative=$false
  $priorReceipt=Join-Path $TargetDir '.uncanny/provider-state.json'
  if(!$Explicit -and (Test-Path -LiteralPath $priorReceipt -PathType Leaf)){
    try{
      $candidate=Get-Content -LiteralPath $priorReceipt -Raw|ConvertFrom-Json
      if($candidate.schema -eq 1 -and [string]$candidate.providerArchitecture -eq $providerArch -and [string]$candidate.targetArchitecture -eq $Architecture -and [string]$candidate.status -in @('NVIDIA_DRIVER_CORE_MISSING_UPDATE_DRIVER','RENDERING_PROVIDER_MISSING')){
        $priorState=$candidate
      }
    }catch{}
  }
  $quickRoots=@($Explicit,$TargetDir,(Join-Path $TargetDir '.uncanny/host64'))|Where-Object{$_ -and (Test-Path -LiteralPath $_ -PathType Container)}|Select-Object -Unique
  $quick=Find-UncannyProviders -Roots $quickRoots -Architecture $providerArch -Seconds 2
  $nr=@($quick.Found|Where-Object Role -eq 'Rendering')|Select-Object -First 1
  $core=@($quick.Found|Where-Object Role -eq 'Core')|Select-Object -First 1
  if($nr -and $core){$scan=$quick}
  elseif($priorState){
    $scan=$quick;$reusePriorNegative=$true
  }else{
    $scan=Find-UncannyProviders -Roots (Get-UncannyProviderRoots $TargetDir $Explicit) -Architecture $providerArch -Seconds 6
    if(!$nr){$nr=@($scan.Found|Where-Object Role -eq 'Rendering')|Select-Object -First 1}
    if(!$core){$core=@($scan.Found|Where-Object Role -eq 'Core')|Select-Object -First 1}
  }
  $errorText='';$downloaded=$false
  if(!$nr -and $AllowDownload -and !$reusePriorNegative){try{$nr=Receive-UncannyPinnedProvider $Stage (Join-Path $PackageRoot 'config/provider-catalog.json');$downloaded=$true}catch{$errorText=$_.Exception.Message;Write-Warning "Automatic DLSS5 download failed safely: $errorText"}}
  $changes=[Collections.Generic.List[object]]::new()
  foreach($pair in @(@($nr,'nvngx_dlssnr.dll'),@($core,'_nvngx.dll'))){$info=$pair[0];if(!$info){continue};$dest=Join-Path $destination $pair[1]
    if(Test-Path -LiteralPath $dest){
      Assert-UncannyNoReparsePath $dest
      $existing=$null
      try{$existing=Get-UncannyProviderInfo $dest}catch{}
      if($existing -and $existing.Architecture -eq $providerArch -and $existing.Role -eq $info.Role){
        $info=$existing
        if($info.Role -eq 'Rendering'){$nr=$existing}else{$core=$existing}
      }else{Write-Warning "Replacing incompatible provider with full installer backup: $dest"}
    }
    $changes.Add([pscustomobject]@{source=$info.Path;destination=$dest;sha256=$info.SHA256})
    if($Architecture -eq '64'){
      $isolated=Join-Path (Join-Path $TargetDir '.uncanny/host64') $pair[1]
      Assert-UncannyNoReparsePath $isolated
      $changes.Add([pscustomobject]@{source=$info.Path;destination=$isolated;sha256=$info.SHA256})
    }
  }
  $status=if($nr -and $core){'FILES_READY_INFERENCE_NOT_TESTED'}elseif($reusePriorNegative){[string]$priorState.status}elseif(!$core){'NVIDIA_DRIVER_CORE_MISSING_UPDATE_DRIVER'}else{'RENDERING_PROVIDER_MISSING'}
  [pscustomobject]@{schema=1;revision='release-alpha.1.elysium';targetArchitecture=$Architecture;providerArchitecture=$providerArch;route=$(if($Architecture -eq '32'){'x64-helper-experimental'}else{'native-in-process-plus-isolated-legacy-helper'});status=$status;rendering=$nr;core=$core;downloaded=$downloaded;downloadError=$errorText;searchTruncated=$scan.Truncated;rejected=$scan.Rejected;reusedPriorState=$reusePriorNegative;changes=@($changes.ToArray())}
}
