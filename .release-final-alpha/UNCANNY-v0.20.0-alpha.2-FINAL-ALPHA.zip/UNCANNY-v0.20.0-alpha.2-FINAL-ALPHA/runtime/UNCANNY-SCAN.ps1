﻿param([Parameter(Mandatory=$true)][string]$Root,[Parameter(Mandatory=$true)][string]$ResultFile,[Parameter(Mandatory=$true)][string]$ProgressFile)
$ErrorActionPreference='Stop';Set-StrictMode -Version Latest
$runtimeRoot=Split-Path -Parent $MyInvocation.MyCommand.Path
if(!$runtimeRoot -or !(Test-Path -LiteralPath $runtimeRoot -PathType Container)){throw 'UNCANNY scanner runtime directory could not be resolved.'}
. (Join-Path $runtimeRoot 'UNCANNY-InstallCommon.ps1')
. (Join-Path $runtimeRoot 'UNCANNY-Library.ps1')
function Progress([string]$stage,[int]$percent){[IO.File]::WriteAllText($ProgressFile,([Math]::Max(0,[Math]::Min(100,$percent))).ToString()+'|'+$stage,[Text.UTF8Encoding]::new($false))}
Progress 'Scanning known game libraries and emulators' 1
$items=@(Get-UncannyGameLibrary {param($stage,$percent) Progress $stage $percent})
$tmp=$ResultFile+'.tmp';$items|ConvertTo-Json -Depth 8|Set-Content -LiteralPath $tmp -Encoding UTF8;Move-Item -LiteralPath $tmp -Destination $ResultFile -Force
Progress 'Scan complete' 100
