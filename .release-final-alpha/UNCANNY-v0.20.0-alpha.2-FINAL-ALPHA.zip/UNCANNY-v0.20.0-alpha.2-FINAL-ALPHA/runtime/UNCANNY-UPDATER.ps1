﻿param(
  [ValidateSet('Check','Install')][string]$Mode='Check',
  [string]$ResultFile='',
  [string]$ProgressFile=''
)
Set-StrictMode -Version Latest
$ErrorActionPreference='Stop'
$root=[IO.Path]::GetFullPath($env:UNCANNY_PACKAGE_ROOT)
function Progress([int]$p,[string]$stage){if(!$ProgressFile){return};try{[IO.File]::WriteAllText($ProgressFile,([Math]::Max(0,[Math]::Min(100,$p))).ToString()+'|'+($stage -replace '[\r\n|]',' '),[Text.UTF8Encoding]::new($false))}catch{}}
function Write-Result($o){if($ResultFile){$o|ConvertTo-Json -Depth 8|Set-Content -LiteralPath $ResultFile -Encoding UTF8};return $o}
function Parse-Version([string]$text){
  $m=[regex]::Match($text,'(?i)v?(\d+)\.(\d+)\.(\d+)(?:[-+](.*))?')
  if(!$m.Success){return $null}
  $suffix=$m.Groups[4].Value.ToLowerInvariant();$rank=3
  if($suffix -match 'alpha'){$rank=0}elseif($suffix -match 'beta'){$rank=1}elseif($suffix -match 'rc'){$rank=2}
  $pre=0;$pm=[regex]::Match($suffix,'(?:rc|beta|alpha)[^0-9]*([0-9]+)');if($pm.Success){$pre=[int]$pm.Groups[1].Value}
  return [pscustomobject]@{Major=[int]$m.Groups[1].Value;Minor=[int]$m.Groups[2].Value;Patch=[int]$m.Groups[3].Value;Rank=$rank;Pre=$pre}
}
function Compare-Version($a,$b){foreach($k in @('Major','Minor','Patch','Rank','Pre')){if($a.$k -lt $b.$k){return -1};if($a.$k -gt $b.$k){return 1}};return 0}
function Get-HotfixSerial([string]$text){
  $m=[regex]::Match($text,'(?i)(?:hotfix|hf)\s*([0-9]+)(?:\.([0-9]+))?')
  if(!$m.Success){return 0}
  $minor=if($m.Groups[2].Success){[int]$m.Groups[2].Value}else{0}
  return ([int]$m.Groups[1].Value*100)+($minor*10)
}
Progress 5 'Checking official UNCANNY releases'
$config=Get-Content -LiteralPath (Join-Path $root 'config\updater.json') -Raw|ConvertFrom-Json
$current=Get-Content -LiteralPath (Join-Path $root 'VERSION.json') -Raw|ConvertFrom-Json
$packageMetaPath=Join-Path $root 'PACKAGE-REVISION.json';$packageMeta=if(Test-Path -LiteralPath $packageMetaPath){Get-Content -LiteralPath $packageMetaPath -Raw|ConvertFrom-Json}else{$null};$currentUpdateSerial=if($packageMeta -and $packageMeta.PSObject.Properties['updateSerial']){[int]$packageMeta.updateSerial}else{0};$currentBuildId=if($packageMeta -and $packageMeta.PSObject.Properties['buildId']){[string]$packageMeta.buildId}else{''}
$currentParsed=Parse-Version ($current.version+'-'+$current.build)
if(!$currentParsed){throw 'Current UNCANNY version could not be parsed.'}
[Net.ServicePointManager]::SecurityProtocol=[Net.SecurityProtocolType]::Tls12
$headers=@{'User-Agent'='UNCANNY-Package-Updater';'Accept'='application/vnd.github+json'}
$releases=Invoke-RestMethod -Uri ('https://api.github.com/repos/'+$config.repository+'/releases?per_page=20') -Headers $headers -Method Get -TimeoutSec 15
$candidate=$null
foreach($release in @($releases)){
  if($release.draft){continue}
  $rv=Parse-Version ([string]$release.tag_name);if(!$rv){continue}
  $versionCmp=Compare-Version $rv $currentParsed
  $remoteSerial=Get-HotfixSerial ([string]$release.name+' '+[string]$release.tag_name)
  if($versionCmp -lt 0){continue}
  if($versionCmp -eq 0 -and $remoteSerial -le $currentUpdateSerial){continue}
  $assets=@($release.assets|Where-Object{$_.name -match $config.assetRegex -and $_.name -notmatch '(?i)(PRIVATE|WORKSPACE|SHA256|SOURCE)'})
  if($assets.Count -ne 1){continue}
  $candidate=[pscustomobject]@{release=$release;asset=$assets[0];version=$rv};break
}
if(!$candidate){Progress 100 'UNCANNY is up to date';Write-Result ([ordered]@{available=$false;currentVersion=$current.displayVersion;currentBuildId=$currentBuildId;updateSerial=$currentUpdateSerial;repository=$config.repository;checkedAt=(Get-Date -Format o)})|Out-Null;exit 0}
$digest=[string]$candidate.asset.digest
$result=[ordered]@{available=$true;currentVersion=$current.displayVersion;currentBuildId=$currentBuildId;updateSerial=$currentUpdateSerial;tag=[string]$candidate.release.tag_name;name=[string]$candidate.release.name;asset=[string]$candidate.asset.name;downloadUrl=[string]$candidate.asset.browser_download_url;digest=$digest;publishedAt=[string]$candidate.release.published_at;repository=$config.repository}
if($Mode -eq 'Check'){Progress 100 'Update available';Write-Result $result|Out-Null;exit 0}
if(!$digest -or $digest -notmatch '^sha256:[0-9a-fA-F]{64}$'){throw 'Official release asset does not publish a SHA-256 digest. Automatic install refused.'}
$base=Join-Path $env:LOCALAPPDATA 'UNCANNY\updates';$tagSafe=([string]$candidate.release.tag_name -replace '[^a-zA-Z0-9._-]','_');$updateDir=Join-Path $base $tagSafe;New-Item -ItemType Directory -Force -Path $updateDir|Out-Null
$zip=Join-Path $updateDir ([string]$candidate.asset.name);Progress 20 'Downloading verified UNCANNY package'
Invoke-WebRequest -Uri $candidate.asset.browser_download_url -Headers $headers -OutFile $zip -UseBasicParsing -TimeoutSec 120
Progress 68 'Verifying package SHA-256';$actual=(Get-FileHash -LiteralPath $zip -Algorithm SHA256).Hash.ToLowerInvariant();$expected=$digest.Substring(7).ToLowerInvariant();if($actual -ne $expected){Remove-Item -LiteralPath $zip -Force -ErrorAction SilentlyContinue;throw 'Downloaded package SHA-256 does not match GitHub release metadata.'}
$packages=Join-Path $env:LOCALAPPDATA 'UNCANNY\packages';$dest=Join-Path $packages $tagSafe;$temp=$dest+'.extracting';Remove-Item -LiteralPath $temp -Recurse -Force -ErrorAction SilentlyContinue;New-Item -ItemType Directory -Force -Path $temp|Out-Null
Progress 82 'Extracting update side-by-side';Expand-Archive -LiteralPath $zip -DestinationPath $temp -Force
$entry=Get-ChildItem -LiteralPath $temp -Filter 'UNCANNY.exe' -File -Recurse -Depth 3 -ErrorAction Stop|Select-Object -First 1;if(!$entry){$entry=Get-ChildItem -LiteralPath $temp -Filter 'UNCANNY.cmd' -File -Recurse -Depth 3 -ErrorAction SilentlyContinue|Select-Object -First 1};if(!$entry){throw 'Downloaded package did not contain UNCANNY.exe (or legacy UNCANNY.cmd).'}
Remove-Item -LiteralPath $dest -Recurse -Force -ErrorAction SilentlyContinue;Move-Item -LiteralPath $temp -Destination $dest
$entry=Get-ChildItem -LiteralPath $dest -Filter 'UNCANNY.exe' -File -Recurse -Depth 3|Select-Object -First 1;if(!$entry){$entry=Get-ChildItem -LiteralPath $dest -Filter 'UNCANNY.cmd' -File -Recurse -Depth 3|Select-Object -First 1}
Progress 96 'Launching updated UNCANNY package';Start-Process -FilePath $entry.FullName -WorkingDirectory $entry.DirectoryName
$result['installedPath']=$entry.DirectoryName;Progress 100 'Update launched';Write-Result $result|Out-Null
